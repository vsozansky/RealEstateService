package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "search_engine", schema = "ps1761", catalog = "")
public class SearchEngineEntity {
    private int idSearchEngine;
    private String server;
    private String getvar;

    @Id
    @Column(name = "id_search_engine", nullable = false)
    public int getIdSearchEngine() {
        return idSearchEngine;
    }

    public void setIdSearchEngine(int idSearchEngine) {
        this.idSearchEngine = idSearchEngine;
    }

    @Basic
    @Column(name = "server", nullable = false, length = 64)
    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }

    @Basic
    @Column(name = "getvar", nullable = false, length = 16)
    public String getGetvar() {
        return getvar;
    }

    public void setGetvar(String getvar) {
        this.getvar = getvar;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SearchEngineEntity that = (SearchEngineEntity) o;
        return idSearchEngine == that.idSearchEngine &&
                Objects.equals(server, that.server) &&
                Objects.equals(getvar, that.getvar);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idSearchEngine, server, getvar);
    }
}
