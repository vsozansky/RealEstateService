package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "module_carrier", schema = "ps1761", catalog = "")
@IdClass(ModuleCarrierEntityPK.class)
public class ModuleCarrierEntity {
    private int idModule;
    private int idShop;
    private int idReference;

    @Id
    @Column(name = "id_module", nullable = false)
    public int getIdModule() {
        return idModule;
    }

    public void setIdModule(int idModule) {
        this.idModule = idModule;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Id
    @Column(name = "id_reference", nullable = false)
    public int getIdReference() {
        return idReference;
    }

    public void setIdReference(int idReference) {
        this.idReference = idReference;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ModuleCarrierEntity that = (ModuleCarrierEntity) o;
        return idModule == that.idModule &&
                idShop == that.idShop &&
                idReference == that.idReference;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idModule, idShop, idReference);
    }
}
