package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class RiskLangEntityPK implements Serializable {
    private int idRisk;
    private int idLang;

    @Column(name = "id_risk", nullable = false)
    @Id
    public int getIdRisk() {
        return idRisk;
    }

    public void setIdRisk(int idRisk) {
        this.idRisk = idRisk;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RiskLangEntityPK that = (RiskLangEntityPK) o;
        return idRisk == that.idRisk &&
                idLang == that.idLang;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idRisk, idLang);
    }
}
