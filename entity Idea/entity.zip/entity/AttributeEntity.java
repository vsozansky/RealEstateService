package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "attribute", schema = "ps1761", catalog = "")
public class AttributeEntity {
    private int idAttribute;
    private int idAttributeGroup;
    private String color;
    private int position;

    @Id
    @Column(name = "id_attribute", nullable = false)
    public int getIdAttribute() {
        return idAttribute;
    }

    public void setIdAttribute(int idAttribute) {
        this.idAttribute = idAttribute;
    }

    @Basic
    @Column(name = "id_attribute_group", nullable = false)
    public int getIdAttributeGroup() {
        return idAttributeGroup;
    }

    public void setIdAttributeGroup(int idAttributeGroup) {
        this.idAttributeGroup = idAttributeGroup;
    }

    @Basic
    @Column(name = "color", nullable = false, length = 32)
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Basic
    @Column(name = "position", nullable = false)
    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AttributeEntity that = (AttributeEntity) o;
        return idAttribute == that.idAttribute &&
                idAttributeGroup == that.idAttributeGroup &&
                position == that.position &&
                Objects.equals(color, that.color);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAttribute, idAttributeGroup, color, position);
    }
}
