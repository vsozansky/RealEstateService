package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "link_block_lang", schema = "ps1761", catalog = "")
@IdClass(LinkBlockLangEntityPK.class)
public class LinkBlockLangEntity {
    private int idLinkBlock;
    private int idLang;
    private String name;
    private String customContent;

    @Id
    @Column(name = "id_link_block", nullable = false)
    public int getIdLinkBlock() {
        return idLinkBlock;
    }

    public void setIdLinkBlock(int idLinkBlock) {
        this.idLinkBlock = idLinkBlock;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 40)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "custom_content", nullable = true, length = -1)
    public String getCustomContent() {
        return customContent;
    }

    public void setCustomContent(String customContent) {
        this.customContent = customContent;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LinkBlockLangEntity that = (LinkBlockLangEntity) o;
        return idLinkBlock == that.idLinkBlock &&
                idLang == that.idLang &&
                Objects.equals(name, that.name) &&
                Objects.equals(customContent, that.customContent);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idLinkBlock, idLang, name, customContent);
    }
}
