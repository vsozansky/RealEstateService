package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class SpecificPriceRuleConditionGroupEntityPK implements Serializable {
    private int idSpecificPriceRuleConditionGroup;
    private int idSpecificPriceRule;

    @Column(name = "id_specific_price_rule_condition_group", nullable = false)
    @Id
    public int getIdSpecificPriceRuleConditionGroup() {
        return idSpecificPriceRuleConditionGroup;
    }

    public void setIdSpecificPriceRuleConditionGroup(int idSpecificPriceRuleConditionGroup) {
        this.idSpecificPriceRuleConditionGroup = idSpecificPriceRuleConditionGroup;
    }

    @Column(name = "id_specific_price_rule", nullable = false)
    @Id
    public int getIdSpecificPriceRule() {
        return idSpecificPriceRule;
    }

    public void setIdSpecificPriceRule(int idSpecificPriceRule) {
        this.idSpecificPriceRule = idSpecificPriceRule;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SpecificPriceRuleConditionGroupEntityPK that = (SpecificPriceRuleConditionGroupEntityPK) o;
        return idSpecificPriceRuleConditionGroup == that.idSpecificPriceRuleConditionGroup &&
                idSpecificPriceRule == that.idSpecificPriceRule;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idSpecificPriceRuleConditionGroup, idSpecificPriceRule);
    }
}
