package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "cart_rule_combination", schema = "ps1761", catalog = "")
@IdClass(CartRuleCombinationEntityPK.class)
public class CartRuleCombinationEntity {
    private int idCartRule1;
    private int idCartRule2;

    @Id
    @Column(name = "id_cart_rule_1", nullable = false)
    public int getIdCartRule1() {
        return idCartRule1;
    }

    public void setIdCartRule1(int idCartRule1) {
        this.idCartRule1 = idCartRule1;
    }

    @Id
    @Column(name = "id_cart_rule_2", nullable = false)
    public int getIdCartRule2() {
        return idCartRule2;
    }

    public void setIdCartRule2(int idCartRule2) {
        this.idCartRule2 = idCartRule2;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CartRuleCombinationEntity that = (CartRuleCombinationEntity) o;
        return idCartRule1 == that.idCartRule1 &&
                idCartRule2 == that.idCartRule2;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCartRule1, idCartRule2);
    }
}
