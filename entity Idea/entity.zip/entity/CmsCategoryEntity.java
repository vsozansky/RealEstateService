package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "cms_category", schema = "ps1761", catalog = "")
public class CmsCategoryEntity {
    private int idCmsCategory;
    private int idParent;
    private byte levelDepth;
    private byte active;
    private Timestamp dateAdd;
    private Timestamp dateUpd;
    private int position;

    @Id
    @Column(name = "id_cms_category", nullable = false)
    public int getIdCmsCategory() {
        return idCmsCategory;
    }

    public void setIdCmsCategory(int idCmsCategory) {
        this.idCmsCategory = idCmsCategory;
    }

    @Basic
    @Column(name = "id_parent", nullable = false)
    public int getIdParent() {
        return idParent;
    }

    public void setIdParent(int idParent) {
        this.idParent = idParent;
    }

    @Basic
    @Column(name = "level_depth", nullable = false)
    public byte getLevelDepth() {
        return levelDepth;
    }

    public void setLevelDepth(byte levelDepth) {
        this.levelDepth = levelDepth;
    }

    @Basic
    @Column(name = "active", nullable = false)
    public byte getActive() {
        return active;
    }

    public void setActive(byte active) {
        this.active = active;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Basic
    @Column(name = "date_upd", nullable = false)
    public Timestamp getDateUpd() {
        return dateUpd;
    }

    public void setDateUpd(Timestamp dateUpd) {
        this.dateUpd = dateUpd;
    }

    @Basic
    @Column(name = "position", nullable = false)
    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CmsCategoryEntity that = (CmsCategoryEntity) o;
        return idCmsCategory == that.idCmsCategory &&
                idParent == that.idParent &&
                levelDepth == that.levelDepth &&
                active == that.active &&
                position == that.position &&
                Objects.equals(dateAdd, that.dateAdd) &&
                Objects.equals(dateUpd, that.dateUpd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCmsCategory, idParent, levelDepth, active, dateAdd, dateUpd, position);
    }
}
