package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "order_carrier", schema = "ps1761", catalog = "")
public class OrderCarrierEntity {
    private int idOrderCarrier;
    private int idOrder;
    private int idCarrier;
    private Integer idOrderInvoice;
    private BigDecimal weight;
    private BigDecimal shippingCostTaxExcl;
    private BigDecimal shippingCostTaxIncl;
    private String trackingNumber;
    private Timestamp dateAdd;

    @Id
    @Column(name = "id_order_carrier", nullable = false)
    public int getIdOrderCarrier() {
        return idOrderCarrier;
    }

    public void setIdOrderCarrier(int idOrderCarrier) {
        this.idOrderCarrier = idOrderCarrier;
    }

    @Basic
    @Column(name = "id_order", nullable = false)
    public int getIdOrder() {
        return idOrder;
    }

    public void setIdOrder(int idOrder) {
        this.idOrder = idOrder;
    }

    @Basic
    @Column(name = "id_carrier", nullable = false)
    public int getIdCarrier() {
        return idCarrier;
    }

    public void setIdCarrier(int idCarrier) {
        this.idCarrier = idCarrier;
    }

    @Basic
    @Column(name = "id_order_invoice", nullable = true)
    public Integer getIdOrderInvoice() {
        return idOrderInvoice;
    }

    public void setIdOrderInvoice(Integer idOrderInvoice) {
        this.idOrderInvoice = idOrderInvoice;
    }

    @Basic
    @Column(name = "weight", nullable = true, precision = 6)
    public BigDecimal getWeight() {
        return weight;
    }

    public void setWeight(BigDecimal weight) {
        this.weight = weight;
    }

    @Basic
    @Column(name = "shipping_cost_tax_excl", nullable = true, precision = 6)
    public BigDecimal getShippingCostTaxExcl() {
        return shippingCostTaxExcl;
    }

    public void setShippingCostTaxExcl(BigDecimal shippingCostTaxExcl) {
        this.shippingCostTaxExcl = shippingCostTaxExcl;
    }

    @Basic
    @Column(name = "shipping_cost_tax_incl", nullable = true, precision = 6)
    public BigDecimal getShippingCostTaxIncl() {
        return shippingCostTaxIncl;
    }

    public void setShippingCostTaxIncl(BigDecimal shippingCostTaxIncl) {
        this.shippingCostTaxIncl = shippingCostTaxIncl;
    }

    @Basic
    @Column(name = "tracking_number", nullable = true, length = 64)
    public String getTrackingNumber() {
        return trackingNumber;
    }

    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderCarrierEntity that = (OrderCarrierEntity) o;
        return idOrderCarrier == that.idOrderCarrier &&
                idOrder == that.idOrder &&
                idCarrier == that.idCarrier &&
                Objects.equals(idOrderInvoice, that.idOrderInvoice) &&
                Objects.equals(weight, that.weight) &&
                Objects.equals(shippingCostTaxExcl, that.shippingCostTaxExcl) &&
                Objects.equals(shippingCostTaxIncl, that.shippingCostTaxIncl) &&
                Objects.equals(trackingNumber, that.trackingNumber) &&
                Objects.equals(dateAdd, that.dateAdd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrderCarrier, idOrder, idCarrier, idOrderInvoice, weight, shippingCostTaxExcl, shippingCostTaxIncl, trackingNumber, dateAdd);
    }
}
