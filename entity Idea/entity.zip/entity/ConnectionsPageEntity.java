package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "connections_page", schema = "ps1761", catalog = "")
@IdClass(ConnectionsPageEntityPK.class)
public class ConnectionsPageEntity {
    private int idConnections;
    private int idPage;
    private Timestamp timeStart;
    private Timestamp timeEnd;

    @Id
    @Column(name = "id_connections", nullable = false)
    public int getIdConnections() {
        return idConnections;
    }

    public void setIdConnections(int idConnections) {
        this.idConnections = idConnections;
    }

    @Id
    @Column(name = "id_page", nullable = false)
    public int getIdPage() {
        return idPage;
    }

    public void setIdPage(int idPage) {
        this.idPage = idPage;
    }

    @Id
    @Column(name = "time_start", nullable = false)
    public Timestamp getTimeStart() {
        return timeStart;
    }

    public void setTimeStart(Timestamp timeStart) {
        this.timeStart = timeStart;
    }

    @Basic
    @Column(name = "time_end", nullable = true)
    public Timestamp getTimeEnd() {
        return timeEnd;
    }

    public void setTimeEnd(Timestamp timeEnd) {
        this.timeEnd = timeEnd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ConnectionsPageEntity that = (ConnectionsPageEntity) o;
        return idConnections == that.idConnections &&
                idPage == that.idPage &&
                Objects.equals(timeStart, that.timeStart) &&
                Objects.equals(timeEnd, that.timeEnd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idConnections, idPage, timeStart, timeEnd);
    }
}
