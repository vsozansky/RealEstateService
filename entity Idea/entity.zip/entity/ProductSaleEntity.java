package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Date;
import java.util.Objects;

@Entity
@Table(name = "product_sale", schema = "ps1761", catalog = "")
public class ProductSaleEntity {
    private int idProduct;
    private int quantity;
    private int saleNbr;
    private Date dateUpd;

    @Id
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Basic
    @Column(name = "quantity", nullable = false)
    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Basic
    @Column(name = "sale_nbr", nullable = false)
    public int getSaleNbr() {
        return saleNbr;
    }

    public void setSaleNbr(int saleNbr) {
        this.saleNbr = saleNbr;
    }

    @Basic
    @Column(name = "date_upd", nullable = true)
    public Date getDateUpd() {
        return dateUpd;
    }

    public void setDateUpd(Date dateUpd) {
        this.dateUpd = dateUpd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductSaleEntity that = (ProductSaleEntity) o;
        return idProduct == that.idProduct &&
                quantity == that.quantity &&
                saleNbr == that.saleNbr &&
                Objects.equals(dateUpd, that.dateUpd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProduct, quantity, saleNbr, dateUpd);
    }
}
