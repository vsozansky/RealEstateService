package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "order_return_detail", schema = "ps1761", catalog = "")
@IdClass(OrderReturnDetailEntityPK.class)
public class OrderReturnDetailEntity {
    private int idOrderReturn;
    private int idOrderDetail;
    private int idCustomization;
    private int productQuantity;

    @Id
    @Column(name = "id_order_return", nullable = false)
    public int getIdOrderReturn() {
        return idOrderReturn;
    }

    public void setIdOrderReturn(int idOrderReturn) {
        this.idOrderReturn = idOrderReturn;
    }

    @Id
    @Column(name = "id_order_detail", nullable = false)
    public int getIdOrderDetail() {
        return idOrderDetail;
    }

    public void setIdOrderDetail(int idOrderDetail) {
        this.idOrderDetail = idOrderDetail;
    }

    @Id
    @Column(name = "id_customization", nullable = false)
    public int getIdCustomization() {
        return idCustomization;
    }

    public void setIdCustomization(int idCustomization) {
        this.idCustomization = idCustomization;
    }

    @Basic
    @Column(name = "product_quantity", nullable = false)
    public int getProductQuantity() {
        return productQuantity;
    }

    public void setProductQuantity(int productQuantity) {
        this.productQuantity = productQuantity;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderReturnDetailEntity that = (OrderReturnDetailEntity) o;
        return idOrderReturn == that.idOrderReturn &&
                idOrderDetail == that.idOrderDetail &&
                idCustomization == that.idCustomization &&
                productQuantity == that.productQuantity;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrderReturn, idOrderDetail, idCustomization, productQuantity);
    }
}
