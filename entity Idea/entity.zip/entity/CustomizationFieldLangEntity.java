package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "customization_field_lang", schema = "ps1761", catalog = "")
@IdClass(CustomizationFieldLangEntityPK.class)
public class CustomizationFieldLangEntity {
    private int idCustomizationField;
    private int idLang;
    private int idShop;
    private String name;

    @Id
    @Column(name = "id_customization_field", nullable = false)
    public int getIdCustomizationField() {
        return idCustomizationField;
    }

    public void setIdCustomizationField(int idCustomizationField) {
        this.idCustomizationField = idCustomizationField;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 255)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CustomizationFieldLangEntity that = (CustomizationFieldLangEntity) o;
        return idCustomizationField == that.idCustomizationField &&
                idLang == that.idLang &&
                idShop == that.idShop &&
                Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCustomizationField, idLang, idShop, name);
    }
}
