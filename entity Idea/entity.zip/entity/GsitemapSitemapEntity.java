package com.jprestashop.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Objects;

@Entity
@Table(name = "gsitemap_sitemap", schema = "ps1761", catalog = "")
public class GsitemapSitemapEntity {
    private String link;
    private Integer idShop;

    @Basic
    @Column(name = "link", nullable = true, length = 255)
    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    @Basic
    @Column(name = "id_shop", nullable = true)
    public Integer getIdShop() {
        return idShop;
    }

    public void setIdShop(Integer idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GsitemapSitemapEntity that = (GsitemapSitemapEntity) o;
        return Objects.equals(link, that.link) &&
                Objects.equals(idShop, that.idShop);
    }

    @Override
    public int hashCode() {
        return Objects.hash(link, idShop);
    }
}
