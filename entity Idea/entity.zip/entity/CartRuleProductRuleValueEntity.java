package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "cart_rule_product_rule_value", schema = "ps1761", catalog = "")
@IdClass(CartRuleProductRuleValueEntityPK.class)
public class CartRuleProductRuleValueEntity {
    private int idProductRule;
    private int idItem;

    @Id
    @Column(name = "id_product_rule", nullable = false)
    public int getIdProductRule() {
        return idProductRule;
    }

    public void setIdProductRule(int idProductRule) {
        this.idProductRule = idProductRule;
    }

    @Id
    @Column(name = "id_item", nullable = false)
    public int getIdItem() {
        return idItem;
    }

    public void setIdItem(int idItem) {
        this.idItem = idItem;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CartRuleProductRuleValueEntity that = (CartRuleProductRuleValueEntity) o;
        return idProductRule == that.idProductRule &&
                idItem == that.idItem;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProductRule, idItem);
    }
}
