package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "carrier_tax_rules_group_shop", schema = "ps1761", catalog = "")
@IdClass(CarrierTaxRulesGroupShopEntityPK.class)
public class CarrierTaxRulesGroupShopEntity {
    private int idCarrier;
    private int idTaxRulesGroup;
    private int idShop;

    @Id
    @Column(name = "id_carrier", nullable = false)
    public int getIdCarrier() {
        return idCarrier;
    }

    public void setIdCarrier(int idCarrier) {
        this.idCarrier = idCarrier;
    }

    @Id
    @Column(name = "id_tax_rules_group", nullable = false)
    public int getIdTaxRulesGroup() {
        return idTaxRulesGroup;
    }

    public void setIdTaxRulesGroup(int idTaxRulesGroup) {
        this.idTaxRulesGroup = idTaxRulesGroup;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CarrierTaxRulesGroupShopEntity that = (CarrierTaxRulesGroupShopEntity) o;
        return idCarrier == that.idCarrier &&
                idTaxRulesGroup == that.idTaxRulesGroup &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCarrier, idTaxRulesGroup, idShop);
    }
}
