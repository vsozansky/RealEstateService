package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "warehouse_product_location", schema = "ps1761", catalog = "")
public class WarehouseProductLocationEntity {
    private int idWarehouseProductLocation;
    private int idProduct;
    private int idProductAttribute;
    private int idWarehouse;
    private String location;

    @Id
    @Column(name = "id_warehouse_product_location", nullable = false)
    public int getIdWarehouseProductLocation() {
        return idWarehouseProductLocation;
    }

    public void setIdWarehouseProductLocation(int idWarehouseProductLocation) {
        this.idWarehouseProductLocation = idWarehouseProductLocation;
    }

    @Basic
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Basic
    @Column(name = "id_product_attribute", nullable = false)
    public int getIdProductAttribute() {
        return idProductAttribute;
    }

    public void setIdProductAttribute(int idProductAttribute) {
        this.idProductAttribute = idProductAttribute;
    }

    @Basic
    @Column(name = "id_warehouse", nullable = false)
    public int getIdWarehouse() {
        return idWarehouse;
    }

    public void setIdWarehouse(int idWarehouse) {
        this.idWarehouse = idWarehouse;
    }

    @Basic
    @Column(name = "location", nullable = true, length = 64)
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WarehouseProductLocationEntity that = (WarehouseProductLocationEntity) o;
        return idWarehouseProductLocation == that.idWarehouseProductLocation &&
                idProduct == that.idProduct &&
                idProductAttribute == that.idProductAttribute &&
                idWarehouse == that.idWarehouse &&
                Objects.equals(location, that.location);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idWarehouseProductLocation, idProduct, idProductAttribute, idWarehouse, location);
    }
}
