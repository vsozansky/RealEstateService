package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "advice_lang", schema = "ps1761", catalog = "")
@IdClass(AdviceLangEntityPK.class)
public class AdviceLangEntity {
    private int idAdvice;
    private int idLang;
    private String html;

    @Id
    @Column(name = "id_advice", nullable = false)
    public int getIdAdvice() {
        return idAdvice;
    }

    public void setIdAdvice(int idAdvice) {
        this.idAdvice = idAdvice;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "html", nullable = true, length = -1)
    public String getHtml() {
        return html;
    }

    public void setHtml(String html) {
        this.html = html;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AdviceLangEntity that = (AdviceLangEntity) o;
        return idAdvice == that.idAdvice &&
                idLang == that.idLang &&
                Objects.equals(html, that.html);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAdvice, idLang, html);
    }
}
