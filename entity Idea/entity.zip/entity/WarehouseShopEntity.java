package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "warehouse_shop", schema = "ps1761", catalog = "")
@IdClass(WarehouseShopEntityPK.class)
public class WarehouseShopEntity {
    private int idShop;
    private int idWarehouse;

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Id
    @Column(name = "id_warehouse", nullable = false)
    public int getIdWarehouse() {
        return idWarehouse;
    }

    public void setIdWarehouse(int idWarehouse) {
        this.idWarehouse = idWarehouse;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WarehouseShopEntity that = (WarehouseShopEntity) o;
        return idShop == that.idShop &&
                idWarehouse == that.idWarehouse;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idShop, idWarehouse);
    }
}
