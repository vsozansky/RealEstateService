package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class OrderReturnDetailEntityPK implements Serializable {
    private int idOrderReturn;
    private int idOrderDetail;
    private int idCustomization;

    @Column(name = "id_order_return", nullable = false)
    @Id
    public int getIdOrderReturn() {
        return idOrderReturn;
    }

    public void setIdOrderReturn(int idOrderReturn) {
        this.idOrderReturn = idOrderReturn;
    }

    @Column(name = "id_order_detail", nullable = false)
    @Id
    public int getIdOrderDetail() {
        return idOrderDetail;
    }

    public void setIdOrderDetail(int idOrderDetail) {
        this.idOrderDetail = idOrderDetail;
    }

    @Column(name = "id_customization", nullable = false)
    @Id
    public int getIdCustomization() {
        return idCustomization;
    }

    public void setIdCustomization(int idCustomization) {
        this.idCustomization = idCustomization;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderReturnDetailEntityPK that = (OrderReturnDetailEntityPK) o;
        return idOrderReturn == that.idOrderReturn &&
                idOrderDetail == that.idOrderDetail &&
                idCustomization == that.idCustomization;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrderReturn, idOrderDetail, idCustomization);
    }
}
