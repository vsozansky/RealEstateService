package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name = "delivery", schema = "ps1761", catalog = "")
public class DeliveryEntity {
    private int idDelivery;
    private Integer idShop;
    private Integer idShopGroup;
    private int idCarrier;
    private Integer idRangePrice;
    private Integer idRangeWeight;
    private int idZone;
    private BigDecimal price;

    @Id
    @Column(name = "id_delivery", nullable = false)
    public int getIdDelivery() {
        return idDelivery;
    }

    public void setIdDelivery(int idDelivery) {
        this.idDelivery = idDelivery;
    }

    @Basic
    @Column(name = "id_shop", nullable = true)
    public Integer getIdShop() {
        return idShop;
    }

    public void setIdShop(Integer idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "id_shop_group", nullable = true)
    public Integer getIdShopGroup() {
        return idShopGroup;
    }

    public void setIdShopGroup(Integer idShopGroup) {
        this.idShopGroup = idShopGroup;
    }

    @Basic
    @Column(name = "id_carrier", nullable = false)
    public int getIdCarrier() {
        return idCarrier;
    }

    public void setIdCarrier(int idCarrier) {
        this.idCarrier = idCarrier;
    }

    @Basic
    @Column(name = "id_range_price", nullable = true)
    public Integer getIdRangePrice() {
        return idRangePrice;
    }

    public void setIdRangePrice(Integer idRangePrice) {
        this.idRangePrice = idRangePrice;
    }

    @Basic
    @Column(name = "id_range_weight", nullable = true)
    public Integer getIdRangeWeight() {
        return idRangeWeight;
    }

    public void setIdRangeWeight(Integer idRangeWeight) {
        this.idRangeWeight = idRangeWeight;
    }

    @Basic
    @Column(name = "id_zone", nullable = false)
    public int getIdZone() {
        return idZone;
    }

    public void setIdZone(int idZone) {
        this.idZone = idZone;
    }

    @Basic
    @Column(name = "price", nullable = false, precision = 6)
    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DeliveryEntity that = (DeliveryEntity) o;
        return idDelivery == that.idDelivery &&
                idCarrier == that.idCarrier &&
                idZone == that.idZone &&
                Objects.equals(idShop, that.idShop) &&
                Objects.equals(idShopGroup, that.idShopGroup) &&
                Objects.equals(idRangePrice, that.idRangePrice) &&
                Objects.equals(idRangeWeight, that.idRangeWeight) &&
                Objects.equals(price, that.price);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idDelivery, idShop, idShopGroup, idCarrier, idRangePrice, idRangeWeight, idZone, price);
    }
}
