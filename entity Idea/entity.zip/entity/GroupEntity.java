package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "group", schema = "ps1761", catalog = "")
public class GroupEntity {
    private int idGroup;
    private BigDecimal reduction;
    private byte priceDisplayMethod;
    private byte showPrices;
    private Timestamp dateAdd;
    private Timestamp dateUpd;

    @Id
    @Column(name = "id_group", nullable = false)
    public int getIdGroup() {
        return idGroup;
    }

    public void setIdGroup(int idGroup) {
        this.idGroup = idGroup;
    }

    @Basic
    @Column(name = "reduction", nullable = false, precision = 2)
    public BigDecimal getReduction() {
        return reduction;
    }

    public void setReduction(BigDecimal reduction) {
        this.reduction = reduction;
    }

    @Basic
    @Column(name = "price_display_method", nullable = false)
    public byte getPriceDisplayMethod() {
        return priceDisplayMethod;
    }

    public void setPriceDisplayMethod(byte priceDisplayMethod) {
        this.priceDisplayMethod = priceDisplayMethod;
    }

    @Basic
    @Column(name = "show_prices", nullable = false)
    public byte getShowPrices() {
        return showPrices;
    }

    public void setShowPrices(byte showPrices) {
        this.showPrices = showPrices;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Basic
    @Column(name = "date_upd", nullable = false)
    public Timestamp getDateUpd() {
        return dateUpd;
    }

    public void setDateUpd(Timestamp dateUpd) {
        this.dateUpd = dateUpd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GroupEntity that = (GroupEntity) o;
        return idGroup == that.idGroup &&
                priceDisplayMethod == that.priceDisplayMethod &&
                showPrices == that.showPrices &&
                Objects.equals(reduction, that.reduction) &&
                Objects.equals(dateAdd, that.dateAdd) &&
                Objects.equals(dateUpd, that.dateUpd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idGroup, reduction, priceDisplayMethod, showPrices, dateAdd, dateUpd);
    }
}
