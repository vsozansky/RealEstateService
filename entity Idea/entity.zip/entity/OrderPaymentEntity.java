package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "order_payment", schema = "ps1761", catalog = "")
public class OrderPaymentEntity {
    private int idOrderPayment;
    private String orderReference;
    private int idCurrency;
    private BigDecimal amount;
    private String paymentMethod;
    private BigDecimal conversionRate;
    private String transactionId;
    private String cardNumber;
    private String cardBrand;
    private String cardExpiration;
    private String cardHolder;
    private Timestamp dateAdd;

    @Id
    @Column(name = "id_order_payment", nullable = false)
    public int getIdOrderPayment() {
        return idOrderPayment;
    }

    public void setIdOrderPayment(int idOrderPayment) {
        this.idOrderPayment = idOrderPayment;
    }

    @Basic
    @Column(name = "order_reference", nullable = true, length = 9)
    public String getOrderReference() {
        return orderReference;
    }

    public void setOrderReference(String orderReference) {
        this.orderReference = orderReference;
    }

    @Basic
    @Column(name = "id_currency", nullable = false)
    public int getIdCurrency() {
        return idCurrency;
    }

    public void setIdCurrency(int idCurrency) {
        this.idCurrency = idCurrency;
    }

    @Basic
    @Column(name = "amount", nullable = false, precision = 2)
    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    @Basic
    @Column(name = "payment_method", nullable = false, length = 255)
    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    @Basic
    @Column(name = "conversion_rate", nullable = false, precision = 6)
    public BigDecimal getConversionRate() {
        return conversionRate;
    }

    public void setConversionRate(BigDecimal conversionRate) {
        this.conversionRate = conversionRate;
    }

    @Basic
    @Column(name = "transaction_id", nullable = true, length = 254)
    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    @Basic
    @Column(name = "card_number", nullable = true, length = 254)
    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    @Basic
    @Column(name = "card_brand", nullable = true, length = 254)
    public String getCardBrand() {
        return cardBrand;
    }

    public void setCardBrand(String cardBrand) {
        this.cardBrand = cardBrand;
    }

    @Basic
    @Column(name = "card_expiration", nullable = true, length = 7)
    public String getCardExpiration() {
        return cardExpiration;
    }

    public void setCardExpiration(String cardExpiration) {
        this.cardExpiration = cardExpiration;
    }

    @Basic
    @Column(name = "card_holder", nullable = true, length = 254)
    public String getCardHolder() {
        return cardHolder;
    }

    public void setCardHolder(String cardHolder) {
        this.cardHolder = cardHolder;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderPaymentEntity that = (OrderPaymentEntity) o;
        return idOrderPayment == that.idOrderPayment &&
                idCurrency == that.idCurrency &&
                Objects.equals(orderReference, that.orderReference) &&
                Objects.equals(amount, that.amount) &&
                Objects.equals(paymentMethod, that.paymentMethod) &&
                Objects.equals(conversionRate, that.conversionRate) &&
                Objects.equals(transactionId, that.transactionId) &&
                Objects.equals(cardNumber, that.cardNumber) &&
                Objects.equals(cardBrand, that.cardBrand) &&
                Objects.equals(cardExpiration, that.cardExpiration) &&
                Objects.equals(cardHolder, that.cardHolder) &&
                Objects.equals(dateAdd, that.dateAdd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrderPayment, orderReference, idCurrency, amount, paymentMethod, conversionRate, transactionId, cardNumber, cardBrand, cardExpiration, cardHolder, dateAdd);
    }
}
