package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "pagenotfound", schema = "ps1761", catalog = "")
public class PagenotfoundEntity {
    private int idPagenotfound;
    private int idShop;
    private int idShopGroup;
    private String requestUri;
    private String httpReferer;
    private Timestamp dateAdd;

    @Id
    @Column(name = "id_pagenotfound", nullable = false)
    public int getIdPagenotfound() {
        return idPagenotfound;
    }

    public void setIdPagenotfound(int idPagenotfound) {
        this.idPagenotfound = idPagenotfound;
    }

    @Basic
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "id_shop_group", nullable = false)
    public int getIdShopGroup() {
        return idShopGroup;
    }

    public void setIdShopGroup(int idShopGroup) {
        this.idShopGroup = idShopGroup;
    }

    @Basic
    @Column(name = "request_uri", nullable = false, length = 256)
    public String getRequestUri() {
        return requestUri;
    }

    public void setRequestUri(String requestUri) {
        this.requestUri = requestUri;
    }

    @Basic
    @Column(name = "http_referer", nullable = false, length = 256)
    public String getHttpReferer() {
        return httpReferer;
    }

    public void setHttpReferer(String httpReferer) {
        this.httpReferer = httpReferer;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PagenotfoundEntity that = (PagenotfoundEntity) o;
        return idPagenotfound == that.idPagenotfound &&
                idShop == that.idShop &&
                idShopGroup == that.idShopGroup &&
                Objects.equals(requestUri, that.requestUri) &&
                Objects.equals(httpReferer, that.httpReferer) &&
                Objects.equals(dateAdd, that.dateAdd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPagenotfound, idShop, idShopGroup, requestUri, httpReferer, dateAdd);
    }
}
