package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "layered_filter", schema = "ps1761", catalog = "")
public class LayeredFilterEntity {
    private int idLayeredFilter;
    private String name;
    private String filters;
    private int nCategories;
    private Timestamp dateAdd;

    @Id
    @Column(name = "id_layered_filter", nullable = false)
    public int getIdLayeredFilter() {
        return idLayeredFilter;
    }

    public void setIdLayeredFilter(int idLayeredFilter) {
        this.idLayeredFilter = idLayeredFilter;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 64)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "filters", nullable = true, length = -1)
    public String getFilters() {
        return filters;
    }

    public void setFilters(String filters) {
        this.filters = filters;
    }

    @Basic
    @Column(name = "n_categories", nullable = false)
    public int getnCategories() {
        return nCategories;
    }

    public void setnCategories(int nCategories) {
        this.nCategories = nCategories;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LayeredFilterEntity that = (LayeredFilterEntity) o;
        return idLayeredFilter == that.idLayeredFilter &&
                nCategories == that.nCategories &&
                Objects.equals(name, that.name) &&
                Objects.equals(filters, that.filters) &&
                Objects.equals(dateAdd, that.dateAdd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idLayeredFilter, name, filters, nCategories, dateAdd);
    }
}
