package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "employee_shop", schema = "ps1761", catalog = "")
@IdClass(EmployeeShopEntityPK.class)
public class EmployeeShopEntity {
    private int idEmployee;
    private int idShop;

    @Id
    @Column(name = "id_employee", nullable = false)
    public int getIdEmployee() {
        return idEmployee;
    }

    public void setIdEmployee(int idEmployee) {
        this.idEmployee = idEmployee;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EmployeeShopEntity that = (EmployeeShopEntity) o;
        return idEmployee == that.idEmployee &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idEmployee, idShop);
    }
}
