package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class ConfigurationKpiLangEntityPK implements Serializable {
    private int idConfigurationKpi;
    private int idLang;

    @Column(name = "id_configuration_kpi", nullable = false)
    @Id
    public int getIdConfigurationKpi() {
        return idConfigurationKpi;
    }

    public void setIdConfigurationKpi(int idConfigurationKpi) {
        this.idConfigurationKpi = idConfigurationKpi;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ConfigurationKpiLangEntityPK that = (ConfigurationKpiLangEntityPK) o;
        return idConfigurationKpi == that.idConfigurationKpi &&
                idLang == that.idLang;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idConfigurationKpi, idLang);
    }
}
