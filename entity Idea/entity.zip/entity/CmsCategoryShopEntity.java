package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "cms_category_shop", schema = "ps1761", catalog = "")
@IdClass(CmsCategoryShopEntityPK.class)
public class CmsCategoryShopEntity {
    private int idCmsCategory;
    private int idShop;

    @Id
    @Column(name = "id_cms_category", nullable = false)
    public int getIdCmsCategory() {
        return idCmsCategory;
    }

    public void setIdCmsCategory(int idCmsCategory) {
        this.idCmsCategory = idCmsCategory;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CmsCategoryShopEntity that = (CmsCategoryShopEntity) o;
        return idCmsCategory == that.idCmsCategory &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCmsCategory, idShop);
    }
}
