package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "category_group", schema = "ps1761", catalog = "")
@IdClass(CategoryGroupEntityPK.class)
public class CategoryGroupEntity {
    private int idCategory;
    private int idGroup;

    @Id
    @Column(name = "id_category", nullable = false)
    public int getIdCategory() {
        return idCategory;
    }

    public void setIdCategory(int idCategory) {
        this.idCategory = idCategory;
    }

    @Id
    @Column(name = "id_group", nullable = false)
    public int getIdGroup() {
        return idGroup;
    }

    public void setIdGroup(int idGroup) {
        this.idGroup = idGroup;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CategoryGroupEntity that = (CategoryGroupEntity) o;
        return idCategory == that.idCategory &&
                idGroup == that.idGroup;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCategory, idGroup);
    }
}
