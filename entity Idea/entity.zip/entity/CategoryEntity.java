package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "category", schema = "ps1761", catalog = "")
public class CategoryEntity {
    private int idCategory;
    private int idParent;
    private int idShopDefault;
    private byte levelDepth;
    private int nleft;
    private int nright;
    private byte active;
    private Timestamp dateAdd;
    private Timestamp dateUpd;
    private int position;
    private byte isRootCategory;

    @Id
    @Column(name = "id_category", nullable = false)
    public int getIdCategory() {
        return idCategory;
    }

    public void setIdCategory(int idCategory) {
        this.idCategory = idCategory;
    }

    @Basic
    @Column(name = "id_parent", nullable = false)
    public int getIdParent() {
        return idParent;
    }

    public void setIdParent(int idParent) {
        this.idParent = idParent;
    }

    @Basic
    @Column(name = "id_shop_default", nullable = false)
    public int getIdShopDefault() {
        return idShopDefault;
    }

    public void setIdShopDefault(int idShopDefault) {
        this.idShopDefault = idShopDefault;
    }

    @Basic
    @Column(name = "level_depth", nullable = false)
    public byte getLevelDepth() {
        return levelDepth;
    }

    public void setLevelDepth(byte levelDepth) {
        this.levelDepth = levelDepth;
    }

    @Basic
    @Column(name = "nleft", nullable = false)
    public int getNleft() {
        return nleft;
    }

    public void setNleft(int nleft) {
        this.nleft = nleft;
    }

    @Basic
    @Column(name = "nright", nullable = false)
    public int getNright() {
        return nright;
    }

    public void setNright(int nright) {
        this.nright = nright;
    }

    @Basic
    @Column(name = "active", nullable = false)
    public byte getActive() {
        return active;
    }

    public void setActive(byte active) {
        this.active = active;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Basic
    @Column(name = "date_upd", nullable = false)
    public Timestamp getDateUpd() {
        return dateUpd;
    }

    public void setDateUpd(Timestamp dateUpd) {
        this.dateUpd = dateUpd;
    }

    @Basic
    @Column(name = "position", nullable = false)
    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    @Basic
    @Column(name = "is_root_category", nullable = false)
    public byte getIsRootCategory() {
        return isRootCategory;
    }

    public void setIsRootCategory(byte isRootCategory) {
        this.isRootCategory = isRootCategory;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CategoryEntity that = (CategoryEntity) o;
        return idCategory == that.idCategory &&
                idParent == that.idParent &&
                idShopDefault == that.idShopDefault &&
                levelDepth == that.levelDepth &&
                nleft == that.nleft &&
                nright == that.nright &&
                active == that.active &&
                position == that.position &&
                isRootCategory == that.isRootCategory &&
                Objects.equals(dateAdd, that.dateAdd) &&
                Objects.equals(dateUpd, that.dateUpd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCategory, idParent, idShopDefault, levelDepth, nleft, nright, active, dateAdd, dateUpd, position, isRootCategory);
    }
}
