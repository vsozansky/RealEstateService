package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "access", schema = "ps1761", catalog = "")
@IdClass(AccessEntityPK.class)
public class AccessEntity {
    private int idProfile;
    private int idAuthorizationRole;

    @Id
    @Column(name = "id_profile", nullable = false)
    public int getIdProfile() {
        return idProfile;
    }

    public void setIdProfile(int idProfile) {
        this.idProfile = idProfile;
    }

    @Id
    @Column(name = "id_authorization_role", nullable = false)
    public int getIdAuthorizationRole() {
        return idAuthorizationRole;
    }

    public void setIdAuthorizationRole(int idAuthorizationRole) {
        this.idAuthorizationRole = idAuthorizationRole;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AccessEntity that = (AccessEntity) o;
        return idProfile == that.idProfile &&
                idAuthorizationRole == that.idAuthorizationRole;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProfile, idAuthorizationRole);
    }
}
