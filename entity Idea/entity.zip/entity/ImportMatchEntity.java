package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "import_match", schema = "ps1761", catalog = "")
public class ImportMatchEntity {
    private int idImportMatch;
    private String name;
    private String match;
    private int skip;

    @Id
    @Column(name = "id_import_match", nullable = false)
    public int getIdImportMatch() {
        return idImportMatch;
    }

    public void setIdImportMatch(int idImportMatch) {
        this.idImportMatch = idImportMatch;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 32)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "match", nullable = false, length = -1)
    public String getMatch() {
        return match;
    }

    public void setMatch(String match) {
        this.match = match;
    }

    @Basic
    @Column(name = "skip", nullable = false)
    public int getSkip() {
        return skip;
    }

    public void setSkip(int skip) {
        this.skip = skip;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ImportMatchEntity that = (ImportMatchEntity) o;
        return idImportMatch == that.idImportMatch &&
                skip == that.skip &&
                Objects.equals(name, that.name) &&
                Objects.equals(match, that.match);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idImportMatch, name, match, skip);
    }
}
