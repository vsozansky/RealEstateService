package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "psgdpr_log", schema = "ps1761", catalog = "")
public class PsgdprLogEntity {
    private int idGdprLog;
    private Integer idCustomer;
    private Integer idGuest;
    private String clientName;
    private int idModule;
    private int requestType;
    private Timestamp dateAdd;
    private Timestamp dateUpd;

    @Id
    @Column(name = "id_gdpr_log", nullable = false)
    public int getIdGdprLog() {
        return idGdprLog;
    }

    public void setIdGdprLog(int idGdprLog) {
        this.idGdprLog = idGdprLog;
    }

    @Basic
    @Column(name = "id_customer", nullable = true)
    public Integer getIdCustomer() {
        return idCustomer;
    }

    public void setIdCustomer(Integer idCustomer) {
        this.idCustomer = idCustomer;
    }

    @Basic
    @Column(name = "id_guest", nullable = true)
    public Integer getIdGuest() {
        return idGuest;
    }

    public void setIdGuest(Integer idGuest) {
        this.idGuest = idGuest;
    }

    @Basic
    @Column(name = "client_name", nullable = true, length = 250)
    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    @Basic
    @Column(name = "id_module", nullable = false)
    public int getIdModule() {
        return idModule;
    }

    public void setIdModule(int idModule) {
        this.idModule = idModule;
    }

    @Basic
    @Column(name = "request_type", nullable = false)
    public int getRequestType() {
        return requestType;
    }

    public void setRequestType(int requestType) {
        this.requestType = requestType;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Basic
    @Column(name = "date_upd", nullable = false)
    public Timestamp getDateUpd() {
        return dateUpd;
    }

    public void setDateUpd(Timestamp dateUpd) {
        this.dateUpd = dateUpd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PsgdprLogEntity that = (PsgdprLogEntity) o;
        return idGdprLog == that.idGdprLog &&
                idModule == that.idModule &&
                requestType == that.requestType &&
                Objects.equals(idCustomer, that.idCustomer) &&
                Objects.equals(idGuest, that.idGuest) &&
                Objects.equals(clientName, that.clientName) &&
                Objects.equals(dateAdd, that.dateAdd) &&
                Objects.equals(dateUpd, that.dateUpd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idGdprLog, idCustomer, idGuest, clientName, idModule, requestType, dateAdd, dateUpd);
    }
}
