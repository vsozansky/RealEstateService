package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "meta", schema = "ps1761", catalog = "")
public class MetaEntity {
    private int idMeta;
    private String page;
    private byte configurable;

    @Id
    @Column(name = "id_meta", nullable = false)
    public int getIdMeta() {
        return idMeta;
    }

    public void setIdMeta(int idMeta) {
        this.idMeta = idMeta;
    }

    @Basic
    @Column(name = "page", nullable = false, length = 64)
    public String getPage() {
        return page;
    }

    public void setPage(String page) {
        this.page = page;
    }

    @Basic
    @Column(name = "configurable", nullable = false)
    public byte getConfigurable() {
        return configurable;
    }

    public void setConfigurable(byte configurable) {
        this.configurable = configurable;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MetaEntity that = (MetaEntity) o;
        return idMeta == that.idMeta &&
                configurable == that.configurable &&
                Objects.equals(page, that.page);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idMeta, page, configurable);
    }
}
