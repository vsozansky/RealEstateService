package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class StockMvtReasonLangEntityPK implements Serializable {
    private int idStockMvtReason;
    private int idLang;

    @Column(name = "id_stock_mvt_reason", nullable = false)
    @Id
    public int getIdStockMvtReason() {
        return idStockMvtReason;
    }

    public void setIdStockMvtReason(int idStockMvtReason) {
        this.idStockMvtReason = idStockMvtReason;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StockMvtReasonLangEntityPK that = (StockMvtReasonLangEntityPK) o;
        return idStockMvtReason == that.idStockMvtReason &&
                idLang == that.idLang;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idStockMvtReason, idLang);
    }
}
