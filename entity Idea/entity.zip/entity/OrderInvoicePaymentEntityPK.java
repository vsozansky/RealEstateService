package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class OrderInvoicePaymentEntityPK implements Serializable {
    private int idOrderInvoice;
    private int idOrderPayment;

    @Column(name = "id_order_invoice", nullable = false)
    @Id
    public int getIdOrderInvoice() {
        return idOrderInvoice;
    }

    public void setIdOrderInvoice(int idOrderInvoice) {
        this.idOrderInvoice = idOrderInvoice;
    }

    @Column(name = "id_order_payment", nullable = false)
    @Id
    public int getIdOrderPayment() {
        return idOrderPayment;
    }

    public void setIdOrderPayment(int idOrderPayment) {
        this.idOrderPayment = idOrderPayment;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderInvoicePaymentEntityPK that = (OrderInvoicePaymentEntityPK) o;
        return idOrderInvoice == that.idOrderInvoice &&
                idOrderPayment == that.idOrderPayment;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrderInvoice, idOrderPayment);
    }
}
