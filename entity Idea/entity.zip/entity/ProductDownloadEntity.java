package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "product_download", schema = "ps1761", catalog = "")
public class ProductDownloadEntity {
    private int idProductDownload;
    private int idProduct;
    private String displayFilename;
    private String filename;
    private Timestamp dateAdd;
    private Timestamp dateExpiration;
    private Integer nbDaysAccessible;
    private Integer nbDownloadable;
    private byte active;
    private byte isShareable;

    @Id
    @Column(name = "id_product_download", nullable = false)
    public int getIdProductDownload() {
        return idProductDownload;
    }

    public void setIdProductDownload(int idProductDownload) {
        this.idProductDownload = idProductDownload;
    }

    @Basic
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Basic
    @Column(name = "display_filename", nullable = true, length = 255)
    public String getDisplayFilename() {
        return displayFilename;
    }

    public void setDisplayFilename(String displayFilename) {
        this.displayFilename = displayFilename;
    }

    @Basic
    @Column(name = "filename", nullable = true, length = 255)
    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Basic
    @Column(name = "date_expiration", nullable = true)
    public Timestamp getDateExpiration() {
        return dateExpiration;
    }

    public void setDateExpiration(Timestamp dateExpiration) {
        this.dateExpiration = dateExpiration;
    }

    @Basic
    @Column(name = "nb_days_accessible", nullable = true)
    public Integer getNbDaysAccessible() {
        return nbDaysAccessible;
    }

    public void setNbDaysAccessible(Integer nbDaysAccessible) {
        this.nbDaysAccessible = nbDaysAccessible;
    }

    @Basic
    @Column(name = "nb_downloadable", nullable = true)
    public Integer getNbDownloadable() {
        return nbDownloadable;
    }

    public void setNbDownloadable(Integer nbDownloadable) {
        this.nbDownloadable = nbDownloadable;
    }

    @Basic
    @Column(name = "active", nullable = false)
    public byte getActive() {
        return active;
    }

    public void setActive(byte active) {
        this.active = active;
    }

    @Basic
    @Column(name = "is_shareable", nullable = false)
    public byte getIsShareable() {
        return isShareable;
    }

    public void setIsShareable(byte isShareable) {
        this.isShareable = isShareable;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductDownloadEntity that = (ProductDownloadEntity) o;
        return idProductDownload == that.idProductDownload &&
                idProduct == that.idProduct &&
                active == that.active &&
                isShareable == that.isShareable &&
                Objects.equals(displayFilename, that.displayFilename) &&
                Objects.equals(filename, that.filename) &&
                Objects.equals(dateAdd, that.dateAdd) &&
                Objects.equals(dateExpiration, that.dateExpiration) &&
                Objects.equals(nbDaysAccessible, that.nbDaysAccessible) &&
                Objects.equals(nbDownloadable, that.nbDownloadable);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProductDownload, idProduct, displayFilename, filename, dateAdd, dateExpiration, nbDaysAccessible, nbDownloadable, active, isShareable);
    }
}
