package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class SearchIndexEntityPK implements Serializable {
    private int idProduct;
    private int idWord;

    @Column(name = "id_product", nullable = false)
    @Id
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Column(name = "id_word", nullable = false)
    @Id
    public int getIdWord() {
        return idWord;
    }

    public void setIdWord(int idWord) {
        this.idWord = idWord;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SearchIndexEntityPK that = (SearchIndexEntityPK) o;
        return idProduct == that.idProduct &&
                idWord == that.idWord;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProduct, idWord);
    }
}
