package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "tax_rules_group_shop", schema = "ps1761", catalog = "")
@IdClass(TaxRulesGroupShopEntityPK.class)
public class TaxRulesGroupShopEntity {
    private int idTaxRulesGroup;
    private int idShop;

    @Id
    @Column(name = "id_tax_rules_group", nullable = false)
    public int getIdTaxRulesGroup() {
        return idTaxRulesGroup;
    }

    public void setIdTaxRulesGroup(int idTaxRulesGroup) {
        this.idTaxRulesGroup = idTaxRulesGroup;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TaxRulesGroupShopEntity that = (TaxRulesGroupShopEntity) o;
        return idTaxRulesGroup == that.idTaxRulesGroup &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idTaxRulesGroup, idShop);
    }
}
