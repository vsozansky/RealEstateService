package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class AttributeLangEntityPK implements Serializable {
    private int idAttribute;
    private int idLang;

    @Column(name = "id_attribute", nullable = false)
    @Id
    public int getIdAttribute() {
        return idAttribute;
    }

    public void setIdAttribute(int idAttribute) {
        this.idAttribute = idAttribute;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AttributeLangEntityPK that = (AttributeLangEntityPK) o;
        return idAttribute == that.idAttribute &&
                idLang == that.idLang;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAttribute, idLang);
    }
}
