package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "log", schema = "ps1761", catalog = "")
public class LogEntity {
    private int idLog;
    private byte severity;
    private Integer errorCode;
    private String message;
    private String objectType;
    private Integer objectId;
    private Integer idEmployee;
    private Timestamp dateAdd;
    private Timestamp dateUpd;

    @Id
    @Column(name = "id_log", nullable = false)
    public int getIdLog() {
        return idLog;
    }

    public void setIdLog(int idLog) {
        this.idLog = idLog;
    }

    @Basic
    @Column(name = "severity", nullable = false)
    public byte getSeverity() {
        return severity;
    }

    public void setSeverity(byte severity) {
        this.severity = severity;
    }

    @Basic
    @Column(name = "error_code", nullable = true)
    public Integer getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(Integer errorCode) {
        this.errorCode = errorCode;
    }

    @Basic
    @Column(name = "message", nullable = false, length = -1)
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Basic
    @Column(name = "object_type", nullable = true, length = 32)
    public String getObjectType() {
        return objectType;
    }

    public void setObjectType(String objectType) {
        this.objectType = objectType;
    }

    @Basic
    @Column(name = "object_id", nullable = true)
    public Integer getObjectId() {
        return objectId;
    }

    public void setObjectId(Integer objectId) {
        this.objectId = objectId;
    }

    @Basic
    @Column(name = "id_employee", nullable = true)
    public Integer getIdEmployee() {
        return idEmployee;
    }

    public void setIdEmployee(Integer idEmployee) {
        this.idEmployee = idEmployee;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Basic
    @Column(name = "date_upd", nullable = false)
    public Timestamp getDateUpd() {
        return dateUpd;
    }

    public void setDateUpd(Timestamp dateUpd) {
        this.dateUpd = dateUpd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LogEntity logEntity = (LogEntity) o;
        return idLog == logEntity.idLog &&
                severity == logEntity.severity &&
                Objects.equals(errorCode, logEntity.errorCode) &&
                Objects.equals(message, logEntity.message) &&
                Objects.equals(objectType, logEntity.objectType) &&
                Objects.equals(objectId, logEntity.objectId) &&
                Objects.equals(idEmployee, logEntity.idEmployee) &&
                Objects.equals(dateAdd, logEntity.dateAdd) &&
                Objects.equals(dateUpd, logEntity.dateUpd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idLog, severity, errorCode, message, objectType, objectId, idEmployee, dateAdd, dateUpd);
    }
}
