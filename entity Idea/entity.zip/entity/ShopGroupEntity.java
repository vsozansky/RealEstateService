package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "shop_group", schema = "ps1761", catalog = "")
public class ShopGroupEntity {
    private int idShopGroup;
    private String name;
    private byte shareCustomer;
    private byte shareOrder;
    private byte shareStock;
    private byte active;
    private byte deleted;

    @Id
    @Column(name = "id_shop_group", nullable = false)
    public int getIdShopGroup() {
        return idShopGroup;
    }

    public void setIdShopGroup(int idShopGroup) {
        this.idShopGroup = idShopGroup;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 64)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "share_customer", nullable = false)
    public byte getShareCustomer() {
        return shareCustomer;
    }

    public void setShareCustomer(byte shareCustomer) {
        this.shareCustomer = shareCustomer;
    }

    @Basic
    @Column(name = "share_order", nullable = false)
    public byte getShareOrder() {
        return shareOrder;
    }

    public void setShareOrder(byte shareOrder) {
        this.shareOrder = shareOrder;
    }

    @Basic
    @Column(name = "share_stock", nullable = false)
    public byte getShareStock() {
        return shareStock;
    }

    public void setShareStock(byte shareStock) {
        this.shareStock = shareStock;
    }

    @Basic
    @Column(name = "active", nullable = false)
    public byte getActive() {
        return active;
    }

    public void setActive(byte active) {
        this.active = active;
    }

    @Basic
    @Column(name = "deleted", nullable = false)
    public byte getDeleted() {
        return deleted;
    }

    public void setDeleted(byte deleted) {
        this.deleted = deleted;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ShopGroupEntity that = (ShopGroupEntity) o;
        return idShopGroup == that.idShopGroup &&
                shareCustomer == that.shareCustomer &&
                shareOrder == that.shareOrder &&
                shareStock == that.shareStock &&
                active == that.active &&
                deleted == that.deleted &&
                Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idShopGroup, name, shareCustomer, shareOrder, shareStock, active, deleted);
    }
}
