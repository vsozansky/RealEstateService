package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "cms_role", schema = "ps1761", catalog = "")
@IdClass(CmsRoleEntityPK.class)
public class CmsRoleEntity {
    private int idCmsRole;
    private String name;
    private int idCms;

    @Id
    @Column(name = "id_cms_role", nullable = false)
    public int getIdCmsRole() {
        return idCmsRole;
    }

    public void setIdCmsRole(int idCmsRole) {
        this.idCmsRole = idCmsRole;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 50)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Id
    @Column(name = "id_cms", nullable = false)
    public int getIdCms() {
        return idCms;
    }

    public void setIdCms(int idCms) {
        this.idCms = idCms;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CmsRoleEntity that = (CmsRoleEntity) o;
        return idCmsRole == that.idCmsRole &&
                idCms == that.idCms &&
                Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCmsRole, name, idCms);
    }
}
