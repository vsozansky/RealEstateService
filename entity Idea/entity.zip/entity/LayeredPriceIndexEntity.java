package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "layered_price_index", schema = "ps1761", catalog = "")
@IdClass(LayeredPriceIndexEntityPK.class)
public class LayeredPriceIndexEntity {
    private int idProduct;
    private int idCurrency;
    private int idShop;
    private int priceMin;
    private int priceMax;
    private int idCountry;

    @Id
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Id
    @Column(name = "id_currency", nullable = false)
    public int getIdCurrency() {
        return idCurrency;
    }

    public void setIdCurrency(int idCurrency) {
        this.idCurrency = idCurrency;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "price_min", nullable = false)
    public int getPriceMin() {
        return priceMin;
    }

    public void setPriceMin(int priceMin) {
        this.priceMin = priceMin;
    }

    @Basic
    @Column(name = "price_max", nullable = false)
    public int getPriceMax() {
        return priceMax;
    }

    public void setPriceMax(int priceMax) {
        this.priceMax = priceMax;
    }

    @Id
    @Column(name = "id_country", nullable = false)
    public int getIdCountry() {
        return idCountry;
    }

    public void setIdCountry(int idCountry) {
        this.idCountry = idCountry;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LayeredPriceIndexEntity that = (LayeredPriceIndexEntity) o;
        return idProduct == that.idProduct &&
                idCurrency == that.idCurrency &&
                idShop == that.idShop &&
                priceMin == that.priceMin &&
                priceMax == that.priceMax &&
                idCountry == that.idCountry;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProduct, idCurrency, idShop, priceMin, priceMax, idCountry);
    }
}
