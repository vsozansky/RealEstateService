package com.jprestashop.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name = "order_slip_detail_tax", schema = "ps1761", catalog = "")
public class OrderSlipDetailTaxEntity {
    private int idOrderSlipDetail;
    private int idTax;
    private BigDecimal unitAmount;
    private BigDecimal totalAmount;

    @Basic
    @Column(name = "id_order_slip_detail", nullable = false)
    public int getIdOrderSlipDetail() {
        return idOrderSlipDetail;
    }

    public void setIdOrderSlipDetail(int idOrderSlipDetail) {
        this.idOrderSlipDetail = idOrderSlipDetail;
    }

    @Basic
    @Column(name = "id_tax", nullable = false)
    public int getIdTax() {
        return idTax;
    }

    public void setIdTax(int idTax) {
        this.idTax = idTax;
    }

    @Basic
    @Column(name = "unit_amount", nullable = false, precision = 6)
    public BigDecimal getUnitAmount() {
        return unitAmount;
    }

    public void setUnitAmount(BigDecimal unitAmount) {
        this.unitAmount = unitAmount;
    }

    @Basic
    @Column(name = "total_amount", nullable = false, precision = 6)
    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderSlipDetailTaxEntity that = (OrderSlipDetailTaxEntity) o;
        return idOrderSlipDetail == that.idOrderSlipDetail &&
                idTax == that.idTax &&
                Objects.equals(unitAmount, that.unitAmount) &&
                Objects.equals(totalAmount, that.totalAmount);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrderSlipDetail, idTax, unitAmount, totalAmount);
    }
}
