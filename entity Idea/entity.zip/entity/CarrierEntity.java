package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name = "carrier", schema = "ps1761", catalog = "")
public class CarrierEntity {
    private int idCarrier;
    private int idReference;
    private Integer idTaxRulesGroup;
    private String name;
    private String url;
    private byte active;
    private byte deleted;
    private byte shippingHandling;
    private byte rangeBehavior;
    private byte isModule;
    private byte isFree;
    private byte shippingExternal;
    private byte needRange;
    private String externalModuleName;
    private int shippingMethod;
    private int position;
    private Integer maxWidth;
    private Integer maxHeight;
    private Integer maxDepth;
    private BigDecimal maxWeight;
    private Integer grade;

    @Id
    @Column(name = "id_carrier", nullable = false)
    public int getIdCarrier() {
        return idCarrier;
    }

    public void setIdCarrier(int idCarrier) {
        this.idCarrier = idCarrier;
    }

    @Basic
    @Column(name = "id_reference", nullable = false)
    public int getIdReference() {
        return idReference;
    }

    public void setIdReference(int idReference) {
        this.idReference = idReference;
    }

    @Basic
    @Column(name = "id_tax_rules_group", nullable = true)
    public Integer getIdTaxRulesGroup() {
        return idTaxRulesGroup;
    }

    public void setIdTaxRulesGroup(Integer idTaxRulesGroup) {
        this.idTaxRulesGroup = idTaxRulesGroup;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 64)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "url", nullable = true, length = 255)
    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Basic
    @Column(name = "active", nullable = false)
    public byte getActive() {
        return active;
    }

    public void setActive(byte active) {
        this.active = active;
    }

    @Basic
    @Column(name = "deleted", nullable = false)
    public byte getDeleted() {
        return deleted;
    }

    public void setDeleted(byte deleted) {
        this.deleted = deleted;
    }

    @Basic
    @Column(name = "shipping_handling", nullable = false)
    public byte getShippingHandling() {
        return shippingHandling;
    }

    public void setShippingHandling(byte shippingHandling) {
        this.shippingHandling = shippingHandling;
    }

    @Basic
    @Column(name = "range_behavior", nullable = false)
    public byte getRangeBehavior() {
        return rangeBehavior;
    }

    public void setRangeBehavior(byte rangeBehavior) {
        this.rangeBehavior = rangeBehavior;
    }

    @Basic
    @Column(name = "is_module", nullable = false)
    public byte getIsModule() {
        return isModule;
    }

    public void setIsModule(byte isModule) {
        this.isModule = isModule;
    }

    @Basic
    @Column(name = "is_free", nullable = false)
    public byte getIsFree() {
        return isFree;
    }

    public void setIsFree(byte isFree) {
        this.isFree = isFree;
    }

    @Basic
    @Column(name = "shipping_external", nullable = false)
    public byte getShippingExternal() {
        return shippingExternal;
    }

    public void setShippingExternal(byte shippingExternal) {
        this.shippingExternal = shippingExternal;
    }

    @Basic
    @Column(name = "need_range", nullable = false)
    public byte getNeedRange() {
        return needRange;
    }

    public void setNeedRange(byte needRange) {
        this.needRange = needRange;
    }

    @Basic
    @Column(name = "external_module_name", nullable = true, length = 64)
    public String getExternalModuleName() {
        return externalModuleName;
    }

    public void setExternalModuleName(String externalModuleName) {
        this.externalModuleName = externalModuleName;
    }

    @Basic
    @Column(name = "shipping_method", nullable = false)
    public int getShippingMethod() {
        return shippingMethod;
    }

    public void setShippingMethod(int shippingMethod) {
        this.shippingMethod = shippingMethod;
    }

    @Basic
    @Column(name = "position", nullable = false)
    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    @Basic
    @Column(name = "max_width", nullable = true)
    public Integer getMaxWidth() {
        return maxWidth;
    }

    public void setMaxWidth(Integer maxWidth) {
        this.maxWidth = maxWidth;
    }

    @Basic
    @Column(name = "max_height", nullable = true)
    public Integer getMaxHeight() {
        return maxHeight;
    }

    public void setMaxHeight(Integer maxHeight) {
        this.maxHeight = maxHeight;
    }

    @Basic
    @Column(name = "max_depth", nullable = true)
    public Integer getMaxDepth() {
        return maxDepth;
    }

    public void setMaxDepth(Integer maxDepth) {
        this.maxDepth = maxDepth;
    }

    @Basic
    @Column(name = "max_weight", nullable = true, precision = 6)
    public BigDecimal getMaxWeight() {
        return maxWeight;
    }

    public void setMaxWeight(BigDecimal maxWeight) {
        this.maxWeight = maxWeight;
    }

    @Basic
    @Column(name = "grade", nullable = true)
    public Integer getGrade() {
        return grade;
    }

    public void setGrade(Integer grade) {
        this.grade = grade;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CarrierEntity that = (CarrierEntity) o;
        return idCarrier == that.idCarrier &&
                idReference == that.idReference &&
                active == that.active &&
                deleted == that.deleted &&
                shippingHandling == that.shippingHandling &&
                rangeBehavior == that.rangeBehavior &&
                isModule == that.isModule &&
                isFree == that.isFree &&
                shippingExternal == that.shippingExternal &&
                needRange == that.needRange &&
                shippingMethod == that.shippingMethod &&
                position == that.position &&
                Objects.equals(idTaxRulesGroup, that.idTaxRulesGroup) &&
                Objects.equals(name, that.name) &&
                Objects.equals(url, that.url) &&
                Objects.equals(externalModuleName, that.externalModuleName) &&
                Objects.equals(maxWidth, that.maxWidth) &&
                Objects.equals(maxHeight, that.maxHeight) &&
                Objects.equals(maxDepth, that.maxDepth) &&
                Objects.equals(maxWeight, that.maxWeight) &&
                Objects.equals(grade, that.grade);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCarrier, idReference, idTaxRulesGroup, name, url, active, deleted, shippingHandling, rangeBehavior, isModule, isFree, shippingExternal, needRange, externalModuleName, shippingMethod, position, maxWidth, maxHeight, maxDepth, maxWeight, grade);
    }
}
