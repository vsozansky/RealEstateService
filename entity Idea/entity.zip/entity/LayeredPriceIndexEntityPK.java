package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class LayeredPriceIndexEntityPK implements Serializable {
    private int idProduct;
    private int idCurrency;
    private int idShop;
    private int idCountry;

    @Column(name = "id_product", nullable = false)
    @Id
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Column(name = "id_currency", nullable = false)
    @Id
    public int getIdCurrency() {
        return idCurrency;
    }

    public void setIdCurrency(int idCurrency) {
        this.idCurrency = idCurrency;
    }

    @Column(name = "id_shop", nullable = false)
    @Id
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Column(name = "id_country", nullable = false)
    @Id
    public int getIdCountry() {
        return idCountry;
    }

    public void setIdCountry(int idCountry) {
        this.idCountry = idCountry;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LayeredPriceIndexEntityPK that = (LayeredPriceIndexEntityPK) o;
        return idProduct == that.idProduct &&
                idCurrency == that.idCurrency &&
                idShop == that.idShop &&
                idCountry == that.idCountry;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProduct, idCurrency, idShop, idCountry);
    }
}
