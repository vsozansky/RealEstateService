package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "info_shop", schema = "ps1761", catalog = "")
@IdClass(InfoShopEntityPK.class)
public class InfoShopEntity {
    private int idInfo;
    private int idShop;

    @Id
    @Column(name = "id_info", nullable = false)
    public int getIdInfo() {
        return idInfo;
    }

    public void setIdInfo(int idInfo) {
        this.idInfo = idInfo;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InfoShopEntity that = (InfoShopEntity) o;
        return idInfo == that.idInfo &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idInfo, idShop);
    }
}
