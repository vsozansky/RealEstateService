package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "page_type", schema = "ps1761", catalog = "")
public class PageTypeEntity {
    private int idPageType;
    private String name;

    @Id
    @Column(name = "id_page_type", nullable = false)
    public int getIdPageType() {
        return idPageType;
    }

    public void setIdPageType(int idPageType) {
        this.idPageType = idPageType;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 255)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PageTypeEntity that = (PageTypeEntity) o;
        return idPageType == that.idPageType &&
                Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPageType, name);
    }
}
