package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "smarty_cache", schema = "ps1761", catalog = "")
public class SmartyCacheEntity {
    private String idSmartyCache;
    private String name;
    private String cacheId;
    private Timestamp modified;
    private String content;

    @Id
    @Column(name = "id_smarty_cache", nullable = false, length = 40)
    public String getIdSmartyCache() {
        return idSmartyCache;
    }

    public void setIdSmartyCache(String idSmartyCache) {
        this.idSmartyCache = idSmartyCache;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 40)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "cache_id", nullable = true, length = 254)
    public String getCacheId() {
        return cacheId;
    }

    public void setCacheId(String cacheId) {
        this.cacheId = cacheId;
    }

    @Basic
    @Column(name = "modified", nullable = false)
    public Timestamp getModified() {
        return modified;
    }

    public void setModified(Timestamp modified) {
        this.modified = modified;
    }

    @Basic
    @Column(name = "content", nullable = false, length = -1)
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SmartyCacheEntity that = (SmartyCacheEntity) o;
        return Objects.equals(idSmartyCache, that.idSmartyCache) &&
                Objects.equals(name, that.name) &&
                Objects.equals(cacheId, that.cacheId) &&
                Objects.equals(modified, that.modified) &&
                Objects.equals(content, that.content);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idSmartyCache, name, cacheId, modified, content);
    }
}
