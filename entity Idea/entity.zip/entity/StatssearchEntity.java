package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "statssearch", schema = "ps1761", catalog = "")
public class StatssearchEntity {
    private int idStatssearch;
    private int idShop;
    private int idShopGroup;
    private String keywords;
    private int results;
    private Timestamp dateAdd;

    @Id
    @Column(name = "id_statssearch", nullable = false)
    public int getIdStatssearch() {
        return idStatssearch;
    }

    public void setIdStatssearch(int idStatssearch) {
        this.idStatssearch = idStatssearch;
    }

    @Basic
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "id_shop_group", nullable = false)
    public int getIdShopGroup() {
        return idShopGroup;
    }

    public void setIdShopGroup(int idShopGroup) {
        this.idShopGroup = idShopGroup;
    }

    @Basic
    @Column(name = "keywords", nullable = false, length = 255)
    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    @Basic
    @Column(name = "results", nullable = false)
    public int getResults() {
        return results;
    }

    public void setResults(int results) {
        this.results = results;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StatssearchEntity that = (StatssearchEntity) o;
        return idStatssearch == that.idStatssearch &&
                idShop == that.idShop &&
                idShopGroup == that.idShopGroup &&
                results == that.results &&
                Objects.equals(keywords, that.keywords) &&
                Objects.equals(dateAdd, that.dateAdd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idStatssearch, idShop, idShopGroup, keywords, results, dateAdd);
    }
}
