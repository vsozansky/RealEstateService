package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "specific_price_priority", schema = "ps1761", catalog = "")
@IdClass(SpecificPricePriorityEntityPK.class)
public class SpecificPricePriorityEntity {
    private int idSpecificPricePriority;
    private int idProduct;
    private String priority;

    @Id
    @Column(name = "id_specific_price_priority", nullable = false)
    public int getIdSpecificPricePriority() {
        return idSpecificPricePriority;
    }

    public void setIdSpecificPricePriority(int idSpecificPricePriority) {
        this.idSpecificPricePriority = idSpecificPricePriority;
    }

    @Id
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Basic
    @Column(name = "priority", nullable = false, length = 80)
    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SpecificPricePriorityEntity that = (SpecificPricePriorityEntity) o;
        return idSpecificPricePriority == that.idSpecificPricePriority &&
                idProduct == that.idProduct &&
                Objects.equals(priority, that.priority);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idSpecificPricePriority, idProduct, priority);
    }
}
