package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "lang_shop", schema = "ps1761", catalog = "")
@IdClass(LangShopEntityPK.class)
public class LangShopEntity {
    private int idLang;
    private int idShop;

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LangShopEntity that = (LangShopEntity) o;
        return idLang == that.idLang &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idLang, idShop);
    }
}
