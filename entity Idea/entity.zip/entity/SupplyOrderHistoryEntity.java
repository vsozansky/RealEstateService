package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "supply_order_history", schema = "ps1761", catalog = "")
public class SupplyOrderHistoryEntity {
    private int idSupplyOrderHistory;
    private int idSupplyOrder;
    private int idEmployee;
    private String employeeLastname;
    private String employeeFirstname;
    private int idState;
    private Timestamp dateAdd;

    @Id
    @Column(name = "id_supply_order_history", nullable = false)
    public int getIdSupplyOrderHistory() {
        return idSupplyOrderHistory;
    }

    public void setIdSupplyOrderHistory(int idSupplyOrderHistory) {
        this.idSupplyOrderHistory = idSupplyOrderHistory;
    }

    @Basic
    @Column(name = "id_supply_order", nullable = false)
    public int getIdSupplyOrder() {
        return idSupplyOrder;
    }

    public void setIdSupplyOrder(int idSupplyOrder) {
        this.idSupplyOrder = idSupplyOrder;
    }

    @Basic
    @Column(name = "id_employee", nullable = false)
    public int getIdEmployee() {
        return idEmployee;
    }

    public void setIdEmployee(int idEmployee) {
        this.idEmployee = idEmployee;
    }

    @Basic
    @Column(name = "employee_lastname", nullable = true, length = 255)
    public String getEmployeeLastname() {
        return employeeLastname;
    }

    public void setEmployeeLastname(String employeeLastname) {
        this.employeeLastname = employeeLastname;
    }

    @Basic
    @Column(name = "employee_firstname", nullable = true, length = 255)
    public String getEmployeeFirstname() {
        return employeeFirstname;
    }

    public void setEmployeeFirstname(String employeeFirstname) {
        this.employeeFirstname = employeeFirstname;
    }

    @Basic
    @Column(name = "id_state", nullable = false)
    public int getIdState() {
        return idState;
    }

    public void setIdState(int idState) {
        this.idState = idState;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SupplyOrderHistoryEntity that = (SupplyOrderHistoryEntity) o;
        return idSupplyOrderHistory == that.idSupplyOrderHistory &&
                idSupplyOrder == that.idSupplyOrder &&
                idEmployee == that.idEmployee &&
                idState == that.idState &&
                Objects.equals(employeeLastname, that.employeeLastname) &&
                Objects.equals(employeeFirstname, that.employeeFirstname) &&
                Objects.equals(dateAdd, that.dateAdd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idSupplyOrderHistory, idSupplyOrder, idEmployee, employeeLastname, employeeFirstname, idState, dateAdd);
    }
}
