package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "order_history", schema = "ps1761", catalog = "")
public class OrderHistoryEntity {
    private int idOrderHistory;
    private int idEmployee;
    private int idOrder;
    private int idOrderState;
    private Timestamp dateAdd;

    @Id
    @Column(name = "id_order_history", nullable = false)
    public int getIdOrderHistory() {
        return idOrderHistory;
    }

    public void setIdOrderHistory(int idOrderHistory) {
        this.idOrderHistory = idOrderHistory;
    }

    @Basic
    @Column(name = "id_employee", nullable = false)
    public int getIdEmployee() {
        return idEmployee;
    }

    public void setIdEmployee(int idEmployee) {
        this.idEmployee = idEmployee;
    }

    @Basic
    @Column(name = "id_order", nullable = false)
    public int getIdOrder() {
        return idOrder;
    }

    public void setIdOrder(int idOrder) {
        this.idOrder = idOrder;
    }

    @Basic
    @Column(name = "id_order_state", nullable = false)
    public int getIdOrderState() {
        return idOrderState;
    }

    public void setIdOrderState(int idOrderState) {
        this.idOrderState = idOrderState;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderHistoryEntity that = (OrderHistoryEntity) o;
        return idOrderHistory == that.idOrderHistory &&
                idEmployee == that.idEmployee &&
                idOrder == that.idOrder &&
                idOrderState == that.idOrderState &&
                Objects.equals(dateAdd, that.dateAdd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrderHistory, idEmployee, idOrder, idOrderState, dateAdd);
    }
}
