package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class SmartyLazyCacheEntityPK implements Serializable {
    private String templateHash;
    private String cacheId;
    private String compileId;

    @Column(name = "template_hash", nullable = false, length = 32)
    @Id
    public String getTemplateHash() {
        return templateHash;
    }

    public void setTemplateHash(String templateHash) {
        this.templateHash = templateHash;
    }

    @Column(name = "cache_id", nullable = false, length = 255)
    @Id
    public String getCacheId() {
        return cacheId;
    }

    public void setCacheId(String cacheId) {
        this.cacheId = cacheId;
    }

    @Column(name = "compile_id", nullable = false, length = 32)
    @Id
    public String getCompileId() {
        return compileId;
    }

    public void setCompileId(String compileId) {
        this.compileId = compileId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SmartyLazyCacheEntityPK that = (SmartyLazyCacheEntityPK) o;
        return Objects.equals(templateHash, that.templateHash) &&
                Objects.equals(cacheId, that.cacheId) &&
                Objects.equals(compileId, that.compileId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(templateHash, cacheId, compileId);
    }
}
