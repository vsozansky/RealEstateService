package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "smarty_lazy_cache", schema = "ps1761", catalog = "")
@IdClass(SmartyLazyCacheEntityPK.class)
public class SmartyLazyCacheEntity {
    private String templateHash;
    private String cacheId;
    private String compileId;
    private String filepath;
    private Timestamp lastUpdate;

    @Id
    @Column(name = "template_hash", nullable = false, length = 32)
    public String getTemplateHash() {
        return templateHash;
    }

    public void setTemplateHash(String templateHash) {
        this.templateHash = templateHash;
    }

    @Id
    @Column(name = "cache_id", nullable = false, length = 255)
    public String getCacheId() {
        return cacheId;
    }

    public void setCacheId(String cacheId) {
        this.cacheId = cacheId;
    }

    @Id
    @Column(name = "compile_id", nullable = false, length = 32)
    public String getCompileId() {
        return compileId;
    }

    public void setCompileId(String compileId) {
        this.compileId = compileId;
    }

    @Basic
    @Column(name = "filepath", nullable = false, length = 255)
    public String getFilepath() {
        return filepath;
    }

    public void setFilepath(String filepath) {
        this.filepath = filepath;
    }

    @Basic
    @Column(name = "last_update", nullable = false)
    public Timestamp getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Timestamp lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SmartyLazyCacheEntity that = (SmartyLazyCacheEntity) o;
        return Objects.equals(templateHash, that.templateHash) &&
                Objects.equals(cacheId, that.cacheId) &&
                Objects.equals(compileId, that.compileId) &&
                Objects.equals(filepath, that.filepath) &&
                Objects.equals(lastUpdate, that.lastUpdate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(templateHash, cacheId, compileId, filepath, lastUpdate);
    }
}
