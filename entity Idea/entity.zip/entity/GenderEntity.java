package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "gender", schema = "ps1761", catalog = "")
public class GenderEntity {
    private int idGender;
    private byte type;

    @Id
    @Column(name = "id_gender", nullable = false)
    public int getIdGender() {
        return idGender;
    }

    public void setIdGender(int idGender) {
        this.idGender = idGender;
    }

    @Basic
    @Column(name = "type", nullable = false)
    public byte getType() {
        return type;
    }

    public void setType(byte type) {
        this.type = type;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GenderEntity that = (GenderEntity) o;
        return idGender == that.idGender &&
                type == that.type;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idGender, type);
    }
}
