package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "cart_cart_rule", schema = "ps1761", catalog = "")
@IdClass(CartCartRuleEntityPK.class)
public class CartCartRuleEntity {
    private int idCart;
    private int idCartRule;

    @Id
    @Column(name = "id_cart", nullable = false)
    public int getIdCart() {
        return idCart;
    }

    public void setIdCart(int idCart) {
        this.idCart = idCart;
    }

    @Id
    @Column(name = "id_cart_rule", nullable = false)
    public int getIdCartRule() {
        return idCartRule;
    }

    public void setIdCartRule(int idCartRule) {
        this.idCartRule = idCartRule;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CartCartRuleEntity that = (CartCartRuleEntity) o;
        return idCart == that.idCart &&
                idCartRule == that.idCartRule;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCart, idCartRule);
    }
}
