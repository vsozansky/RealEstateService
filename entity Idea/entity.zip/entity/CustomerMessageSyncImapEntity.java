package com.jprestashop.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Arrays;

@Entity
@Table(name = "customer_message_sync_imap", schema = "ps1761", catalog = "")
public class CustomerMessageSyncImapEntity {
    private byte[] md5Header;

    @Basic
    @Column(name = "md5_header", nullable = false)
    public byte[] getMd5Header() {
        return md5Header;
    }

    public void setMd5Header(byte[] md5Header) {
        this.md5Header = md5Header;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CustomerMessageSyncImapEntity that = (CustomerMessageSyncImapEntity) o;
        return Arrays.equals(md5Header, that.md5Header);
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(md5Header);
    }
}
