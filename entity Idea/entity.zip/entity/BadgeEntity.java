package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "badge", schema = "ps1761", catalog = "")
public class BadgeEntity {
    private int idBadge;
    private int idPsBadge;
    private String type;
    private int idGroup;
    private int groupPosition;
    private int scoring;
    private Integer awb;
    private byte validated;

    @Id
    @Column(name = "id_badge", nullable = false)
    public int getIdBadge() {
        return idBadge;
    }

    public void setIdBadge(int idBadge) {
        this.idBadge = idBadge;
    }

    @Basic
    @Column(name = "id_ps_badge", nullable = false)
    public int getIdPsBadge() {
        return idPsBadge;
    }

    public void setIdPsBadge(int idPsBadge) {
        this.idPsBadge = idPsBadge;
    }

    @Basic
    @Column(name = "type", nullable = false, length = 32)
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Basic
    @Column(name = "id_group", nullable = false)
    public int getIdGroup() {
        return idGroup;
    }

    public void setIdGroup(int idGroup) {
        this.idGroup = idGroup;
    }

    @Basic
    @Column(name = "group_position", nullable = false)
    public int getGroupPosition() {
        return groupPosition;
    }

    public void setGroupPosition(int groupPosition) {
        this.groupPosition = groupPosition;
    }

    @Basic
    @Column(name = "scoring", nullable = false)
    public int getScoring() {
        return scoring;
    }

    public void setScoring(int scoring) {
        this.scoring = scoring;
    }

    @Basic
    @Column(name = "awb", nullable = true)
    public Integer getAwb() {
        return awb;
    }

    public void setAwb(Integer awb) {
        this.awb = awb;
    }

    @Basic
    @Column(name = "validated", nullable = false)
    public byte getValidated() {
        return validated;
    }

    public void setValidated(byte validated) {
        this.validated = validated;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BadgeEntity that = (BadgeEntity) o;
        return idBadge == that.idBadge &&
                idPsBadge == that.idPsBadge &&
                idGroup == that.idGroup &&
                groupPosition == that.groupPosition &&
                scoring == that.scoring &&
                validated == that.validated &&
                Objects.equals(type, that.type) &&
                Objects.equals(awb, that.awb);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idBadge, idPsBadge, type, idGroup, groupPosition, scoring, awb, validated);
    }
}
