package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "guest", schema = "ps1761", catalog = "")
public class GuestEntity {
    private int idGuest;
    private Integer idOperatingSystem;
    private Integer idWebBrowser;
    private Integer idCustomer;
    private Byte javascript;
    private Short screenResolutionX;
    private Short screenResolutionY;
    private Byte screenColor;
    private Byte sunJava;
    private Byte adobeFlash;
    private Byte adobeDirector;
    private Byte appleQuicktime;
    private Byte realPlayer;
    private Byte windowsMedia;
    private String acceptLanguage;
    private byte mobileTheme;

    @Id
    @Column(name = "id_guest", nullable = false)
    public int getIdGuest() {
        return idGuest;
    }

    public void setIdGuest(int idGuest) {
        this.idGuest = idGuest;
    }

    @Basic
    @Column(name = "id_operating_system", nullable = true)
    public Integer getIdOperatingSystem() {
        return idOperatingSystem;
    }

    public void setIdOperatingSystem(Integer idOperatingSystem) {
        this.idOperatingSystem = idOperatingSystem;
    }

    @Basic
    @Column(name = "id_web_browser", nullable = true)
    public Integer getIdWebBrowser() {
        return idWebBrowser;
    }

    public void setIdWebBrowser(Integer idWebBrowser) {
        this.idWebBrowser = idWebBrowser;
    }

    @Basic
    @Column(name = "id_customer", nullable = true)
    public Integer getIdCustomer() {
        return idCustomer;
    }

    public void setIdCustomer(Integer idCustomer) {
        this.idCustomer = idCustomer;
    }

    @Basic
    @Column(name = "javascript", nullable = true)
    public Byte getJavascript() {
        return javascript;
    }

    public void setJavascript(Byte javascript) {
        this.javascript = javascript;
    }

    @Basic
    @Column(name = "screen_resolution_x", nullable = true)
    public Short getScreenResolutionX() {
        return screenResolutionX;
    }

    public void setScreenResolutionX(Short screenResolutionX) {
        this.screenResolutionX = screenResolutionX;
    }

    @Basic
    @Column(name = "screen_resolution_y", nullable = true)
    public Short getScreenResolutionY() {
        return screenResolutionY;
    }

    public void setScreenResolutionY(Short screenResolutionY) {
        this.screenResolutionY = screenResolutionY;
    }

    @Basic
    @Column(name = "screen_color", nullable = true)
    public Byte getScreenColor() {
        return screenColor;
    }

    public void setScreenColor(Byte screenColor) {
        this.screenColor = screenColor;
    }

    @Basic
    @Column(name = "sun_java", nullable = true)
    public Byte getSunJava() {
        return sunJava;
    }

    public void setSunJava(Byte sunJava) {
        this.sunJava = sunJava;
    }

    @Basic
    @Column(name = "adobe_flash", nullable = true)
    public Byte getAdobeFlash() {
        return adobeFlash;
    }

    public void setAdobeFlash(Byte adobeFlash) {
        this.adobeFlash = adobeFlash;
    }

    @Basic
    @Column(name = "adobe_director", nullable = true)
    public Byte getAdobeDirector() {
        return adobeDirector;
    }

    public void setAdobeDirector(Byte adobeDirector) {
        this.adobeDirector = adobeDirector;
    }

    @Basic
    @Column(name = "apple_quicktime", nullable = true)
    public Byte getAppleQuicktime() {
        return appleQuicktime;
    }

    public void setAppleQuicktime(Byte appleQuicktime) {
        this.appleQuicktime = appleQuicktime;
    }

    @Basic
    @Column(name = "real_player", nullable = true)
    public Byte getRealPlayer() {
        return realPlayer;
    }

    public void setRealPlayer(Byte realPlayer) {
        this.realPlayer = realPlayer;
    }

    @Basic
    @Column(name = "windows_media", nullable = true)
    public Byte getWindowsMedia() {
        return windowsMedia;
    }

    public void setWindowsMedia(Byte windowsMedia) {
        this.windowsMedia = windowsMedia;
    }

    @Basic
    @Column(name = "accept_language", nullable = true, length = 8)
    public String getAcceptLanguage() {
        return acceptLanguage;
    }

    public void setAcceptLanguage(String acceptLanguage) {
        this.acceptLanguage = acceptLanguage;
    }

    @Basic
    @Column(name = "mobile_theme", nullable = false)
    public byte getMobileTheme() {
        return mobileTheme;
    }

    public void setMobileTheme(byte mobileTheme) {
        this.mobileTheme = mobileTheme;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GuestEntity that = (GuestEntity) o;
        return idGuest == that.idGuest &&
                mobileTheme == that.mobileTheme &&
                Objects.equals(idOperatingSystem, that.idOperatingSystem) &&
                Objects.equals(idWebBrowser, that.idWebBrowser) &&
                Objects.equals(idCustomer, that.idCustomer) &&
                Objects.equals(javascript, that.javascript) &&
                Objects.equals(screenResolutionX, that.screenResolutionX) &&
                Objects.equals(screenResolutionY, that.screenResolutionY) &&
                Objects.equals(screenColor, that.screenColor) &&
                Objects.equals(sunJava, that.sunJava) &&
                Objects.equals(adobeFlash, that.adobeFlash) &&
                Objects.equals(adobeDirector, that.adobeDirector) &&
                Objects.equals(appleQuicktime, that.appleQuicktime) &&
                Objects.equals(realPlayer, that.realPlayer) &&
                Objects.equals(windowsMedia, that.windowsMedia) &&
                Objects.equals(acceptLanguage, that.acceptLanguage);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idGuest, idOperatingSystem, idWebBrowser, idCustomer, javascript, screenResolutionX, screenResolutionY, screenColor, sunJava, adobeFlash, adobeDirector, appleQuicktime, realPlayer, windowsMedia, acceptLanguage, mobileTheme);
    }
}
