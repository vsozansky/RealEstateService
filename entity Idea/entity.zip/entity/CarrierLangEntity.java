package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "carrier_lang", schema = "ps1761", catalog = "")
@IdClass(CarrierLangEntityPK.class)
public class CarrierLangEntity {
    private int idCarrier;
    private int idShop;
    private int idLang;
    private String delay;

    @Id
    @Column(name = "id_carrier", nullable = false)
    public int getIdCarrier() {
        return idCarrier;
    }

    public void setIdCarrier(int idCarrier) {
        this.idCarrier = idCarrier;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "delay", nullable = true, length = 512)
    public String getDelay() {
        return delay;
    }

    public void setDelay(String delay) {
        this.delay = delay;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CarrierLangEntity that = (CarrierLangEntity) o;
        return idCarrier == that.idCarrier &&
                idShop == that.idShop &&
                idLang == that.idLang &&
                Objects.equals(delay, that.delay);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCarrier, idShop, idLang, delay);
    }
}
