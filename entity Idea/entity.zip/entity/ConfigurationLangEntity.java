package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "configuration_lang", schema = "ps1761", catalog = "")
@IdClass(ConfigurationLangEntityPK.class)
public class ConfigurationLangEntity {
    private int idConfiguration;
    private int idLang;
    private String value;
    private Timestamp dateUpd;

    @Id
    @Column(name = "id_configuration", nullable = false)
    public int getIdConfiguration() {
        return idConfiguration;
    }

    public void setIdConfiguration(int idConfiguration) {
        this.idConfiguration = idConfiguration;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "value", nullable = true, length = -1)
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Basic
    @Column(name = "date_upd", nullable = true)
    public Timestamp getDateUpd() {
        return dateUpd;
    }

    public void setDateUpd(Timestamp dateUpd) {
        this.dateUpd = dateUpd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ConfigurationLangEntity that = (ConfigurationLangEntity) o;
        return idConfiguration == that.idConfiguration &&
                idLang == that.idLang &&
                Objects.equals(value, that.value) &&
                Objects.equals(dateUpd, that.dateUpd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idConfiguration, idLang, value, dateUpd);
    }
}
