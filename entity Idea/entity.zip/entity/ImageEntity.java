package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "image", schema = "ps1761", catalog = "")
public class ImageEntity {
    private int idImage;
    private int idProduct;
    private short position;
    private Byte cover;

    @Id
    @Column(name = "id_image", nullable = false)
    public int getIdImage() {
        return idImage;
    }

    public void setIdImage(int idImage) {
        this.idImage = idImage;
    }

    @Basic
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Basic
    @Column(name = "position", nullable = false)
    public short getPosition() {
        return position;
    }

    public void setPosition(short position) {
        this.position = position;
    }

    @Basic
    @Column(name = "cover", nullable = true)
    public Byte getCover() {
        return cover;
    }

    public void setCover(Byte cover) {
        this.cover = cover;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ImageEntity that = (ImageEntity) o;
        return idImage == that.idImage &&
                idProduct == that.idProduct &&
                position == that.position &&
                Objects.equals(cover, that.cover);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idImage, idProduct, position, cover);
    }
}
