package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "required_field", schema = "ps1761", catalog = "")
public class RequiredFieldEntity {
    private int idRequiredField;
    private String objectName;
    private String fieldName;

    @Id
    @Column(name = "id_required_field", nullable = false)
    public int getIdRequiredField() {
        return idRequiredField;
    }

    public void setIdRequiredField(int idRequiredField) {
        this.idRequiredField = idRequiredField;
    }

    @Basic
    @Column(name = "object_name", nullable = false, length = 32)
    public String getObjectName() {
        return objectName;
    }

    public void setObjectName(String objectName) {
        this.objectName = objectName;
    }

    @Basic
    @Column(name = "field_name", nullable = false, length = 32)
    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RequiredFieldEntity that = (RequiredFieldEntity) o;
        return idRequiredField == that.idRequiredField &&
                Objects.equals(objectName, that.objectName) &&
                Objects.equals(fieldName, that.fieldName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idRequiredField, objectName, fieldName);
    }
}
