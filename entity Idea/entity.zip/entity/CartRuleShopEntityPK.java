package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class CartRuleShopEntityPK implements Serializable {
    private int idCartRule;
    private int idShop;

    @Column(name = "id_cart_rule", nullable = false)
    @Id
    public int getIdCartRule() {
        return idCartRule;
    }

    public void setIdCartRule(int idCartRule) {
        this.idCartRule = idCartRule;
    }

    @Column(name = "id_shop", nullable = false)
    @Id
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CartRuleShopEntityPK that = (CartRuleShopEntityPK) o;
        return idCartRule == that.idCartRule &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCartRule, idShop);
    }
}
