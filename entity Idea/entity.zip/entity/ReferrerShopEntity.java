package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name = "referrer_shop", schema = "ps1761", catalog = "")
@IdClass(ReferrerShopEntityPK.class)
public class ReferrerShopEntity {
    private int idReferrer;
    private int idShop;
    private Integer cacheVisitors;
    private Integer cacheVisits;
    private Integer cachePages;
    private Integer cacheRegistrations;
    private Integer cacheOrders;
    private BigDecimal cacheSales;
    private BigDecimal cacheRegRate;
    private BigDecimal cacheOrderRate;

    @Id
    @Column(name = "id_referrer", nullable = false)
    public int getIdReferrer() {
        return idReferrer;
    }

    public void setIdReferrer(int idReferrer) {
        this.idReferrer = idReferrer;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "cache_visitors", nullable = true)
    public Integer getCacheVisitors() {
        return cacheVisitors;
    }

    public void setCacheVisitors(Integer cacheVisitors) {
        this.cacheVisitors = cacheVisitors;
    }

    @Basic
    @Column(name = "cache_visits", nullable = true)
    public Integer getCacheVisits() {
        return cacheVisits;
    }

    public void setCacheVisits(Integer cacheVisits) {
        this.cacheVisits = cacheVisits;
    }

    @Basic
    @Column(name = "cache_pages", nullable = true)
    public Integer getCachePages() {
        return cachePages;
    }

    public void setCachePages(Integer cachePages) {
        this.cachePages = cachePages;
    }

    @Basic
    @Column(name = "cache_registrations", nullable = true)
    public Integer getCacheRegistrations() {
        return cacheRegistrations;
    }

    public void setCacheRegistrations(Integer cacheRegistrations) {
        this.cacheRegistrations = cacheRegistrations;
    }

    @Basic
    @Column(name = "cache_orders", nullable = true)
    public Integer getCacheOrders() {
        return cacheOrders;
    }

    public void setCacheOrders(Integer cacheOrders) {
        this.cacheOrders = cacheOrders;
    }

    @Basic
    @Column(name = "cache_sales", nullable = true, precision = 2)
    public BigDecimal getCacheSales() {
        return cacheSales;
    }

    public void setCacheSales(BigDecimal cacheSales) {
        this.cacheSales = cacheSales;
    }

    @Basic
    @Column(name = "cache_reg_rate", nullable = true, precision = 4)
    public BigDecimal getCacheRegRate() {
        return cacheRegRate;
    }

    public void setCacheRegRate(BigDecimal cacheRegRate) {
        this.cacheRegRate = cacheRegRate;
    }

    @Basic
    @Column(name = "cache_order_rate", nullable = true, precision = 4)
    public BigDecimal getCacheOrderRate() {
        return cacheOrderRate;
    }

    public void setCacheOrderRate(BigDecimal cacheOrderRate) {
        this.cacheOrderRate = cacheOrderRate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ReferrerShopEntity that = (ReferrerShopEntity) o;
        return idReferrer == that.idReferrer &&
                idShop == that.idShop &&
                Objects.equals(cacheVisitors, that.cacheVisitors) &&
                Objects.equals(cacheVisits, that.cacheVisits) &&
                Objects.equals(cachePages, that.cachePages) &&
                Objects.equals(cacheRegistrations, that.cacheRegistrations) &&
                Objects.equals(cacheOrders, that.cacheOrders) &&
                Objects.equals(cacheSales, that.cacheSales) &&
                Objects.equals(cacheRegRate, that.cacheRegRate) &&
                Objects.equals(cacheOrderRate, that.cacheOrderRate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idReferrer, idShop, cacheVisitors, cacheVisits, cachePages, cacheRegistrations, cacheOrders, cacheSales, cacheRegRate, cacheOrderRate);
    }
}
