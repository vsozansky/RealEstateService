package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "attachment", schema = "ps1761", catalog = "")
public class AttachmentEntity {
    private int idAttachment;
    private String file;
    private String fileName;
    private long fileSize;
    private String mime;

    @Id
    @Column(name = "id_attachment", nullable = false)
    public int getIdAttachment() {
        return idAttachment;
    }

    public void setIdAttachment(int idAttachment) {
        this.idAttachment = idAttachment;
    }

    @Basic
    @Column(name = "file", nullable = false, length = 40)
    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    @Basic
    @Column(name = "file_name", nullable = false, length = 128)
    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    @Basic
    @Column(name = "file_size", nullable = false)
    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    @Basic
    @Column(name = "mime", nullable = false, length = 128)
    public String getMime() {
        return mime;
    }

    public void setMime(String mime) {
        this.mime = mime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AttachmentEntity that = (AttachmentEntity) o;
        return idAttachment == that.idAttachment &&
                fileSize == that.fileSize &&
                Objects.equals(file, that.file) &&
                Objects.equals(fileName, that.fileName) &&
                Objects.equals(mime, that.mime);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAttachment, file, fileName, fileSize, mime);
    }
}
