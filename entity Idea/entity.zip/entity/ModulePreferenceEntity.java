package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "module_preference", schema = "ps1761", catalog = "")
public class ModulePreferenceEntity {
    private int idModulePreference;
    private int idEmployee;
    private String module;
    private Byte interest;
    private Byte favorite;

    @Id
    @Column(name = "id_module_preference", nullable = false)
    public int getIdModulePreference() {
        return idModulePreference;
    }

    public void setIdModulePreference(int idModulePreference) {
        this.idModulePreference = idModulePreference;
    }

    @Basic
    @Column(name = "id_employee", nullable = false)
    public int getIdEmployee() {
        return idEmployee;
    }

    public void setIdEmployee(int idEmployee) {
        this.idEmployee = idEmployee;
    }

    @Basic
    @Column(name = "module", nullable = false, length = 255)
    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    @Basic
    @Column(name = "interest", nullable = true)
    public Byte getInterest() {
        return interest;
    }

    public void setInterest(Byte interest) {
        this.interest = interest;
    }

    @Basic
    @Column(name = "favorite", nullable = true)
    public Byte getFavorite() {
        return favorite;
    }

    public void setFavorite(Byte favorite) {
        this.favorite = favorite;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ModulePreferenceEntity that = (ModulePreferenceEntity) o;
        return idModulePreference == that.idModulePreference &&
                idEmployee == that.idEmployee &&
                Objects.equals(module, that.module) &&
                Objects.equals(interest, that.interest) &&
                Objects.equals(favorite, that.favorite);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idModulePreference, idEmployee, module, interest, favorite);
    }
}
