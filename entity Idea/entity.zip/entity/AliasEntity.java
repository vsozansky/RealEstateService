package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "alias", schema = "ps1761", catalog = "")
public class AliasEntity {
    private int idAlias;
    private String alias;
    private String search;
    private byte active;

    @Id
    @Column(name = "id_alias", nullable = false)
    public int getIdAlias() {
        return idAlias;
    }

    public void setIdAlias(int idAlias) {
        this.idAlias = idAlias;
    }

    @Basic
    @Column(name = "alias", nullable = false, length = 255)
    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    @Basic
    @Column(name = "search", nullable = false, length = 255)
    public String getSearch() {
        return search;
    }

    public void setSearch(String search) {
        this.search = search;
    }

    @Basic
    @Column(name = "active", nullable = false)
    public byte getActive() {
        return active;
    }

    public void setActive(byte active) {
        this.active = active;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AliasEntity that = (AliasEntity) o;
        return idAlias == that.idAlias &&
                active == that.active &&
                Objects.equals(alias, that.alias) &&
                Objects.equals(search, that.search);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAlias, alias, search, active);
    }
}
