package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "psgdpr_consent", schema = "ps1761", catalog = "")
@IdClass(PsgdprConsentEntityPK.class)
public class PsgdprConsentEntity {
    private int idGdprConsent;
    private int idModule;
    private int active;
    private Integer error;
    private String errorMessage;
    private Timestamp dateAdd;
    private Timestamp dateUpd;

    @Id
    @Column(name = "id_gdpr_consent", nullable = false)
    public int getIdGdprConsent() {
        return idGdprConsent;
    }

    public void setIdGdprConsent(int idGdprConsent) {
        this.idGdprConsent = idGdprConsent;
    }

    @Id
    @Column(name = "id_module", nullable = false)
    public int getIdModule() {
        return idModule;
    }

    public void setIdModule(int idModule) {
        this.idModule = idModule;
    }

    @Basic
    @Column(name = "active", nullable = false)
    public int getActive() {
        return active;
    }

    public void setActive(int active) {
        this.active = active;
    }

    @Basic
    @Column(name = "error", nullable = true)
    public Integer getError() {
        return error;
    }

    public void setError(Integer error) {
        this.error = error;
    }

    @Basic
    @Column(name = "error_message", nullable = true, length = -1)
    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Basic
    @Column(name = "date_upd", nullable = false)
    public Timestamp getDateUpd() {
        return dateUpd;
    }

    public void setDateUpd(Timestamp dateUpd) {
        this.dateUpd = dateUpd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PsgdprConsentEntity that = (PsgdprConsentEntity) o;
        return idGdprConsent == that.idGdprConsent &&
                idModule == that.idModule &&
                active == that.active &&
                Objects.equals(error, that.error) &&
                Objects.equals(errorMessage, that.errorMessage) &&
                Objects.equals(dateAdd, that.dateAdd) &&
                Objects.equals(dateUpd, that.dateUpd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idGdprConsent, idModule, active, error, errorMessage, dateAdd, dateUpd);
    }
}
