package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class SpecificPricePriorityEntityPK implements Serializable {
    private int idSpecificPricePriority;
    private int idProduct;

    @Column(name = "id_specific_price_priority", nullable = false)
    @Id
    public int getIdSpecificPricePriority() {
        return idSpecificPricePriority;
    }

    public void setIdSpecificPricePriority(int idSpecificPricePriority) {
        this.idSpecificPricePriority = idSpecificPricePriority;
    }

    @Column(name = "id_product", nullable = false)
    @Id
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SpecificPricePriorityEntityPK that = (SpecificPricePriorityEntityPK) o;
        return idSpecificPricePriority == that.idSpecificPricePriority &&
                idProduct == that.idProduct;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idSpecificPricePriority, idProduct);
    }
}
