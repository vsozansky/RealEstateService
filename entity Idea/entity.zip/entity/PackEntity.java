package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "pack", schema = "ps1761", catalog = "")
@IdClass(PackEntityPK.class)
public class PackEntity {
    private int idProductPack;
    private int idProductItem;
    private int idProductAttributeItem;
    private int quantity;

    @Id
    @Column(name = "id_product_pack", nullable = false)
    public int getIdProductPack() {
        return idProductPack;
    }

    public void setIdProductPack(int idProductPack) {
        this.idProductPack = idProductPack;
    }

    @Id
    @Column(name = "id_product_item", nullable = false)
    public int getIdProductItem() {
        return idProductItem;
    }

    public void setIdProductItem(int idProductItem) {
        this.idProductItem = idProductItem;
    }

    @Id
    @Column(name = "id_product_attribute_item", nullable = false)
    public int getIdProductAttributeItem() {
        return idProductAttributeItem;
    }

    public void setIdProductAttributeItem(int idProductAttributeItem) {
        this.idProductAttributeItem = idProductAttributeItem;
    }

    @Basic
    @Column(name = "quantity", nullable = false)
    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PackEntity that = (PackEntity) o;
        return idProductPack == that.idProductPack &&
                idProductItem == that.idProductItem &&
                idProductAttributeItem == that.idProductAttributeItem &&
                quantity == that.quantity;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProductPack, idProductItem, idProductAttributeItem, quantity);
    }
}
