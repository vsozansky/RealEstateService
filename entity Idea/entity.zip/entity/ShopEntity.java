package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "shop", schema = "ps1761", catalog = "")
public class ShopEntity {
    private int idShop;
    private int idShopGroup;
    private String name;
    private int idCategory;
    private String themeName;
    private byte active;
    private byte deleted;

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "id_shop_group", nullable = false)
    public int getIdShopGroup() {
        return idShopGroup;
    }

    public void setIdShopGroup(int idShopGroup) {
        this.idShopGroup = idShopGroup;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 64)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "id_category", nullable = false)
    public int getIdCategory() {
        return idCategory;
    }

    public void setIdCategory(int idCategory) {
        this.idCategory = idCategory;
    }

    @Basic
    @Column(name = "theme_name", nullable = false, length = 255)
    public String getThemeName() {
        return themeName;
    }

    public void setThemeName(String themeName) {
        this.themeName = themeName;
    }

    @Basic
    @Column(name = "active", nullable = false)
    public byte getActive() {
        return active;
    }

    public void setActive(byte active) {
        this.active = active;
    }

    @Basic
    @Column(name = "deleted", nullable = false)
    public byte getDeleted() {
        return deleted;
    }

    public void setDeleted(byte deleted) {
        this.deleted = deleted;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ShopEntity that = (ShopEntity) o;
        return idShop == that.idShop &&
                idShopGroup == that.idShopGroup &&
                idCategory == that.idCategory &&
                active == that.active &&
                deleted == that.deleted &&
                Objects.equals(name, that.name) &&
                Objects.equals(themeName, that.themeName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idShop, idShopGroup, name, idCategory, themeName, active, deleted);
    }
}
