package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class CartCartRuleEntityPK implements Serializable {
    private int idCart;
    private int idCartRule;

    @Column(name = "id_cart", nullable = false)
    @Id
    public int getIdCart() {
        return idCart;
    }

    public void setIdCart(int idCart) {
        this.idCart = idCart;
    }

    @Column(name = "id_cart_rule", nullable = false)
    @Id
    public int getIdCartRule() {
        return idCartRule;
    }

    public void setIdCartRule(int idCartRule) {
        this.idCartRule = idCartRule;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CartCartRuleEntityPK that = (CartCartRuleEntityPK) o;
        return idCart == that.idCart &&
                idCartRule == that.idCartRule;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCart, idCartRule);
    }
}
