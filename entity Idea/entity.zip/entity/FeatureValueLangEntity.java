package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "feature_value_lang", schema = "ps1761", catalog = "")
@IdClass(FeatureValueLangEntityPK.class)
public class FeatureValueLangEntity {
    private int idFeatureValue;
    private int idLang;
    private String value;

    @Id
    @Column(name = "id_feature_value", nullable = false)
    public int getIdFeatureValue() {
        return idFeatureValue;
    }

    public void setIdFeatureValue(int idFeatureValue) {
        this.idFeatureValue = idFeatureValue;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "value", nullable = true, length = 255)
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FeatureValueLangEntity that = (FeatureValueLangEntity) o;
        return idFeatureValue == that.idFeatureValue &&
                idLang == that.idLang &&
                Objects.equals(value, that.value);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idFeatureValue, idLang, value);
    }
}
