package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class CarrierTaxRulesGroupShopEntityPK implements Serializable {
    private int idCarrier;
    private int idTaxRulesGroup;
    private int idShop;

    @Column(name = "id_carrier", nullable = false)
    @Id
    public int getIdCarrier() {
        return idCarrier;
    }

    public void setIdCarrier(int idCarrier) {
        this.idCarrier = idCarrier;
    }

    @Column(name = "id_tax_rules_group", nullable = false)
    @Id
    public int getIdTaxRulesGroup() {
        return idTaxRulesGroup;
    }

    public void setIdTaxRulesGroup(int idTaxRulesGroup) {
        this.idTaxRulesGroup = idTaxRulesGroup;
    }

    @Column(name = "id_shop", nullable = false)
    @Id
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CarrierTaxRulesGroupShopEntityPK that = (CarrierTaxRulesGroupShopEntityPK) o;
        return idCarrier == that.idCarrier &&
                idTaxRulesGroup == that.idTaxRulesGroup &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCarrier, idTaxRulesGroup, idShop);
    }
}
