package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "product_shop", schema = "ps1761", catalog = "")
@IdClass(ProductShopEntityPK.class)
public class ProductShopEntity {
    private int idProduct;
    private int idShop;
    private Integer idCategoryDefault;
    private int idTaxRulesGroup;
    private byte onSale;
    private byte onlineOnly;
    private BigDecimal ecotax;
    private int minimalQuantity;
    private Integer lowStockThreshold;
    private byte lowStockAlert;
    private BigDecimal price;
    private BigDecimal wholesalePrice;
    private String unity;
    private BigDecimal unitPriceRatio;
    private BigDecimal additionalShippingCost;
    private byte customizable;
    private byte uploadableFiles;
    private byte textFields;
    private byte active;
    private Object redirectType;
    private int idTypeRedirected;
    private byte availableForOrder;
    private Date availableDate;
    private byte showCondition;
    private Object condition;
    private byte showPrice;
    private byte indexed;
    private Object visibility;
    private Integer cacheDefaultAttribute;
    private byte advancedStockManagement;
    private Timestamp dateAdd;
    private Timestamp dateUpd;
    private int packStockType;

    @Id
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "id_category_default", nullable = true)
    public Integer getIdCategoryDefault() {
        return idCategoryDefault;
    }

    public void setIdCategoryDefault(Integer idCategoryDefault) {
        this.idCategoryDefault = idCategoryDefault;
    }

    @Basic
    @Column(name = "id_tax_rules_group", nullable = false)
    public int getIdTaxRulesGroup() {
        return idTaxRulesGroup;
    }

    public void setIdTaxRulesGroup(int idTaxRulesGroup) {
        this.idTaxRulesGroup = idTaxRulesGroup;
    }

    @Basic
    @Column(name = "on_sale", nullable = false)
    public byte getOnSale() {
        return onSale;
    }

    public void setOnSale(byte onSale) {
        this.onSale = onSale;
    }

    @Basic
    @Column(name = "online_only", nullable = false)
    public byte getOnlineOnly() {
        return onlineOnly;
    }

    public void setOnlineOnly(byte onlineOnly) {
        this.onlineOnly = onlineOnly;
    }

    @Basic
    @Column(name = "ecotax", nullable = false, precision = 6)
    public BigDecimal getEcotax() {
        return ecotax;
    }

    public void setEcotax(BigDecimal ecotax) {
        this.ecotax = ecotax;
    }

    @Basic
    @Column(name = "minimal_quantity", nullable = false)
    public int getMinimalQuantity() {
        return minimalQuantity;
    }

    public void setMinimalQuantity(int minimalQuantity) {
        this.minimalQuantity = minimalQuantity;
    }

    @Basic
    @Column(name = "low_stock_threshold", nullable = true)
    public Integer getLowStockThreshold() {
        return lowStockThreshold;
    }

    public void setLowStockThreshold(Integer lowStockThreshold) {
        this.lowStockThreshold = lowStockThreshold;
    }

    @Basic
    @Column(name = "low_stock_alert", nullable = false)
    public byte getLowStockAlert() {
        return lowStockAlert;
    }

    public void setLowStockAlert(byte lowStockAlert) {
        this.lowStockAlert = lowStockAlert;
    }

    @Basic
    @Column(name = "price", nullable = false, precision = 6)
    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    @Basic
    @Column(name = "wholesale_price", nullable = false, precision = 6)
    public BigDecimal getWholesalePrice() {
        return wholesalePrice;
    }

    public void setWholesalePrice(BigDecimal wholesalePrice) {
        this.wholesalePrice = wholesalePrice;
    }

    @Basic
    @Column(name = "unity", nullable = true, length = 255)
    public String getUnity() {
        return unity;
    }

    public void setUnity(String unity) {
        this.unity = unity;
    }

    @Basic
    @Column(name = "unit_price_ratio", nullable = false, precision = 6)
    public BigDecimal getUnitPriceRatio() {
        return unitPriceRatio;
    }

    public void setUnitPriceRatio(BigDecimal unitPriceRatio) {
        this.unitPriceRatio = unitPriceRatio;
    }

    @Basic
    @Column(name = "additional_shipping_cost", nullable = false, precision = 2)
    public BigDecimal getAdditionalShippingCost() {
        return additionalShippingCost;
    }

    public void setAdditionalShippingCost(BigDecimal additionalShippingCost) {
        this.additionalShippingCost = additionalShippingCost;
    }

    @Basic
    @Column(name = "customizable", nullable = false)
    public byte getCustomizable() {
        return customizable;
    }

    public void setCustomizable(byte customizable) {
        this.customizable = customizable;
    }

    @Basic
    @Column(name = "uploadable_files", nullable = false)
    public byte getUploadableFiles() {
        return uploadableFiles;
    }

    public void setUploadableFiles(byte uploadableFiles) {
        this.uploadableFiles = uploadableFiles;
    }

    @Basic
    @Column(name = "text_fields", nullable = false)
    public byte getTextFields() {
        return textFields;
    }

    public void setTextFields(byte textFields) {
        this.textFields = textFields;
    }

    @Basic
    @Column(name = "active", nullable = false)
    public byte getActive() {
        return active;
    }

    public void setActive(byte active) {
        this.active = active;
    }

    @Basic
    @Column(name = "redirect_type", nullable = false)
    public Object getRedirectType() {
        return redirectType;
    }

    public void setRedirectType(Object redirectType) {
        this.redirectType = redirectType;
    }

    @Basic
    @Column(name = "id_type_redirected", nullable = false)
    public int getIdTypeRedirected() {
        return idTypeRedirected;
    }

    public void setIdTypeRedirected(int idTypeRedirected) {
        this.idTypeRedirected = idTypeRedirected;
    }

    @Basic
    @Column(name = "available_for_order", nullable = false)
    public byte getAvailableForOrder() {
        return availableForOrder;
    }

    public void setAvailableForOrder(byte availableForOrder) {
        this.availableForOrder = availableForOrder;
    }

    @Basic
    @Column(name = "available_date", nullable = true)
    public Date getAvailableDate() {
        return availableDate;
    }

    public void setAvailableDate(Date availableDate) {
        this.availableDate = availableDate;
    }

    @Basic
    @Column(name = "show_condition", nullable = false)
    public byte getShowCondition() {
        return showCondition;
    }

    public void setShowCondition(byte showCondition) {
        this.showCondition = showCondition;
    }

    @Basic
    @Column(name = "condition", nullable = false)
    public Object getCondition() {
        return condition;
    }

    public void setCondition(Object condition) {
        this.condition = condition;
    }

    @Basic
    @Column(name = "show_price", nullable = false)
    public byte getShowPrice() {
        return showPrice;
    }

    public void setShowPrice(byte showPrice) {
        this.showPrice = showPrice;
    }

    @Basic
    @Column(name = "indexed", nullable = false)
    public byte getIndexed() {
        return indexed;
    }

    public void setIndexed(byte indexed) {
        this.indexed = indexed;
    }

    @Basic
    @Column(name = "visibility", nullable = false)
    public Object getVisibility() {
        return visibility;
    }

    public void setVisibility(Object visibility) {
        this.visibility = visibility;
    }

    @Basic
    @Column(name = "cache_default_attribute", nullable = true)
    public Integer getCacheDefaultAttribute() {
        return cacheDefaultAttribute;
    }

    public void setCacheDefaultAttribute(Integer cacheDefaultAttribute) {
        this.cacheDefaultAttribute = cacheDefaultAttribute;
    }

    @Basic
    @Column(name = "advanced_stock_management", nullable = false)
    public byte getAdvancedStockManagement() {
        return advancedStockManagement;
    }

    public void setAdvancedStockManagement(byte advancedStockManagement) {
        this.advancedStockManagement = advancedStockManagement;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Basic
    @Column(name = "date_upd", nullable = false)
    public Timestamp getDateUpd() {
        return dateUpd;
    }

    public void setDateUpd(Timestamp dateUpd) {
        this.dateUpd = dateUpd;
    }

    @Basic
    @Column(name = "pack_stock_type", nullable = false)
    public int getPackStockType() {
        return packStockType;
    }

    public void setPackStockType(int packStockType) {
        this.packStockType = packStockType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductShopEntity that = (ProductShopEntity) o;
        return idProduct == that.idProduct &&
                idShop == that.idShop &&
                idTaxRulesGroup == that.idTaxRulesGroup &&
                onSale == that.onSale &&
                onlineOnly == that.onlineOnly &&
                minimalQuantity == that.minimalQuantity &&
                lowStockAlert == that.lowStockAlert &&
                customizable == that.customizable &&
                uploadableFiles == that.uploadableFiles &&
                textFields == that.textFields &&
                active == that.active &&
                idTypeRedirected == that.idTypeRedirected &&
                availableForOrder == that.availableForOrder &&
                showCondition == that.showCondition &&
                showPrice == that.showPrice &&
                indexed == that.indexed &&
                advancedStockManagement == that.advancedStockManagement &&
                packStockType == that.packStockType &&
                Objects.equals(idCategoryDefault, that.idCategoryDefault) &&
                Objects.equals(ecotax, that.ecotax) &&
                Objects.equals(lowStockThreshold, that.lowStockThreshold) &&
                Objects.equals(price, that.price) &&
                Objects.equals(wholesalePrice, that.wholesalePrice) &&
                Objects.equals(unity, that.unity) &&
                Objects.equals(unitPriceRatio, that.unitPriceRatio) &&
                Objects.equals(additionalShippingCost, that.additionalShippingCost) &&
                Objects.equals(redirectType, that.redirectType) &&
                Objects.equals(availableDate, that.availableDate) &&
                Objects.equals(condition, that.condition) &&
                Objects.equals(visibility, that.visibility) &&
                Objects.equals(cacheDefaultAttribute, that.cacheDefaultAttribute) &&
                Objects.equals(dateAdd, that.dateAdd) &&
                Objects.equals(dateUpd, that.dateUpd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProduct, idShop, idCategoryDefault, idTaxRulesGroup, onSale, onlineOnly, ecotax, minimalQuantity, lowStockThreshold, lowStockAlert, price, wholesalePrice, unity, unitPriceRatio, additionalShippingCost, customizable, uploadableFiles, textFields, active, redirectType, idTypeRedirected, availableForOrder, availableDate, showCondition, condition, showPrice, indexed, visibility, cacheDefaultAttribute, advancedStockManagement, dateAdd, dateUpd, packStockType);
    }
}
