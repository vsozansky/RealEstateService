package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "layered_filter_block", schema = "ps1761", catalog = "")
public class LayeredFilterBlockEntity {
    private String hash;
    private String data;

    @Id
    @Column(name = "hash", nullable = false, length = 32)
    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    @Basic
    @Column(name = "data", nullable = true, length = -1)
    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LayeredFilterBlockEntity that = (LayeredFilterBlockEntity) o;
        return Objects.equals(hash, that.hash) &&
                Objects.equals(data, that.data);
    }

    @Override
    public int hashCode() {
        return Objects.hash(hash, data);
    }
}
