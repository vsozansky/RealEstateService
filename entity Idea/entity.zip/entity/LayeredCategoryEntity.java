package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "layered_category", schema = "ps1761", catalog = "")
public class LayeredCategoryEntity {
    private int idLayeredCategory;
    private int idShop;
    private int idCategory;
    private Integer idValue;
    private Object type;
    private int position;
    private int filterType;
    private int filterShowLimit;

    @Id
    @Column(name = "id_layered_category", nullable = false)
    public int getIdLayeredCategory() {
        return idLayeredCategory;
    }

    public void setIdLayeredCategory(int idLayeredCategory) {
        this.idLayeredCategory = idLayeredCategory;
    }

    @Basic
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "id_category", nullable = false)
    public int getIdCategory() {
        return idCategory;
    }

    public void setIdCategory(int idCategory) {
        this.idCategory = idCategory;
    }

    @Basic
    @Column(name = "id_value", nullable = true)
    public Integer getIdValue() {
        return idValue;
    }

    public void setIdValue(Integer idValue) {
        this.idValue = idValue;
    }

    @Basic
    @Column(name = "type", nullable = false)
    public Object getType() {
        return type;
    }

    public void setType(Object type) {
        this.type = type;
    }

    @Basic
    @Column(name = "position", nullable = false)
    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    @Basic
    @Column(name = "filter_type", nullable = false)
    public int getFilterType() {
        return filterType;
    }

    public void setFilterType(int filterType) {
        this.filterType = filterType;
    }

    @Basic
    @Column(name = "filter_show_limit", nullable = false)
    public int getFilterShowLimit() {
        return filterShowLimit;
    }

    public void setFilterShowLimit(int filterShowLimit) {
        this.filterShowLimit = filterShowLimit;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LayeredCategoryEntity that = (LayeredCategoryEntity) o;
        return idLayeredCategory == that.idLayeredCategory &&
                idShop == that.idShop &&
                idCategory == that.idCategory &&
                position == that.position &&
                filterType == that.filterType &&
                filterShowLimit == that.filterShowLimit &&
                Objects.equals(idValue, that.idValue) &&
                Objects.equals(type, that.type);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idLayeredCategory, idShop, idCategory, idValue, type, position, filterType, filterShowLimit);
    }
}
