package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "message", schema = "ps1761", catalog = "")
public class MessageEntity {
    private int idMessage;
    private Integer idCart;
    private int idCustomer;
    private Integer idEmployee;
    private int idOrder;
    private String message;
    private byte isPrivate;
    private Timestamp dateAdd;

    @Id
    @Column(name = "id_message", nullable = false)
    public int getIdMessage() {
        return idMessage;
    }

    public void setIdMessage(int idMessage) {
        this.idMessage = idMessage;
    }

    @Basic
    @Column(name = "id_cart", nullable = true)
    public Integer getIdCart() {
        return idCart;
    }

    public void setIdCart(Integer idCart) {
        this.idCart = idCart;
    }

    @Basic
    @Column(name = "id_customer", nullable = false)
    public int getIdCustomer() {
        return idCustomer;
    }

    public void setIdCustomer(int idCustomer) {
        this.idCustomer = idCustomer;
    }

    @Basic
    @Column(name = "id_employee", nullable = true)
    public Integer getIdEmployee() {
        return idEmployee;
    }

    public void setIdEmployee(Integer idEmployee) {
        this.idEmployee = idEmployee;
    }

    @Basic
    @Column(name = "id_order", nullable = false)
    public int getIdOrder() {
        return idOrder;
    }

    public void setIdOrder(int idOrder) {
        this.idOrder = idOrder;
    }

    @Basic
    @Column(name = "message", nullable = false, length = -1)
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Basic
    @Column(name = "private", nullable = false)
    public byte getIsPrivate() {
        return isPrivate;
    }

    public void setIsPrivate(byte isPrivate) {
        this.isPrivate = isPrivate;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MessageEntity that = (MessageEntity) o;
        return idMessage == that.idMessage &&
                idCustomer == that.idCustomer &&
                idOrder == that.idOrder &&
                isPrivate == that.isPrivate &&
                Objects.equals(idCart, that.idCart) &&
                Objects.equals(idEmployee, that.idEmployee) &&
                Objects.equals(message, that.message) &&
                Objects.equals(dateAdd, that.dateAdd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idMessage, idCart, idCustomer, idEmployee, idOrder, message, isPrivate, dateAdd);
    }
}
