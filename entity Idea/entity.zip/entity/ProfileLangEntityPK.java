package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class ProfileLangEntityPK implements Serializable {
    private int idLang;
    private int idProfile;

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Column(name = "id_profile", nullable = false)
    @Id
    public int getIdProfile() {
        return idProfile;
    }

    public void setIdProfile(int idProfile) {
        this.idProfile = idProfile;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProfileLangEntityPK that = (ProfileLangEntityPK) o;
        return idLang == that.idLang &&
                idProfile == that.idProfile;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idLang, idProfile);
    }
}
