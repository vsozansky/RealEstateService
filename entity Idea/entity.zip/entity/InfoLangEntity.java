package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "info_lang", schema = "ps1761", catalog = "")
@IdClass(InfoLangEntityPK.class)
public class InfoLangEntity {
    private int idInfo;
    private int idShop;
    private int idLang;
    private String text;

    @Id
    @Column(name = "id_info", nullable = false)
    public int getIdInfo() {
        return idInfo;
    }

    public void setIdInfo(int idInfo) {
        this.idInfo = idInfo;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "text", nullable = false, length = -1)
    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InfoLangEntity that = (InfoLangEntity) o;
        return idInfo == that.idInfo &&
                idShop == that.idShop &&
                idLang == that.idLang &&
                Objects.equals(text, that.text);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idInfo, idShop, idLang, text);
    }
}
