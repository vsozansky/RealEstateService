package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "supplier_lang", schema = "ps1761", catalog = "")
@IdClass(SupplierLangEntityPK.class)
public class SupplierLangEntity {
    private int idSupplier;
    private int idLang;
    private String description;
    private String metaTitle;
    private String metaKeywords;
    private String metaDescription;

    @Id
    @Column(name = "id_supplier", nullable = false)
    public int getIdSupplier() {
        return idSupplier;
    }

    public void setIdSupplier(int idSupplier) {
        this.idSupplier = idSupplier;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "description", nullable = true, length = -1)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Basic
    @Column(name = "meta_title", nullable = true, length = 255)
    public String getMetaTitle() {
        return metaTitle;
    }

    public void setMetaTitle(String metaTitle) {
        this.metaTitle = metaTitle;
    }

    @Basic
    @Column(name = "meta_keywords", nullable = true, length = 255)
    public String getMetaKeywords() {
        return metaKeywords;
    }

    public void setMetaKeywords(String metaKeywords) {
        this.metaKeywords = metaKeywords;
    }

    @Basic
    @Column(name = "meta_description", nullable = true, length = 512)
    public String getMetaDescription() {
        return metaDescription;
    }

    public void setMetaDescription(String metaDescription) {
        this.metaDescription = metaDescription;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SupplierLangEntity that = (SupplierLangEntity) o;
        return idSupplier == that.idSupplier &&
                idLang == that.idLang &&
                Objects.equals(description, that.description) &&
                Objects.equals(metaTitle, that.metaTitle) &&
                Objects.equals(metaKeywords, that.metaKeywords) &&
                Objects.equals(metaDescription, that.metaDescription);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idSupplier, idLang, description, metaTitle, metaKeywords, metaDescription);
    }
}
