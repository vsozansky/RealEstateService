package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "referrer_cache", schema = "ps1761", catalog = "")
@IdClass(ReferrerCacheEntityPK.class)
public class ReferrerCacheEntity {
    private int idConnectionsSource;
    private int idReferrer;

    @Id
    @Column(name = "id_connections_source", nullable = false)
    public int getIdConnectionsSource() {
        return idConnectionsSource;
    }

    public void setIdConnectionsSource(int idConnectionsSource) {
        this.idConnectionsSource = idConnectionsSource;
    }

    @Id
    @Column(name = "id_referrer", nullable = false)
    public int getIdReferrer() {
        return idReferrer;
    }

    public void setIdReferrer(int idReferrer) {
        this.idReferrer = idReferrer;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ReferrerCacheEntity that = (ReferrerCacheEntity) o;
        return idConnectionsSource == that.idConnectionsSource &&
                idReferrer == that.idReferrer;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idConnectionsSource, idReferrer);
    }
}
