package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "supply_order_state", schema = "ps1761", catalog = "")
public class SupplyOrderStateEntity {
    private int idSupplyOrderState;
    private byte deliveryNote;
    private byte editable;
    private byte receiptState;
    private byte pendingReceipt;
    private byte enclosed;
    private String color;

    @Id
    @Column(name = "id_supply_order_state", nullable = false)
    public int getIdSupplyOrderState() {
        return idSupplyOrderState;
    }

    public void setIdSupplyOrderState(int idSupplyOrderState) {
        this.idSupplyOrderState = idSupplyOrderState;
    }

    @Basic
    @Column(name = "delivery_note", nullable = false)
    public byte getDeliveryNote() {
        return deliveryNote;
    }

    public void setDeliveryNote(byte deliveryNote) {
        this.deliveryNote = deliveryNote;
    }

    @Basic
    @Column(name = "editable", nullable = false)
    public byte getEditable() {
        return editable;
    }

    public void setEditable(byte editable) {
        this.editable = editable;
    }

    @Basic
    @Column(name = "receipt_state", nullable = false)
    public byte getReceiptState() {
        return receiptState;
    }

    public void setReceiptState(byte receiptState) {
        this.receiptState = receiptState;
    }

    @Basic
    @Column(name = "pending_receipt", nullable = false)
    public byte getPendingReceipt() {
        return pendingReceipt;
    }

    public void setPendingReceipt(byte pendingReceipt) {
        this.pendingReceipt = pendingReceipt;
    }

    @Basic
    @Column(name = "enclosed", nullable = false)
    public byte getEnclosed() {
        return enclosed;
    }

    public void setEnclosed(byte enclosed) {
        this.enclosed = enclosed;
    }

    @Basic
    @Column(name = "color", nullable = true, length = 32)
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SupplyOrderStateEntity that = (SupplyOrderStateEntity) o;
        return idSupplyOrderState == that.idSupplyOrderState &&
                deliveryNote == that.deliveryNote &&
                editable == that.editable &&
                receiptState == that.receiptState &&
                pendingReceipt == that.pendingReceipt &&
                enclosed == that.enclosed &&
                Objects.equals(color, that.color);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idSupplyOrderState, deliveryNote, editable, receiptState, pendingReceipt, enclosed, color);
    }
}
