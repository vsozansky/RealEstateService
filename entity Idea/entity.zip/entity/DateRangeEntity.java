package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "date_range", schema = "ps1761", catalog = "")
public class DateRangeEntity {
    private int idDateRange;
    private Timestamp timeStart;
    private Timestamp timeEnd;

    @Id
    @Column(name = "id_date_range", nullable = false)
    public int getIdDateRange() {
        return idDateRange;
    }

    public void setIdDateRange(int idDateRange) {
        this.idDateRange = idDateRange;
    }

    @Basic
    @Column(name = "time_start", nullable = false)
    public Timestamp getTimeStart() {
        return timeStart;
    }

    public void setTimeStart(Timestamp timeStart) {
        this.timeStart = timeStart;
    }

    @Basic
    @Column(name = "time_end", nullable = false)
    public Timestamp getTimeEnd() {
        return timeEnd;
    }

    public void setTimeEnd(Timestamp timeEnd) {
        this.timeEnd = timeEnd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DateRangeEntity that = (DateRangeEntity) o;
        return idDateRange == that.idDateRange &&
                Objects.equals(timeStart, that.timeStart) &&
                Objects.equals(timeEnd, that.timeEnd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idDateRange, timeStart, timeEnd);
    }
}
