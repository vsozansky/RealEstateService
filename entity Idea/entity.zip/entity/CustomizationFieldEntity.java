package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "customization_field", schema = "ps1761", catalog = "")
public class CustomizationFieldEntity {
    private int idCustomizationField;
    private int idProduct;
    private byte type;
    private byte required;
    private byte isModule;
    private byte isDeleted;

    @Id
    @Column(name = "id_customization_field", nullable = false)
    public int getIdCustomizationField() {
        return idCustomizationField;
    }

    public void setIdCustomizationField(int idCustomizationField) {
        this.idCustomizationField = idCustomizationField;
    }

    @Basic
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Basic
    @Column(name = "type", nullable = false)
    public byte getType() {
        return type;
    }

    public void setType(byte type) {
        this.type = type;
    }

    @Basic
    @Column(name = "required", nullable = false)
    public byte getRequired() {
        return required;
    }

    public void setRequired(byte required) {
        this.required = required;
    }

    @Basic
    @Column(name = "is_module", nullable = false)
    public byte getIsModule() {
        return isModule;
    }

    public void setIsModule(byte isModule) {
        this.isModule = isModule;
    }

    @Basic
    @Column(name = "is_deleted", nullable = false)
    public byte getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(byte isDeleted) {
        this.isDeleted = isDeleted;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CustomizationFieldEntity that = (CustomizationFieldEntity) o;
        return idCustomizationField == that.idCustomizationField &&
                idProduct == that.idProduct &&
                type == that.type &&
                required == that.required &&
                isModule == that.isModule &&
                isDeleted == that.isDeleted;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCustomizationField, idProduct, type, required, isModule, isDeleted);
    }
}
