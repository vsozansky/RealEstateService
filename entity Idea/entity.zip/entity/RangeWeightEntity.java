package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name = "range_weight", schema = "ps1761", catalog = "")
public class RangeWeightEntity {
    private int idRangeWeight;
    private int idCarrier;
    private BigDecimal delimiter1;
    private BigDecimal delimiter2;

    @Id
    @Column(name = "id_range_weight", nullable = false)
    public int getIdRangeWeight() {
        return idRangeWeight;
    }

    public void setIdRangeWeight(int idRangeWeight) {
        this.idRangeWeight = idRangeWeight;
    }

    @Basic
    @Column(name = "id_carrier", nullable = false)
    public int getIdCarrier() {
        return idCarrier;
    }

    public void setIdCarrier(int idCarrier) {
        this.idCarrier = idCarrier;
    }

    @Basic
    @Column(name = "delimiter1", nullable = false, precision = 6)
    public BigDecimal getDelimiter1() {
        return delimiter1;
    }

    public void setDelimiter1(BigDecimal delimiter1) {
        this.delimiter1 = delimiter1;
    }

    @Basic
    @Column(name = "delimiter2", nullable = false, precision = 6)
    public BigDecimal getDelimiter2() {
        return delimiter2;
    }

    public void setDelimiter2(BigDecimal delimiter2) {
        this.delimiter2 = delimiter2;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RangeWeightEntity that = (RangeWeightEntity) o;
        return idRangeWeight == that.idRangeWeight &&
                idCarrier == that.idCarrier &&
                Objects.equals(delimiter1, that.delimiter1) &&
                Objects.equals(delimiter2, that.delimiter2);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idRangeWeight, idCarrier, delimiter1, delimiter2);
    }
}
