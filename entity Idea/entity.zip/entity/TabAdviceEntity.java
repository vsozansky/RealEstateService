package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "tab_advice", schema = "ps1761", catalog = "")
@IdClass(TabAdviceEntityPK.class)
public class TabAdviceEntity {
    private int idTab;
    private int idAdvice;

    @Id
    @Column(name = "id_tab", nullable = false)
    public int getIdTab() {
        return idTab;
    }

    public void setIdTab(int idTab) {
        this.idTab = idTab;
    }

    @Id
    @Column(name = "id_advice", nullable = false)
    public int getIdAdvice() {
        return idAdvice;
    }

    public void setIdAdvice(int idAdvice) {
        this.idAdvice = idAdvice;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TabAdviceEntity that = (TabAdviceEntity) o;
        return idTab == that.idTab &&
                idAdvice == that.idAdvice;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idTab, idAdvice);
    }
}
