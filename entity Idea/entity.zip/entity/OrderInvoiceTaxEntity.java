package com.jprestashop.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name = "order_invoice_tax", schema = "ps1761", catalog = "")
public class OrderInvoiceTaxEntity {
    private int idOrderInvoice;
    private String type;
    private int idTax;
    private BigDecimal amount;

    @Basic
    @Column(name = "id_order_invoice", nullable = false)
    public int getIdOrderInvoice() {
        return idOrderInvoice;
    }

    public void setIdOrderInvoice(int idOrderInvoice) {
        this.idOrderInvoice = idOrderInvoice;
    }

    @Basic
    @Column(name = "type", nullable = false, length = 15)
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Basic
    @Column(name = "id_tax", nullable = false)
    public int getIdTax() {
        return idTax;
    }

    public void setIdTax(int idTax) {
        this.idTax = idTax;
    }

    @Basic
    @Column(name = "amount", nullable = false, precision = 6)
    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderInvoiceTaxEntity that = (OrderInvoiceTaxEntity) o;
        return idOrderInvoice == that.idOrderInvoice &&
                idTax == that.idTax &&
                Objects.equals(type, that.type) &&
                Objects.equals(amount, that.amount);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrderInvoice, type, idTax, amount);
    }
}
