package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "image_lang", schema = "ps1761", catalog = "")
@IdClass(ImageLangEntityPK.class)
public class ImageLangEntity {
    private int idImage;
    private int idLang;
    private String legend;

    @Id
    @Column(name = "id_image", nullable = false)
    public int getIdImage() {
        return idImage;
    }

    public void setIdImage(int idImage) {
        this.idImage = idImage;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "legend", nullable = true, length = 128)
    public String getLegend() {
        return legend;
    }

    public void setLegend(String legend) {
        this.legend = legend;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ImageLangEntity that = (ImageLangEntity) o;
        return idImage == that.idImage &&
                idLang == that.idLang &&
                Objects.equals(legend, that.legend);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idImage, idLang, legend);
    }
}
