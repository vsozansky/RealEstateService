package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "stock_mvt_reason", schema = "ps1761", catalog = "")
public class StockMvtReasonEntity {
    private int idStockMvtReason;
    private byte sign;
    private Timestamp dateAdd;
    private Timestamp dateUpd;
    private byte deleted;

    @Id
    @Column(name = "id_stock_mvt_reason", nullable = false)
    public int getIdStockMvtReason() {
        return idStockMvtReason;
    }

    public void setIdStockMvtReason(int idStockMvtReason) {
        this.idStockMvtReason = idStockMvtReason;
    }

    @Basic
    @Column(name = "sign", nullable = false)
    public byte getSign() {
        return sign;
    }

    public void setSign(byte sign) {
        this.sign = sign;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Basic
    @Column(name = "date_upd", nullable = false)
    public Timestamp getDateUpd() {
        return dateUpd;
    }

    public void setDateUpd(Timestamp dateUpd) {
        this.dateUpd = dateUpd;
    }

    @Basic
    @Column(name = "deleted", nullable = false)
    public byte getDeleted() {
        return deleted;
    }

    public void setDeleted(byte deleted) {
        this.deleted = deleted;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StockMvtReasonEntity that = (StockMvtReasonEntity) o;
        return idStockMvtReason == that.idStockMvtReason &&
                sign == that.sign &&
                deleted == that.deleted &&
                Objects.equals(dateAdd, that.dateAdd) &&
                Objects.equals(dateUpd, that.dateUpd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idStockMvtReason, sign, dateAdd, dateUpd, deleted);
    }
}
