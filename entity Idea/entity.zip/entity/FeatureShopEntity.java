package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "feature_shop", schema = "ps1761", catalog = "")
@IdClass(FeatureShopEntityPK.class)
public class FeatureShopEntity {
    private int idFeature;
    private int idShop;

    @Id
    @Column(name = "id_feature", nullable = false)
    public int getIdFeature() {
        return idFeature;
    }

    public void setIdFeature(int idFeature) {
        this.idFeature = idFeature;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FeatureShopEntity that = (FeatureShopEntity) o;
        return idFeature == that.idFeature &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idFeature, idShop);
    }
}
