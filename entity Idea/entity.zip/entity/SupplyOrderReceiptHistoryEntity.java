package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "supply_order_receipt_history", schema = "ps1761", catalog = "")
public class SupplyOrderReceiptHistoryEntity {
    private int idSupplyOrderReceiptHistory;
    private int idSupplyOrderDetail;
    private int idEmployee;
    private String employeeLastname;
    private String employeeFirstname;
    private int idSupplyOrderState;
    private int quantity;
    private Timestamp dateAdd;

    @Id
    @Column(name = "id_supply_order_receipt_history", nullable = false)
    public int getIdSupplyOrderReceiptHistory() {
        return idSupplyOrderReceiptHistory;
    }

    public void setIdSupplyOrderReceiptHistory(int idSupplyOrderReceiptHistory) {
        this.idSupplyOrderReceiptHistory = idSupplyOrderReceiptHistory;
    }

    @Basic
    @Column(name = "id_supply_order_detail", nullable = false)
    public int getIdSupplyOrderDetail() {
        return idSupplyOrderDetail;
    }

    public void setIdSupplyOrderDetail(int idSupplyOrderDetail) {
        this.idSupplyOrderDetail = idSupplyOrderDetail;
    }

    @Basic
    @Column(name = "id_employee", nullable = false)
    public int getIdEmployee() {
        return idEmployee;
    }

    public void setIdEmployee(int idEmployee) {
        this.idEmployee = idEmployee;
    }

    @Basic
    @Column(name = "employee_lastname", nullable = true, length = 255)
    public String getEmployeeLastname() {
        return employeeLastname;
    }

    public void setEmployeeLastname(String employeeLastname) {
        this.employeeLastname = employeeLastname;
    }

    @Basic
    @Column(name = "employee_firstname", nullable = true, length = 255)
    public String getEmployeeFirstname() {
        return employeeFirstname;
    }

    public void setEmployeeFirstname(String employeeFirstname) {
        this.employeeFirstname = employeeFirstname;
    }

    @Basic
    @Column(name = "id_supply_order_state", nullable = false)
    public int getIdSupplyOrderState() {
        return idSupplyOrderState;
    }

    public void setIdSupplyOrderState(int idSupplyOrderState) {
        this.idSupplyOrderState = idSupplyOrderState;
    }

    @Basic
    @Column(name = "quantity", nullable = false)
    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SupplyOrderReceiptHistoryEntity that = (SupplyOrderReceiptHistoryEntity) o;
        return idSupplyOrderReceiptHistory == that.idSupplyOrderReceiptHistory &&
                idSupplyOrderDetail == that.idSupplyOrderDetail &&
                idEmployee == that.idEmployee &&
                idSupplyOrderState == that.idSupplyOrderState &&
                quantity == that.quantity &&
                Objects.equals(employeeLastname, that.employeeLastname) &&
                Objects.equals(employeeFirstname, that.employeeFirstname) &&
                Objects.equals(dateAdd, that.dateAdd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idSupplyOrderReceiptHistory, idSupplyOrderDetail, idEmployee, employeeLastname, employeeFirstname, idSupplyOrderState, quantity, dateAdd);
    }
}
