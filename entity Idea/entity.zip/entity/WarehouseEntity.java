package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "warehouse", schema = "ps1761", catalog = "")
public class WarehouseEntity {
    private int idWarehouse;
    private int idCurrency;
    private int idAddress;
    private int idEmployee;
    private String reference;
    private String name;
    private Object managementType;
    private byte deleted;

    @Id
    @Column(name = "id_warehouse", nullable = false)
    public int getIdWarehouse() {
        return idWarehouse;
    }

    public void setIdWarehouse(int idWarehouse) {
        this.idWarehouse = idWarehouse;
    }

    @Basic
    @Column(name = "id_currency", nullable = false)
    public int getIdCurrency() {
        return idCurrency;
    }

    public void setIdCurrency(int idCurrency) {
        this.idCurrency = idCurrency;
    }

    @Basic
    @Column(name = "id_address", nullable = false)
    public int getIdAddress() {
        return idAddress;
    }

    public void setIdAddress(int idAddress) {
        this.idAddress = idAddress;
    }

    @Basic
    @Column(name = "id_employee", nullable = false)
    public int getIdEmployee() {
        return idEmployee;
    }

    public void setIdEmployee(int idEmployee) {
        this.idEmployee = idEmployee;
    }

    @Basic
    @Column(name = "reference", nullable = true, length = 64)
    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 45)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "management_type", nullable = false)
    public Object getManagementType() {
        return managementType;
    }

    public void setManagementType(Object managementType) {
        this.managementType = managementType;
    }

    @Basic
    @Column(name = "deleted", nullable = false)
    public byte getDeleted() {
        return deleted;
    }

    public void setDeleted(byte deleted) {
        this.deleted = deleted;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WarehouseEntity that = (WarehouseEntity) o;
        return idWarehouse == that.idWarehouse &&
                idCurrency == that.idCurrency &&
                idAddress == that.idAddress &&
                idEmployee == that.idEmployee &&
                deleted == that.deleted &&
                Objects.equals(reference, that.reference) &&
                Objects.equals(name, that.name) &&
                Objects.equals(managementType, that.managementType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idWarehouse, idCurrency, idAddress, idEmployee, reference, name, managementType, deleted);
    }
}
