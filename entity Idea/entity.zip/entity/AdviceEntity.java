package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "advice", schema = "ps1761", catalog = "")
public class AdviceEntity {
    private int idAdvice;
    private int idPsAdvice;
    private int idTab;
    private String idsTab;
    private byte validated;
    private byte hide;
    private Object location;
    private String selector;
    private int startDay;
    private int stopDay;
    private Integer weight;

    @Id
    @Column(name = "id_advice", nullable = false)
    public int getIdAdvice() {
        return idAdvice;
    }

    public void setIdAdvice(int idAdvice) {
        this.idAdvice = idAdvice;
    }

    @Basic
    @Column(name = "id_ps_advice", nullable = false)
    public int getIdPsAdvice() {
        return idPsAdvice;
    }

    public void setIdPsAdvice(int idPsAdvice) {
        this.idPsAdvice = idPsAdvice;
    }

    @Basic
    @Column(name = "id_tab", nullable = false)
    public int getIdTab() {
        return idTab;
    }

    public void setIdTab(int idTab) {
        this.idTab = idTab;
    }

    @Basic
    @Column(name = "ids_tab", nullable = true, length = -1)
    public String getIdsTab() {
        return idsTab;
    }

    public void setIdsTab(String idsTab) {
        this.idsTab = idsTab;
    }

    @Basic
    @Column(name = "validated", nullable = false)
    public byte getValidated() {
        return validated;
    }

    public void setValidated(byte validated) {
        this.validated = validated;
    }

    @Basic
    @Column(name = "hide", nullable = false)
    public byte getHide() {
        return hide;
    }

    public void setHide(byte hide) {
        this.hide = hide;
    }

    @Basic
    @Column(name = "location", nullable = false)
    public Object getLocation() {
        return location;
    }

    public void setLocation(Object location) {
        this.location = location;
    }

    @Basic
    @Column(name = "selector", nullable = true, length = 255)
    public String getSelector() {
        return selector;
    }

    public void setSelector(String selector) {
        this.selector = selector;
    }

    @Basic
    @Column(name = "start_day", nullable = false)
    public int getStartDay() {
        return startDay;
    }

    public void setStartDay(int startDay) {
        this.startDay = startDay;
    }

    @Basic
    @Column(name = "stop_day", nullable = false)
    public int getStopDay() {
        return stopDay;
    }

    public void setStopDay(int stopDay) {
        this.stopDay = stopDay;
    }

    @Basic
    @Column(name = "weight", nullable = true)
    public Integer getWeight() {
        return weight;
    }

    public void setWeight(Integer weight) {
        this.weight = weight;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AdviceEntity that = (AdviceEntity) o;
        return idAdvice == that.idAdvice &&
                idPsAdvice == that.idPsAdvice &&
                idTab == that.idTab &&
                validated == that.validated &&
                hide == that.hide &&
                startDay == that.startDay &&
                stopDay == that.stopDay &&
                Objects.equals(idsTab, that.idsTab) &&
                Objects.equals(location, that.location) &&
                Objects.equals(selector, that.selector) &&
                Objects.equals(weight, that.weight);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAdvice, idPsAdvice, idTab, idsTab, validated, hide, location, selector, startDay, stopDay, weight);
    }
}
