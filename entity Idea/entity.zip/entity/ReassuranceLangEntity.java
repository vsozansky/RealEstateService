package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "reassurance_lang", schema = "ps1761", catalog = "")
@IdClass(ReassuranceLangEntityPK.class)
public class ReassuranceLangEntity {
    private int idReassurance;
    private int idLang;
    private String text;

    @Id
    @Column(name = "id_reassurance", nullable = false)
    public int getIdReassurance() {
        return idReassurance;
    }

    public void setIdReassurance(int idReassurance) {
        this.idReassurance = idReassurance;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "text", nullable = false, length = 300)
    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ReassuranceLangEntity that = (ReassuranceLangEntity) o;
        return idReassurance == that.idReassurance &&
                idLang == that.idLang &&
                Objects.equals(text, that.text);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idReassurance, idLang, text);
    }
}
