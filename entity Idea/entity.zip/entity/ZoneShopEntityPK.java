package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class ZoneShopEntityPK implements Serializable {
    private int idZone;
    private int idShop;

    @Column(name = "id_zone", nullable = false)
    @Id
    public int getIdZone() {
        return idZone;
    }

    public void setIdZone(int idZone) {
        this.idZone = idZone;
    }

    @Column(name = "id_shop", nullable = false)
    @Id
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ZoneShopEntityPK that = (ZoneShopEntityPK) o;
        return idZone == that.idZone &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idZone, idShop);
    }
}
