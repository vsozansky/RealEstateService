package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class CarrierZoneEntityPK implements Serializable {
    private int idCarrier;
    private int idZone;

    @Column(name = "id_carrier", nullable = false)
    @Id
    public int getIdCarrier() {
        return idCarrier;
    }

    public void setIdCarrier(int idCarrier) {
        this.idCarrier = idCarrier;
    }

    @Column(name = "id_zone", nullable = false)
    @Id
    public int getIdZone() {
        return idZone;
    }

    public void setIdZone(int idZone) {
        this.idZone = idZone;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CarrierZoneEntityPK that = (CarrierZoneEntityPK) o;
        return idCarrier == that.idCarrier &&
                idZone == that.idZone;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCarrier, idZone);
    }
}
