package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class CarrierLangEntityPK implements Serializable {
    private int idCarrier;
    private int idShop;
    private int idLang;

    @Column(name = "id_carrier", nullable = false)
    @Id
    public int getIdCarrier() {
        return idCarrier;
    }

    public void setIdCarrier(int idCarrier) {
        this.idCarrier = idCarrier;
    }

    @Column(name = "id_shop", nullable = false)
    @Id
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CarrierLangEntityPK that = (CarrierLangEntityPK) o;
        return idCarrier == that.idCarrier &&
                idShop == that.idShop &&
                idLang == that.idLang;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCarrier, idShop, idLang);
    }
}
