package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "risk", schema = "ps1761", catalog = "")
public class RiskEntity {
    private int idRisk;
    private byte percent;
    private String color;

    @Id
    @Column(name = "id_risk", nullable = false)
    public int getIdRisk() {
        return idRisk;
    }

    public void setIdRisk(int idRisk) {
        this.idRisk = idRisk;
    }

    @Basic
    @Column(name = "percent", nullable = false)
    public byte getPercent() {
        return percent;
    }

    public void setPercent(byte percent) {
        this.percent = percent;
    }

    @Basic
    @Column(name = "color", nullable = true, length = 32)
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RiskEntity that = (RiskEntity) o;
        return idRisk == that.idRisk &&
                percent == that.percent &&
                Objects.equals(color, that.color);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idRisk, percent, color);
    }
}
