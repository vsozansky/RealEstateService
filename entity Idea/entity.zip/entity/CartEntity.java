package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "cart", schema = "ps1761", catalog = "")
public class CartEntity {
    private int idCart;
    private int idShopGroup;
    private int idShop;
    private int idCarrier;
    private String deliveryOption;
    private int idLang;
    private int idAddressDelivery;
    private int idAddressInvoice;
    private int idCurrency;
    private int idCustomer;
    private int idGuest;
    private String secureKey;
    private byte recyclable;
    private byte gift;
    private String giftMessage;
    private byte mobileTheme;
    private byte allowSeperatedPackage;
    private Timestamp dateAdd;
    private Timestamp dateUpd;
    private String checkoutSessionData;

    @Id
    @Column(name = "id_cart", nullable = false)
    public int getIdCart() {
        return idCart;
    }

    public void setIdCart(int idCart) {
        this.idCart = idCart;
    }

    @Basic
    @Column(name = "id_shop_group", nullable = false)
    public int getIdShopGroup() {
        return idShopGroup;
    }

    public void setIdShopGroup(int idShopGroup) {
        this.idShopGroup = idShopGroup;
    }

    @Basic
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "id_carrier", nullable = false)
    public int getIdCarrier() {
        return idCarrier;
    }

    public void setIdCarrier(int idCarrier) {
        this.idCarrier = idCarrier;
    }

    @Basic
    @Column(name = "delivery_option", nullable = false, length = -1)
    public String getDeliveryOption() {
        return deliveryOption;
    }

    public void setDeliveryOption(String deliveryOption) {
        this.deliveryOption = deliveryOption;
    }

    @Basic
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "id_address_delivery", nullable = false)
    public int getIdAddressDelivery() {
        return idAddressDelivery;
    }

    public void setIdAddressDelivery(int idAddressDelivery) {
        this.idAddressDelivery = idAddressDelivery;
    }

    @Basic
    @Column(name = "id_address_invoice", nullable = false)
    public int getIdAddressInvoice() {
        return idAddressInvoice;
    }

    public void setIdAddressInvoice(int idAddressInvoice) {
        this.idAddressInvoice = idAddressInvoice;
    }

    @Basic
    @Column(name = "id_currency", nullable = false)
    public int getIdCurrency() {
        return idCurrency;
    }

    public void setIdCurrency(int idCurrency) {
        this.idCurrency = idCurrency;
    }

    @Basic
    @Column(name = "id_customer", nullable = false)
    public int getIdCustomer() {
        return idCustomer;
    }

    public void setIdCustomer(int idCustomer) {
        this.idCustomer = idCustomer;
    }

    @Basic
    @Column(name = "id_guest", nullable = false)
    public int getIdGuest() {
        return idGuest;
    }

    public void setIdGuest(int idGuest) {
        this.idGuest = idGuest;
    }

    @Basic
    @Column(name = "secure_key", nullable = false, length = 32)
    public String getSecureKey() {
        return secureKey;
    }

    public void setSecureKey(String secureKey) {
        this.secureKey = secureKey;
    }

    @Basic
    @Column(name = "recyclable", nullable = false)
    public byte getRecyclable() {
        return recyclable;
    }

    public void setRecyclable(byte recyclable) {
        this.recyclable = recyclable;
    }

    @Basic
    @Column(name = "gift", nullable = false)
    public byte getGift() {
        return gift;
    }

    public void setGift(byte gift) {
        this.gift = gift;
    }

    @Basic
    @Column(name = "gift_message", nullable = true, length = -1)
    public String getGiftMessage() {
        return giftMessage;
    }

    public void setGiftMessage(String giftMessage) {
        this.giftMessage = giftMessage;
    }

    @Basic
    @Column(name = "mobile_theme", nullable = false)
    public byte getMobileTheme() {
        return mobileTheme;
    }

    public void setMobileTheme(byte mobileTheme) {
        this.mobileTheme = mobileTheme;
    }

    @Basic
    @Column(name = "allow_seperated_package", nullable = false)
    public byte getAllowSeperatedPackage() {
        return allowSeperatedPackage;
    }

    public void setAllowSeperatedPackage(byte allowSeperatedPackage) {
        this.allowSeperatedPackage = allowSeperatedPackage;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Basic
    @Column(name = "date_upd", nullable = false)
    public Timestamp getDateUpd() {
        return dateUpd;
    }

    public void setDateUpd(Timestamp dateUpd) {
        this.dateUpd = dateUpd;
    }

    @Basic
    @Column(name = "checkout_session_data", nullable = true, length = -1)
    public String getCheckoutSessionData() {
        return checkoutSessionData;
    }

    public void setCheckoutSessionData(String checkoutSessionData) {
        this.checkoutSessionData = checkoutSessionData;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CartEntity that = (CartEntity) o;
        return idCart == that.idCart &&
                idShopGroup == that.idShopGroup &&
                idShop == that.idShop &&
                idCarrier == that.idCarrier &&
                idLang == that.idLang &&
                idAddressDelivery == that.idAddressDelivery &&
                idAddressInvoice == that.idAddressInvoice &&
                idCurrency == that.idCurrency &&
                idCustomer == that.idCustomer &&
                idGuest == that.idGuest &&
                recyclable == that.recyclable &&
                gift == that.gift &&
                mobileTheme == that.mobileTheme &&
                allowSeperatedPackage == that.allowSeperatedPackage &&
                Objects.equals(deliveryOption, that.deliveryOption) &&
                Objects.equals(secureKey, that.secureKey) &&
                Objects.equals(giftMessage, that.giftMessage) &&
                Objects.equals(dateAdd, that.dateAdd) &&
                Objects.equals(dateUpd, that.dateUpd) &&
                Objects.equals(checkoutSessionData, that.checkoutSessionData);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCart, idShopGroup, idShop, idCarrier, deliveryOption, idLang, idAddressDelivery, idAddressInvoice, idCurrency, idCustomer, idGuest, secureKey, recyclable, gift, giftMessage, mobileTheme, allowSeperatedPackage, dateAdd, dateUpd, checkoutSessionData);
    }
}
