package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "supplier_shop", schema = "ps1761", catalog = "")
@IdClass(SupplierShopEntityPK.class)
public class SupplierShopEntity {
    private int idSupplier;
    private int idShop;

    @Id
    @Column(name = "id_supplier", nullable = false)
    public int getIdSupplier() {
        return idSupplier;
    }

    public void setIdSupplier(int idSupplier) {
        this.idSupplier = idSupplier;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SupplierShopEntity that = (SupplierShopEntity) o;
        return idSupplier == that.idSupplier &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idSupplier, idShop);
    }
}
