package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "employee", schema = "ps1761", catalog = "")
public class EmployeeEntity {
    private int idEmployee;
    private int idProfile;
    private int idLang;
    private String lastname;
    private String firstname;
    private String email;
    private String passwd;
    private Timestamp lastPasswdGen;
    private Date statsDateFrom;
    private Date statsDateTo;
    private Date statsCompareFrom;
    private Date statsCompareTo;
    private int statsCompareOption;
    private String preselectDateRange;
    private String boColor;
    private String boTheme;
    private String boCss;
    private int defaultTab;
    private int boWidth;
    private byte boMenu;
    private byte active;
    private byte optin;
    private int idLastOrder;
    private int idLastCustomerMessage;
    private int idLastCustomer;
    private Date lastConnectionDate;
    private String resetPasswordToken;
    private Timestamp resetPasswordValidity;

    @Id
    @Column(name = "id_employee", nullable = false)
    public int getIdEmployee() {
        return idEmployee;
    }

    public void setIdEmployee(int idEmployee) {
        this.idEmployee = idEmployee;
    }

    @Basic
    @Column(name = "id_profile", nullable = false)
    public int getIdProfile() {
        return idProfile;
    }

    public void setIdProfile(int idProfile) {
        this.idProfile = idProfile;
    }

    @Basic
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "lastname", nullable = false, length = 255)
    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    @Basic
    @Column(name = "firstname", nullable = false, length = 255)
    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    @Basic
    @Column(name = "email", nullable = false, length = 255)
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Basic
    @Column(name = "passwd", nullable = false, length = 255)
    public String getPasswd() {
        return passwd;
    }

    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    @Basic
    @Column(name = "last_passwd_gen", nullable = false)
    public Timestamp getLastPasswdGen() {
        return lastPasswdGen;
    }

    public void setLastPasswdGen(Timestamp lastPasswdGen) {
        this.lastPasswdGen = lastPasswdGen;
    }

    @Basic
    @Column(name = "stats_date_from", nullable = true)
    public Date getStatsDateFrom() {
        return statsDateFrom;
    }

    public void setStatsDateFrom(Date statsDateFrom) {
        this.statsDateFrom = statsDateFrom;
    }

    @Basic
    @Column(name = "stats_date_to", nullable = true)
    public Date getStatsDateTo() {
        return statsDateTo;
    }

    public void setStatsDateTo(Date statsDateTo) {
        this.statsDateTo = statsDateTo;
    }

    @Basic
    @Column(name = "stats_compare_from", nullable = true)
    public Date getStatsCompareFrom() {
        return statsCompareFrom;
    }

    public void setStatsCompareFrom(Date statsCompareFrom) {
        this.statsCompareFrom = statsCompareFrom;
    }

    @Basic
    @Column(name = "stats_compare_to", nullable = true)
    public Date getStatsCompareTo() {
        return statsCompareTo;
    }

    public void setStatsCompareTo(Date statsCompareTo) {
        this.statsCompareTo = statsCompareTo;
    }

    @Basic
    @Column(name = "stats_compare_option", nullable = false)
    public int getStatsCompareOption() {
        return statsCompareOption;
    }

    public void setStatsCompareOption(int statsCompareOption) {
        this.statsCompareOption = statsCompareOption;
    }

    @Basic
    @Column(name = "preselect_date_range", nullable = true, length = 32)
    public String getPreselectDateRange() {
        return preselectDateRange;
    }

    public void setPreselectDateRange(String preselectDateRange) {
        this.preselectDateRange = preselectDateRange;
    }

    @Basic
    @Column(name = "bo_color", nullable = true, length = 32)
    public String getBoColor() {
        return boColor;
    }

    public void setBoColor(String boColor) {
        this.boColor = boColor;
    }

    @Basic
    @Column(name = "bo_theme", nullable = true, length = 32)
    public String getBoTheme() {
        return boTheme;
    }

    public void setBoTheme(String boTheme) {
        this.boTheme = boTheme;
    }

    @Basic
    @Column(name = "bo_css", nullable = true, length = 64)
    public String getBoCss() {
        return boCss;
    }

    public void setBoCss(String boCss) {
        this.boCss = boCss;
    }

    @Basic
    @Column(name = "default_tab", nullable = false)
    public int getDefaultTab() {
        return defaultTab;
    }

    public void setDefaultTab(int defaultTab) {
        this.defaultTab = defaultTab;
    }

    @Basic
    @Column(name = "bo_width", nullable = false)
    public int getBoWidth() {
        return boWidth;
    }

    public void setBoWidth(int boWidth) {
        this.boWidth = boWidth;
    }

    @Basic
    @Column(name = "bo_menu", nullable = false)
    public byte getBoMenu() {
        return boMenu;
    }

    public void setBoMenu(byte boMenu) {
        this.boMenu = boMenu;
    }

    @Basic
    @Column(name = "active", nullable = false)
    public byte getActive() {
        return active;
    }

    public void setActive(byte active) {
        this.active = active;
    }

    @Basic
    @Column(name = "optin", nullable = false)
    public byte getOptin() {
        return optin;
    }

    public void setOptin(byte optin) {
        this.optin = optin;
    }

    @Basic
    @Column(name = "id_last_order", nullable = false)
    public int getIdLastOrder() {
        return idLastOrder;
    }

    public void setIdLastOrder(int idLastOrder) {
        this.idLastOrder = idLastOrder;
    }

    @Basic
    @Column(name = "id_last_customer_message", nullable = false)
    public int getIdLastCustomerMessage() {
        return idLastCustomerMessage;
    }

    public void setIdLastCustomerMessage(int idLastCustomerMessage) {
        this.idLastCustomerMessage = idLastCustomerMessage;
    }

    @Basic
    @Column(name = "id_last_customer", nullable = false)
    public int getIdLastCustomer() {
        return idLastCustomer;
    }

    public void setIdLastCustomer(int idLastCustomer) {
        this.idLastCustomer = idLastCustomer;
    }

    @Basic
    @Column(name = "last_connection_date", nullable = true)
    public Date getLastConnectionDate() {
        return lastConnectionDate;
    }

    public void setLastConnectionDate(Date lastConnectionDate) {
        this.lastConnectionDate = lastConnectionDate;
    }

    @Basic
    @Column(name = "reset_password_token", nullable = true, length = 40)
    public String getResetPasswordToken() {
        return resetPasswordToken;
    }

    public void setResetPasswordToken(String resetPasswordToken) {
        this.resetPasswordToken = resetPasswordToken;
    }

    @Basic
    @Column(name = "reset_password_validity", nullable = true)
    public Timestamp getResetPasswordValidity() {
        return resetPasswordValidity;
    }

    public void setResetPasswordValidity(Timestamp resetPasswordValidity) {
        this.resetPasswordValidity = resetPasswordValidity;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EmployeeEntity that = (EmployeeEntity) o;
        return idEmployee == that.idEmployee &&
                idProfile == that.idProfile &&
                idLang == that.idLang &&
                statsCompareOption == that.statsCompareOption &&
                defaultTab == that.defaultTab &&
                boWidth == that.boWidth &&
                boMenu == that.boMenu &&
                active == that.active &&
                optin == that.optin &&
                idLastOrder == that.idLastOrder &&
                idLastCustomerMessage == that.idLastCustomerMessage &&
                idLastCustomer == that.idLastCustomer &&
                Objects.equals(lastname, that.lastname) &&
                Objects.equals(firstname, that.firstname) &&
                Objects.equals(email, that.email) &&
                Objects.equals(passwd, that.passwd) &&
                Objects.equals(lastPasswdGen, that.lastPasswdGen) &&
                Objects.equals(statsDateFrom, that.statsDateFrom) &&
                Objects.equals(statsDateTo, that.statsDateTo) &&
                Objects.equals(statsCompareFrom, that.statsCompareFrom) &&
                Objects.equals(statsCompareTo, that.statsCompareTo) &&
                Objects.equals(preselectDateRange, that.preselectDateRange) &&
                Objects.equals(boColor, that.boColor) &&
                Objects.equals(boTheme, that.boTheme) &&
                Objects.equals(boCss, that.boCss) &&
                Objects.equals(lastConnectionDate, that.lastConnectionDate) &&
                Objects.equals(resetPasswordToken, that.resetPasswordToken) &&
                Objects.equals(resetPasswordValidity, that.resetPasswordValidity);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idEmployee, idProfile, idLang, lastname, firstname, email, passwd, lastPasswdGen, statsDateFrom, statsDateTo, statsCompareFrom, statsCompareTo, statsCompareOption, preselectDateRange, boColor, boTheme, boCss, defaultTab, boWidth, boMenu, active, optin, idLastOrder, idLastCustomerMessage, idLastCustomer, lastConnectionDate, resetPasswordToken, resetPasswordValidity);
    }
}
