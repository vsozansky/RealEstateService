package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "product_tag", schema = "ps1761", catalog = "")
@IdClass(ProductTagEntityPK.class)
public class ProductTagEntity {
    private int idProduct;
    private int idTag;
    private int idLang;

    @Id
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Id
    @Column(name = "id_tag", nullable = false)
    public int getIdTag() {
        return idTag;
    }

    public void setIdTag(int idTag) {
        this.idTag = idTag;
    }

    @Basic
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductTagEntity that = (ProductTagEntity) o;
        return idProduct == that.idProduct &&
                idTag == that.idTag &&
                idLang == that.idLang;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProduct, idTag, idLang);
    }
}
