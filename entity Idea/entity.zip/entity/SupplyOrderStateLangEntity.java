package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "supply_order_state_lang", schema = "ps1761", catalog = "")
@IdClass(SupplyOrderStateLangEntityPK.class)
public class SupplyOrderStateLangEntity {
    private int idSupplyOrderState;
    private int idLang;
    private String name;

    @Id
    @Column(name = "id_supply_order_state", nullable = false)
    public int getIdSupplyOrderState() {
        return idSupplyOrderState;
    }

    public void setIdSupplyOrderState(int idSupplyOrderState) {
        this.idSupplyOrderState = idSupplyOrderState;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "name", nullable = true, length = 128)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SupplyOrderStateLangEntity that = (SupplyOrderStateLangEntity) o;
        return idSupplyOrderState == that.idSupplyOrderState &&
                idLang == that.idLang &&
                Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idSupplyOrderState, idLang, name);
    }
}
