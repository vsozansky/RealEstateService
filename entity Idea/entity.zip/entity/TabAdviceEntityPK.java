package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class TabAdviceEntityPK implements Serializable {
    private int idTab;
    private int idAdvice;

    @Column(name = "id_tab", nullable = false)
    @Id
    public int getIdTab() {
        return idTab;
    }

    public void setIdTab(int idTab) {
        this.idTab = idTab;
    }

    @Column(name = "id_advice", nullable = false)
    @Id
    public int getIdAdvice() {
        return idAdvice;
    }

    public void setIdAdvice(int idAdvice) {
        this.idAdvice = idAdvice;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TabAdviceEntityPK that = (TabAdviceEntityPK) o;
        return idTab == that.idTab &&
                idAdvice == that.idAdvice;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idTab, idAdvice);
    }
}
