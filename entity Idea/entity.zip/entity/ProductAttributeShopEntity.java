package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.Objects;

@Entity
@Table(name = "product_attribute_shop", schema = "ps1761", catalog = "")
@IdClass(ProductAttributeShopEntityPK.class)
public class ProductAttributeShopEntity {
    private int idProduct;
    private int idProductAttribute;
    private int idShop;
    private BigDecimal wholesalePrice;
    private BigDecimal price;
    private BigDecimal ecotax;
    private BigDecimal weight;
    private BigDecimal unitPriceImpact;
    private Byte defaultOn;
    private int minimalQuantity;
    private Integer lowStockThreshold;
    private byte lowStockAlert;
    private Date availableDate;

    @Basic
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Id
    @Column(name = "id_product_attribute", nullable = false)
    public int getIdProductAttribute() {
        return idProductAttribute;
    }

    public void setIdProductAttribute(int idProductAttribute) {
        this.idProductAttribute = idProductAttribute;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "wholesale_price", nullable = false, precision = 6)
    public BigDecimal getWholesalePrice() {
        return wholesalePrice;
    }

    public void setWholesalePrice(BigDecimal wholesalePrice) {
        this.wholesalePrice = wholesalePrice;
    }

    @Basic
    @Column(name = "price", nullable = false, precision = 6)
    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    @Basic
    @Column(name = "ecotax", nullable = false, precision = 6)
    public BigDecimal getEcotax() {
        return ecotax;
    }

    public void setEcotax(BigDecimal ecotax) {
        this.ecotax = ecotax;
    }

    @Basic
    @Column(name = "weight", nullable = false, precision = 6)
    public BigDecimal getWeight() {
        return weight;
    }

    public void setWeight(BigDecimal weight) {
        this.weight = weight;
    }

    @Basic
    @Column(name = "unit_price_impact", nullable = false, precision = 6)
    public BigDecimal getUnitPriceImpact() {
        return unitPriceImpact;
    }

    public void setUnitPriceImpact(BigDecimal unitPriceImpact) {
        this.unitPriceImpact = unitPriceImpact;
    }

    @Basic
    @Column(name = "default_on", nullable = true)
    public Byte getDefaultOn() {
        return defaultOn;
    }

    public void setDefaultOn(Byte defaultOn) {
        this.defaultOn = defaultOn;
    }

    @Basic
    @Column(name = "minimal_quantity", nullable = false)
    public int getMinimalQuantity() {
        return minimalQuantity;
    }

    public void setMinimalQuantity(int minimalQuantity) {
        this.minimalQuantity = minimalQuantity;
    }

    @Basic
    @Column(name = "low_stock_threshold", nullable = true)
    public Integer getLowStockThreshold() {
        return lowStockThreshold;
    }

    public void setLowStockThreshold(Integer lowStockThreshold) {
        this.lowStockThreshold = lowStockThreshold;
    }

    @Basic
    @Column(name = "low_stock_alert", nullable = false)
    public byte getLowStockAlert() {
        return lowStockAlert;
    }

    public void setLowStockAlert(byte lowStockAlert) {
        this.lowStockAlert = lowStockAlert;
    }

    @Basic
    @Column(name = "available_date", nullable = true)
    public Date getAvailableDate() {
        return availableDate;
    }

    public void setAvailableDate(Date availableDate) {
        this.availableDate = availableDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductAttributeShopEntity that = (ProductAttributeShopEntity) o;
        return idProduct == that.idProduct &&
                idProductAttribute == that.idProductAttribute &&
                idShop == that.idShop &&
                minimalQuantity == that.minimalQuantity &&
                lowStockAlert == that.lowStockAlert &&
                Objects.equals(wholesalePrice, that.wholesalePrice) &&
                Objects.equals(price, that.price) &&
                Objects.equals(ecotax, that.ecotax) &&
                Objects.equals(weight, that.weight) &&
                Objects.equals(unitPriceImpact, that.unitPriceImpact) &&
                Objects.equals(defaultOn, that.defaultOn) &&
                Objects.equals(lowStockThreshold, that.lowStockThreshold) &&
                Objects.equals(availableDate, that.availableDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProduct, idProductAttribute, idShop, wholesalePrice, price, ecotax, weight, unitPriceImpact, defaultOn, minimalQuantity, lowStockThreshold, lowStockAlert, availableDate);
    }
}
