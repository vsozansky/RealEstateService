package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "tab", schema = "ps1761", catalog = "")
public class TabEntity {
    private int idTab;
    private int idParent;
    private int position;
    private String module;
    private String className;
    private byte active;
    private byte hideHostMode;
    private String icon;

    @Id
    @Column(name = "id_tab", nullable = false)
    public int getIdTab() {
        return idTab;
    }

    public void setIdTab(int idTab) {
        this.idTab = idTab;
    }

    @Basic
    @Column(name = "id_parent", nullable = false)
    public int getIdParent() {
        return idParent;
    }

    public void setIdParent(int idParent) {
        this.idParent = idParent;
    }

    @Basic
    @Column(name = "position", nullable = false)
    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    @Basic
    @Column(name = "module", nullable = true, length = 64)
    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    @Basic
    @Column(name = "class_name", nullable = true, length = 64)
    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    @Basic
    @Column(name = "active", nullable = false)
    public byte getActive() {
        return active;
    }

    public void setActive(byte active) {
        this.active = active;
    }

    @Basic
    @Column(name = "hide_host_mode", nullable = false)
    public byte getHideHostMode() {
        return hideHostMode;
    }

    public void setHideHostMode(byte hideHostMode) {
        this.hideHostMode = hideHostMode;
    }

    @Basic
    @Column(name = "icon", nullable = true, length = 32)
    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TabEntity tabEntity = (TabEntity) o;
        return idTab == tabEntity.idTab &&
                idParent == tabEntity.idParent &&
                position == tabEntity.position &&
                active == tabEntity.active &&
                hideHostMode == tabEntity.hideHostMode &&
                Objects.equals(module, tabEntity.module) &&
                Objects.equals(className, tabEntity.className) &&
                Objects.equals(icon, tabEntity.icon);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idTab, idParent, position, module, className, active, hideHostMode, icon);
    }
}
