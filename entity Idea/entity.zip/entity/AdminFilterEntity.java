package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "admin_filter", schema = "ps1761", catalog = "")
public class AdminFilterEntity {
    private int id;
    private int employee;
    private int shop;
    private String controller;
    private String action;
    private String filter;
    private String filterId;

    @Id
    @Column(name = "id", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "employee", nullable = false)
    public int getEmployee() {
        return employee;
    }

    public void setEmployee(int employee) {
        this.employee = employee;
    }

    @Basic
    @Column(name = "shop", nullable = false)
    public int getShop() {
        return shop;
    }

    public void setShop(int shop) {
        this.shop = shop;
    }

    @Basic
    @Column(name = "controller", nullable = false, length = 60)
    public String getController() {
        return controller;
    }

    public void setController(String controller) {
        this.controller = controller;
    }

    @Basic
    @Column(name = "action", nullable = false, length = 100)
    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    @Basic
    @Column(name = "filter", nullable = false, length = -1)
    public String getFilter() {
        return filter;
    }

    public void setFilter(String filter) {
        this.filter = filter;
    }

    @Basic
    @Column(name = "filter_id", nullable = false, length = 255)
    public String getFilterId() {
        return filterId;
    }

    public void setFilterId(String filterId) {
        this.filterId = filterId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AdminFilterEntity that = (AdminFilterEntity) o;
        return id == that.id &&
                employee == that.employee &&
                shop == that.shop &&
                Objects.equals(controller, that.controller) &&
                Objects.equals(action, that.action) &&
                Objects.equals(filter, that.filter) &&
                Objects.equals(filterId, that.filterId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, employee, shop, controller, action, filter, filterId);
    }
}
