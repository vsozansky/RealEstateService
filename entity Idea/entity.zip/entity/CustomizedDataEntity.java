package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name = "customized_data", schema = "ps1761", catalog = "")
@IdClass(CustomizedDataEntityPK.class)
public class CustomizedDataEntity {
    private int idCustomization;
    private byte type;
    private int index;
    private String value;
    private int idModule;
    private BigDecimal price;
    private BigDecimal weight;

    @Id
    @Column(name = "id_customization", nullable = false)
    public int getIdCustomization() {
        return idCustomization;
    }

    public void setIdCustomization(int idCustomization) {
        this.idCustomization = idCustomization;
    }

    @Id
    @Column(name = "type", nullable = false)
    public byte getType() {
        return type;
    }

    public void setType(byte type) {
        this.type = type;
    }

    @Id
    @Column(name = "index", nullable = false)
    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    @Basic
    @Column(name = "value", nullable = false, length = 255)
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Basic
    @Column(name = "id_module", nullable = false)
    public int getIdModule() {
        return idModule;
    }

    public void setIdModule(int idModule) {
        this.idModule = idModule;
    }

    @Basic
    @Column(name = "price", nullable = false, precision = 6)
    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    @Basic
    @Column(name = "weight", nullable = false, precision = 6)
    public BigDecimal getWeight() {
        return weight;
    }

    public void setWeight(BigDecimal weight) {
        this.weight = weight;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CustomizedDataEntity that = (CustomizedDataEntity) o;
        return idCustomization == that.idCustomization &&
                type == that.type &&
                index == that.index &&
                idModule == that.idModule &&
                Objects.equals(value, that.value) &&
                Objects.equals(price, that.price) &&
                Objects.equals(weight, that.weight);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCustomization, type, index, value, idModule, price, weight);
    }
}
