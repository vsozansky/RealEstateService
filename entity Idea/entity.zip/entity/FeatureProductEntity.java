package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "feature_product", schema = "ps1761", catalog = "")
@IdClass(FeatureProductEntityPK.class)
public class FeatureProductEntity {
    private int idFeature;
    private int idProduct;
    private int idFeatureValue;

    @Id
    @Column(name = "id_feature", nullable = false)
    public int getIdFeature() {
        return idFeature;
    }

    public void setIdFeature(int idFeature) {
        this.idFeature = idFeature;
    }

    @Id
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Id
    @Column(name = "id_feature_value", nullable = false)
    public int getIdFeatureValue() {
        return idFeatureValue;
    }

    public void setIdFeatureValue(int idFeatureValue) {
        this.idFeatureValue = idFeatureValue;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FeatureProductEntity that = (FeatureProductEntity) o;
        return idFeature == that.idFeature &&
                idProduct == that.idProduct &&
                idFeatureValue == that.idFeatureValue;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idFeature, idProduct, idFeatureValue);
    }
}
