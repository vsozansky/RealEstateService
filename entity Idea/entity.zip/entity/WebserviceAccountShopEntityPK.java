package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class WebserviceAccountShopEntityPK implements Serializable {
    private int idWebserviceAccount;
    private int idShop;

    @Column(name = "id_webservice_account", nullable = false)
    @Id
    public int getIdWebserviceAccount() {
        return idWebserviceAccount;
    }

    public void setIdWebserviceAccount(int idWebserviceAccount) {
        this.idWebserviceAccount = idWebserviceAccount;
    }

    @Column(name = "id_shop", nullable = false)
    @Id
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WebserviceAccountShopEntityPK that = (WebserviceAccountShopEntityPK) o;
        return idWebserviceAccount == that.idWebserviceAccount &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idWebserviceAccount, idShop);
    }
}
