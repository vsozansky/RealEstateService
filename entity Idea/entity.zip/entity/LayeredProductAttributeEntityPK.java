package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class LayeredProductAttributeEntityPK implements Serializable {
    private int idAttribute;
    private int idProduct;
    private int idShop;

    @Column(name = "id_attribute", nullable = false)
    @Id
    public int getIdAttribute() {
        return idAttribute;
    }

    public void setIdAttribute(int idAttribute) {
        this.idAttribute = idAttribute;
    }

    @Column(name = "id_product", nullable = false)
    @Id
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Column(name = "id_shop", nullable = false)
    @Id
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LayeredProductAttributeEntityPK that = (LayeredProductAttributeEntityPK) o;
        return idAttribute == that.idAttribute &&
                idProduct == that.idProduct &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAttribute, idProduct, idShop);
    }
}
