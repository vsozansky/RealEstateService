package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "specific_price_rule", schema = "ps1761", catalog = "")
public class SpecificPriceRuleEntity {
    private int idSpecificPriceRule;
    private String name;
    private int idShop;
    private int idCurrency;
    private int idCountry;
    private int idGroup;
    private Object fromQuantity;
    private BigDecimal price;
    private BigDecimal reduction;
    private byte reductionTax;
    private Object reductionType;
    private Timestamp from;
    private Timestamp to;

    @Id
    @Column(name = "id_specific_price_rule", nullable = false)
    public int getIdSpecificPriceRule() {
        return idSpecificPriceRule;
    }

    public void setIdSpecificPriceRule(int idSpecificPriceRule) {
        this.idSpecificPriceRule = idSpecificPriceRule;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 255)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "id_currency", nullable = false)
    public int getIdCurrency() {
        return idCurrency;
    }

    public void setIdCurrency(int idCurrency) {
        this.idCurrency = idCurrency;
    }

    @Basic
    @Column(name = "id_country", nullable = false)
    public int getIdCountry() {
        return idCountry;
    }

    public void setIdCountry(int idCountry) {
        this.idCountry = idCountry;
    }

    @Basic
    @Column(name = "id_group", nullable = false)
    public int getIdGroup() {
        return idGroup;
    }

    public void setIdGroup(int idGroup) {
        this.idGroup = idGroup;
    }

    @Basic
    @Column(name = "from_quantity", nullable = false)
    public Object getFromQuantity() {
        return fromQuantity;
    }

    public void setFromQuantity(Object fromQuantity) {
        this.fromQuantity = fromQuantity;
    }

    @Basic
    @Column(name = "price", nullable = true, precision = 6)
    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    @Basic
    @Column(name = "reduction", nullable = false, precision = 6)
    public BigDecimal getReduction() {
        return reduction;
    }

    public void setReduction(BigDecimal reduction) {
        this.reduction = reduction;
    }

    @Basic
    @Column(name = "reduction_tax", nullable = false)
    public byte getReductionTax() {
        return reductionTax;
    }

    public void setReductionTax(byte reductionTax) {
        this.reductionTax = reductionTax;
    }

    @Basic
    @Column(name = "reduction_type", nullable = false)
    public Object getReductionType() {
        return reductionType;
    }

    public void setReductionType(Object reductionType) {
        this.reductionType = reductionType;
    }

    @Basic
    @Column(name = "from", nullable = false)
    public Timestamp getFrom() {
        return from;
    }

    public void setFrom(Timestamp from) {
        this.from = from;
    }

    @Basic
    @Column(name = "to", nullable = false)
    public Timestamp getTo() {
        return to;
    }

    public void setTo(Timestamp to) {
        this.to = to;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SpecificPriceRuleEntity that = (SpecificPriceRuleEntity) o;
        return idSpecificPriceRule == that.idSpecificPriceRule &&
                idShop == that.idShop &&
                idCurrency == that.idCurrency &&
                idCountry == that.idCountry &&
                idGroup == that.idGroup &&
                reductionTax == that.reductionTax &&
                Objects.equals(name, that.name) &&
                Objects.equals(fromQuantity, that.fromQuantity) &&
                Objects.equals(price, that.price) &&
                Objects.equals(reduction, that.reduction) &&
                Objects.equals(reductionType, that.reductionType) &&
                Objects.equals(from, that.from) &&
                Objects.equals(to, that.to);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idSpecificPriceRule, name, idShop, idCurrency, idCountry, idGroup, fromQuantity, price, reduction, reductionTax, reductionType, from, to);
    }
}
