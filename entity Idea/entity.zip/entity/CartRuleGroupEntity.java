package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "cart_rule_group", schema = "ps1761", catalog = "")
@IdClass(CartRuleGroupEntityPK.class)
public class CartRuleGroupEntity {
    private int idCartRule;
    private int idGroup;

    @Id
    @Column(name = "id_cart_rule", nullable = false)
    public int getIdCartRule() {
        return idCartRule;
    }

    public void setIdCartRule(int idCartRule) {
        this.idCartRule = idCartRule;
    }

    @Id
    @Column(name = "id_group", nullable = false)
    public int getIdGroup() {
        return idGroup;
    }

    public void setIdGroup(int idGroup) {
        this.idGroup = idGroup;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CartRuleGroupEntity that = (CartRuleGroupEntity) o;
        return idCartRule == that.idCartRule &&
                idGroup == that.idGroup;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCartRule, idGroup);
    }
}
