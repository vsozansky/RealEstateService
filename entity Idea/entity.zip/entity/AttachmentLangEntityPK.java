package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class AttachmentLangEntityPK implements Serializable {
    private int idAttachment;
    private int idLang;

    @Column(name = "id_attachment", nullable = false)
    @Id
    public int getIdAttachment() {
        return idAttachment;
    }

    public void setIdAttachment(int idAttachment) {
        this.idAttachment = idAttachment;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AttachmentLangEntityPK that = (AttachmentLangEntityPK) o;
        return idAttachment == that.idAttachment &&
                idLang == that.idLang;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAttachment, idLang);
    }
}
