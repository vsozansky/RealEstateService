package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "hook_alias", schema = "ps1761", catalog = "")
public class HookAliasEntity {
    private int idHookAlias;
    private String alias;
    private String name;

    @Id
    @Column(name = "id_hook_alias", nullable = false)
    public int getIdHookAlias() {
        return idHookAlias;
    }

    public void setIdHookAlias(int idHookAlias) {
        this.idHookAlias = idHookAlias;
    }

    @Basic
    @Column(name = "alias", nullable = false, length = 64)
    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 64)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        HookAliasEntity that = (HookAliasEntity) o;
        return idHookAlias == that.idHookAlias &&
                Objects.equals(alias, that.alias) &&
                Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idHookAlias, alias, name);
    }
}
