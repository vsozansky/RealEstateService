package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "webservice_permission", schema = "ps1761", catalog = "")
public class WebservicePermissionEntity {
    private int idWebservicePermission;
    private String resource;
    private Object method;
    private int idWebserviceAccount;

    @Id
    @Column(name = "id_webservice_permission", nullable = false)
    public int getIdWebservicePermission() {
        return idWebservicePermission;
    }

    public void setIdWebservicePermission(int idWebservicePermission) {
        this.idWebservicePermission = idWebservicePermission;
    }

    @Basic
    @Column(name = "resource", nullable = false, length = 50)
    public String getResource() {
        return resource;
    }

    public void setResource(String resource) {
        this.resource = resource;
    }

    @Basic
    @Column(name = "method", nullable = false)
    public Object getMethod() {
        return method;
    }

    public void setMethod(Object method) {
        this.method = method;
    }

    @Basic
    @Column(name = "id_webservice_account", nullable = false)
    public int getIdWebserviceAccount() {
        return idWebserviceAccount;
    }

    public void setIdWebserviceAccount(int idWebserviceAccount) {
        this.idWebserviceAccount = idWebserviceAccount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WebservicePermissionEntity that = (WebservicePermissionEntity) o;
        return idWebservicePermission == that.idWebservicePermission &&
                idWebserviceAccount == that.idWebserviceAccount &&
                Objects.equals(resource, that.resource) &&
                Objects.equals(method, that.method);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idWebservicePermission, resource, method, idWebserviceAccount);
    }
}
