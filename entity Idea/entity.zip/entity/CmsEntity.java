package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "cms", schema = "ps1761", catalog = "")
public class CmsEntity {
    private int idCms;
    private int idCmsCategory;
    private int position;
    private byte active;
    private byte indexation;

    @Id
    @Column(name = "id_cms", nullable = false)
    public int getIdCms() {
        return idCms;
    }

    public void setIdCms(int idCms) {
        this.idCms = idCms;
    }

    @Basic
    @Column(name = "id_cms_category", nullable = false)
    public int getIdCmsCategory() {
        return idCmsCategory;
    }

    public void setIdCmsCategory(int idCmsCategory) {
        this.idCmsCategory = idCmsCategory;
    }

    @Basic
    @Column(name = "position", nullable = false)
    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    @Basic
    @Column(name = "active", nullable = false)
    public byte getActive() {
        return active;
    }

    public void setActive(byte active) {
        this.active = active;
    }

    @Basic
    @Column(name = "indexation", nullable = false)
    public byte getIndexation() {
        return indexation;
    }

    public void setIndexation(byte indexation) {
        this.indexation = indexation;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CmsEntity cmsEntity = (CmsEntity) o;
        return idCms == cmsEntity.idCms &&
                idCmsCategory == cmsEntity.idCmsCategory &&
                position == cmsEntity.position &&
                active == cmsEntity.active &&
                indexation == cmsEntity.indexation;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCms, idCmsCategory, position, active, indexation);
    }
}
