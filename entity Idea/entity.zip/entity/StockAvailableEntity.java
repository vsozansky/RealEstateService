package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "stock_available", schema = "ps1761", catalog = "")
public class StockAvailableEntity {
    private int idStockAvailable;
    private int idProduct;
    private int idProductAttribute;
    private int idShop;
    private int idShopGroup;
    private int quantity;
    private int physicalQuantity;
    private int reservedQuantity;
    private byte dependsOnStock;
    private byte outOfStock;
    private String location;

    @Id
    @Column(name = "id_stock_available", nullable = false)
    public int getIdStockAvailable() {
        return idStockAvailable;
    }

    public void setIdStockAvailable(int idStockAvailable) {
        this.idStockAvailable = idStockAvailable;
    }

    @Basic
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Basic
    @Column(name = "id_product_attribute", nullable = false)
    public int getIdProductAttribute() {
        return idProductAttribute;
    }

    public void setIdProductAttribute(int idProductAttribute) {
        this.idProductAttribute = idProductAttribute;
    }

    @Basic
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "id_shop_group", nullable = false)
    public int getIdShopGroup() {
        return idShopGroup;
    }

    public void setIdShopGroup(int idShopGroup) {
        this.idShopGroup = idShopGroup;
    }

    @Basic
    @Column(name = "quantity", nullable = false)
    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Basic
    @Column(name = "physical_quantity", nullable = false)
    public int getPhysicalQuantity() {
        return physicalQuantity;
    }

    public void setPhysicalQuantity(int physicalQuantity) {
        this.physicalQuantity = physicalQuantity;
    }

    @Basic
    @Column(name = "reserved_quantity", nullable = false)
    public int getReservedQuantity() {
        return reservedQuantity;
    }

    public void setReservedQuantity(int reservedQuantity) {
        this.reservedQuantity = reservedQuantity;
    }

    @Basic
    @Column(name = "depends_on_stock", nullable = false)
    public byte getDependsOnStock() {
        return dependsOnStock;
    }

    public void setDependsOnStock(byte dependsOnStock) {
        this.dependsOnStock = dependsOnStock;
    }

    @Basic
    @Column(name = "out_of_stock", nullable = false)
    public byte getOutOfStock() {
        return outOfStock;
    }

    public void setOutOfStock(byte outOfStock) {
        this.outOfStock = outOfStock;
    }

    @Basic
    @Column(name = "location", nullable = false, length = 255)
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StockAvailableEntity that = (StockAvailableEntity) o;
        return idStockAvailable == that.idStockAvailable &&
                idProduct == that.idProduct &&
                idProductAttribute == that.idProductAttribute &&
                idShop == that.idShop &&
                idShopGroup == that.idShopGroup &&
                quantity == that.quantity &&
                physicalQuantity == that.physicalQuantity &&
                reservedQuantity == that.reservedQuantity &&
                dependsOnStock == that.dependsOnStock &&
                outOfStock == that.outOfStock &&
                Objects.equals(location, that.location);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idStockAvailable, idProduct, idProductAttribute, idShop, idShopGroup, quantity, physicalQuantity, reservedQuantity, dependsOnStock, outOfStock, location);
    }
}
