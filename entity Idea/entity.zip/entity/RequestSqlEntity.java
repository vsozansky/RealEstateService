package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "request_sql", schema = "ps1761", catalog = "")
public class RequestSqlEntity {
    private int idRequestSql;
    private String name;
    private String sql;

    @Id
    @Column(name = "id_request_sql", nullable = false)
    public int getIdRequestSql() {
        return idRequestSql;
    }

    public void setIdRequestSql(int idRequestSql) {
        this.idRequestSql = idRequestSql;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 200)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "sql", nullable = false, length = -1)
    public String getSql() {
        return sql;
    }

    public void setSql(String sql) {
        this.sql = sql;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RequestSqlEntity that = (RequestSqlEntity) o;
        return idRequestSql == that.idRequestSql &&
                Objects.equals(name, that.name) &&
                Objects.equals(sql, that.sql);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idRequestSql, name, sql);
    }
}
