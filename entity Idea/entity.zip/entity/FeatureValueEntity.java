package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "feature_value", schema = "ps1761", catalog = "")
public class FeatureValueEntity {
    private int idFeatureValue;
    private int idFeature;
    private Byte custom;

    @Id
    @Column(name = "id_feature_value", nullable = false)
    public int getIdFeatureValue() {
        return idFeatureValue;
    }

    public void setIdFeatureValue(int idFeatureValue) {
        this.idFeatureValue = idFeatureValue;
    }

    @Basic
    @Column(name = "id_feature", nullable = false)
    public int getIdFeature() {
        return idFeature;
    }

    public void setIdFeature(int idFeature) {
        this.idFeature = idFeature;
    }

    @Basic
    @Column(name = "custom", nullable = true)
    public Byte getCustom() {
        return custom;
    }

    public void setCustom(Byte custom) {
        this.custom = custom;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FeatureValueEntity that = (FeatureValueEntity) o;
        return idFeatureValue == that.idFeatureValue &&
                idFeature == that.idFeature &&
                Objects.equals(custom, that.custom);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idFeatureValue, idFeature, custom);
    }
}
