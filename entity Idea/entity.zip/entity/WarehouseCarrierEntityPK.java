package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class WarehouseCarrierEntityPK implements Serializable {
    private int idCarrier;
    private int idWarehouse;

    @Column(name = "id_carrier", nullable = false)
    @Id
    public int getIdCarrier() {
        return idCarrier;
    }

    public void setIdCarrier(int idCarrier) {
        this.idCarrier = idCarrier;
    }

    @Column(name = "id_warehouse", nullable = false)
    @Id
    public int getIdWarehouse() {
        return idWarehouse;
    }

    public void setIdWarehouse(int idWarehouse) {
        this.idWarehouse = idWarehouse;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WarehouseCarrierEntityPK that = (WarehouseCarrierEntityPK) o;
        return idCarrier == that.idCarrier &&
                idWarehouse == that.idWarehouse;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCarrier, idWarehouse);
    }
}
