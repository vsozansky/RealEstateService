package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "condition", schema = "ps1761", catalog = "")
@IdClass(ConditionEntityPK.class)
public class ConditionEntity {
    private int idCondition;
    private int idPsCondition;
    private Object type;
    private String request;
    private String operator;
    private String value;
    private String result;
    private Object calculationType;
    private String calculationDetail;
    private byte validated;
    private Timestamp dateAdd;
    private Timestamp dateUpd;

    @Id
    @Column(name = "id_condition", nullable = false)
    public int getIdCondition() {
        return idCondition;
    }

    public void setIdCondition(int idCondition) {
        this.idCondition = idCondition;
    }

    @Id
    @Column(name = "id_ps_condition", nullable = false)
    public int getIdPsCondition() {
        return idPsCondition;
    }

    public void setIdPsCondition(int idPsCondition) {
        this.idPsCondition = idPsCondition;
    }

    @Basic
    @Column(name = "type", nullable = false)
    public Object getType() {
        return type;
    }

    public void setType(Object type) {
        this.type = type;
    }

    @Basic
    @Column(name = "request", nullable = true, length = -1)
    public String getRequest() {
        return request;
    }

    public void setRequest(String request) {
        this.request = request;
    }

    @Basic
    @Column(name = "operator", nullable = true, length = 32)
    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    @Basic
    @Column(name = "value", nullable = true, length = 64)
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Basic
    @Column(name = "result", nullable = true, length = 64)
    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    @Basic
    @Column(name = "calculation_type", nullable = true)
    public Object getCalculationType() {
        return calculationType;
    }

    public void setCalculationType(Object calculationType) {
        this.calculationType = calculationType;
    }

    @Basic
    @Column(name = "calculation_detail", nullable = true, length = 64)
    public String getCalculationDetail() {
        return calculationDetail;
    }

    public void setCalculationDetail(String calculationDetail) {
        this.calculationDetail = calculationDetail;
    }

    @Basic
    @Column(name = "validated", nullable = false)
    public byte getValidated() {
        return validated;
    }

    public void setValidated(byte validated) {
        this.validated = validated;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Basic
    @Column(name = "date_upd", nullable = false)
    public Timestamp getDateUpd() {
        return dateUpd;
    }

    public void setDateUpd(Timestamp dateUpd) {
        this.dateUpd = dateUpd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ConditionEntity that = (ConditionEntity) o;
        return idCondition == that.idCondition &&
                idPsCondition == that.idPsCondition &&
                validated == that.validated &&
                Objects.equals(type, that.type) &&
                Objects.equals(request, that.request) &&
                Objects.equals(operator, that.operator) &&
                Objects.equals(value, that.value) &&
                Objects.equals(result, that.result) &&
                Objects.equals(calculationType, that.calculationType) &&
                Objects.equals(calculationDetail, that.calculationDetail) &&
                Objects.equals(dateAdd, that.dateAdd) &&
                Objects.equals(dateUpd, that.dateUpd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCondition, idPsCondition, type, request, operator, value, result, calculationType, calculationDetail, validated, dateAdd, dateUpd);
    }
}
