package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name = "order_slip_detail", schema = "ps1761", catalog = "")
@IdClass(OrderSlipDetailEntityPK.class)
public class OrderSlipDetailEntity {
    private int idOrderSlip;
    private int idOrderDetail;
    private int productQuantity;
    private BigDecimal unitPriceTaxExcl;
    private BigDecimal unitPriceTaxIncl;
    private BigDecimal totalPriceTaxExcl;
    private BigDecimal totalPriceTaxIncl;
    private BigDecimal amountTaxExcl;
    private BigDecimal amountTaxIncl;

    @Id
    @Column(name = "id_order_slip", nullable = false)
    public int getIdOrderSlip() {
        return idOrderSlip;
    }

    public void setIdOrderSlip(int idOrderSlip) {
        this.idOrderSlip = idOrderSlip;
    }

    @Id
    @Column(name = "id_order_detail", nullable = false)
    public int getIdOrderDetail() {
        return idOrderDetail;
    }

    public void setIdOrderDetail(int idOrderDetail) {
        this.idOrderDetail = idOrderDetail;
    }

    @Basic
    @Column(name = "product_quantity", nullable = false)
    public int getProductQuantity() {
        return productQuantity;
    }

    public void setProductQuantity(int productQuantity) {
        this.productQuantity = productQuantity;
    }

    @Basic
    @Column(name = "unit_price_tax_excl", nullable = true, precision = 6)
    public BigDecimal getUnitPriceTaxExcl() {
        return unitPriceTaxExcl;
    }

    public void setUnitPriceTaxExcl(BigDecimal unitPriceTaxExcl) {
        this.unitPriceTaxExcl = unitPriceTaxExcl;
    }

    @Basic
    @Column(name = "unit_price_tax_incl", nullable = true, precision = 6)
    public BigDecimal getUnitPriceTaxIncl() {
        return unitPriceTaxIncl;
    }

    public void setUnitPriceTaxIncl(BigDecimal unitPriceTaxIncl) {
        this.unitPriceTaxIncl = unitPriceTaxIncl;
    }

    @Basic
    @Column(name = "total_price_tax_excl", nullable = true, precision = 6)
    public BigDecimal getTotalPriceTaxExcl() {
        return totalPriceTaxExcl;
    }

    public void setTotalPriceTaxExcl(BigDecimal totalPriceTaxExcl) {
        this.totalPriceTaxExcl = totalPriceTaxExcl;
    }

    @Basic
    @Column(name = "total_price_tax_incl", nullable = true, precision = 6)
    public BigDecimal getTotalPriceTaxIncl() {
        return totalPriceTaxIncl;
    }

    public void setTotalPriceTaxIncl(BigDecimal totalPriceTaxIncl) {
        this.totalPriceTaxIncl = totalPriceTaxIncl;
    }

    @Basic
    @Column(name = "amount_tax_excl", nullable = true, precision = 6)
    public BigDecimal getAmountTaxExcl() {
        return amountTaxExcl;
    }

    public void setAmountTaxExcl(BigDecimal amountTaxExcl) {
        this.amountTaxExcl = amountTaxExcl;
    }

    @Basic
    @Column(name = "amount_tax_incl", nullable = true, precision = 6)
    public BigDecimal getAmountTaxIncl() {
        return amountTaxIncl;
    }

    public void setAmountTaxIncl(BigDecimal amountTaxIncl) {
        this.amountTaxIncl = amountTaxIncl;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderSlipDetailEntity that = (OrderSlipDetailEntity) o;
        return idOrderSlip == that.idOrderSlip &&
                idOrderDetail == that.idOrderDetail &&
                productQuantity == that.productQuantity &&
                Objects.equals(unitPriceTaxExcl, that.unitPriceTaxExcl) &&
                Objects.equals(unitPriceTaxIncl, that.unitPriceTaxIncl) &&
                Objects.equals(totalPriceTaxExcl, that.totalPriceTaxExcl) &&
                Objects.equals(totalPriceTaxIncl, that.totalPriceTaxIncl) &&
                Objects.equals(amountTaxExcl, that.amountTaxExcl) &&
                Objects.equals(amountTaxIncl, that.amountTaxIncl);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrderSlip, idOrderDetail, productQuantity, unitPriceTaxExcl, unitPriceTaxIncl, totalPriceTaxExcl, totalPriceTaxIncl, amountTaxExcl, amountTaxIncl);
    }
}
