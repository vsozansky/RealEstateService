package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "image_type", schema = "ps1761", catalog = "")
public class ImageTypeEntity {
    private int idImageType;
    private String name;
    private int width;
    private int height;
    private byte products;
    private byte categories;
    private byte manufacturers;
    private byte suppliers;
    private byte stores;

    @Id
    @Column(name = "id_image_type", nullable = false)
    public int getIdImageType() {
        return idImageType;
    }

    public void setIdImageType(int idImageType) {
        this.idImageType = idImageType;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 64)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "width", nullable = false)
    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    @Basic
    @Column(name = "height", nullable = false)
    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    @Basic
    @Column(name = "products", nullable = false)
    public byte getProducts() {
        return products;
    }

    public void setProducts(byte products) {
        this.products = products;
    }

    @Basic
    @Column(name = "categories", nullable = false)
    public byte getCategories() {
        return categories;
    }

    public void setCategories(byte categories) {
        this.categories = categories;
    }

    @Basic
    @Column(name = "manufacturers", nullable = false)
    public byte getManufacturers() {
        return manufacturers;
    }

    public void setManufacturers(byte manufacturers) {
        this.manufacturers = manufacturers;
    }

    @Basic
    @Column(name = "suppliers", nullable = false)
    public byte getSuppliers() {
        return suppliers;
    }

    public void setSuppliers(byte suppliers) {
        this.suppliers = suppliers;
    }

    @Basic
    @Column(name = "stores", nullable = false)
    public byte getStores() {
        return stores;
    }

    public void setStores(byte stores) {
        this.stores = stores;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ImageTypeEntity that = (ImageTypeEntity) o;
        return idImageType == that.idImageType &&
                width == that.width &&
                height == that.height &&
                products == that.products &&
                categories == that.categories &&
                manufacturers == that.manufacturers &&
                suppliers == that.suppliers &&
                stores == that.stores &&
                Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idImageType, name, width, height, products, categories, manufacturers, suppliers, stores);
    }
}
