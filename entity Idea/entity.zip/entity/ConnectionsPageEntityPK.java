package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Objects;

public class ConnectionsPageEntityPK implements Serializable {
    private int idConnections;
    private int idPage;
    private Timestamp timeStart;

    @Column(name = "id_connections", nullable = false)
    @Id
    public int getIdConnections() {
        return idConnections;
    }

    public void setIdConnections(int idConnections) {
        this.idConnections = idConnections;
    }

    @Column(name = "id_page", nullable = false)
    @Id
    public int getIdPage() {
        return idPage;
    }

    public void setIdPage(int idPage) {
        this.idPage = idPage;
    }

    @Column(name = "time_start", nullable = false)
    @Id
    public Timestamp getTimeStart() {
        return timeStart;
    }

    public void setTimeStart(Timestamp timeStart) {
        this.timeStart = timeStart;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ConnectionsPageEntityPK that = (ConnectionsPageEntityPK) o;
        return idConnections == that.idConnections &&
                idPage == that.idPage &&
                Objects.equals(timeStart, that.timeStart);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idConnections, idPage, timeStart);
    }
}
