package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "cart_product", schema = "ps1761", catalog = "")
@IdClass(CartProductEntityPK.class)
public class CartProductEntity {
    private int idCart;
    private int idProduct;
    private int idAddressDelivery;
    private int idShop;
    private int idProductAttribute;
    private int idCustomization;
    private int quantity;
    private Timestamp dateAdd;

    @Id
    @Column(name = "id_cart", nullable = false)
    public int getIdCart() {
        return idCart;
    }

    public void setIdCart(int idCart) {
        this.idCart = idCart;
    }

    @Id
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Id
    @Column(name = "id_address_delivery", nullable = false)
    public int getIdAddressDelivery() {
        return idAddressDelivery;
    }

    public void setIdAddressDelivery(int idAddressDelivery) {
        this.idAddressDelivery = idAddressDelivery;
    }

    @Basic
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Id
    @Column(name = "id_product_attribute", nullable = false)
    public int getIdProductAttribute() {
        return idProductAttribute;
    }

    public void setIdProductAttribute(int idProductAttribute) {
        this.idProductAttribute = idProductAttribute;
    }

    @Id
    @Column(name = "id_customization", nullable = false)
    public int getIdCustomization() {
        return idCustomization;
    }

    public void setIdCustomization(int idCustomization) {
        this.idCustomization = idCustomization;
    }

    @Basic
    @Column(name = "quantity", nullable = false)
    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CartProductEntity that = (CartProductEntity) o;
        return idCart == that.idCart &&
                idProduct == that.idProduct &&
                idAddressDelivery == that.idAddressDelivery &&
                idShop == that.idShop &&
                idProductAttribute == that.idProductAttribute &&
                idCustomization == that.idCustomization &&
                quantity == that.quantity &&
                Objects.equals(dateAdd, that.dateAdd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCart, idProduct, idAddressDelivery, idShop, idProductAttribute, idCustomization, quantity, dateAdd);
    }
}
