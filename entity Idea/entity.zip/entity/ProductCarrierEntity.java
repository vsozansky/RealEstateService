package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "product_carrier", schema = "ps1761", catalog = "")
@IdClass(ProductCarrierEntityPK.class)
public class ProductCarrierEntity {
    private int idProduct;
    private int idCarrierReference;
    private int idShop;

    @Id
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Id
    @Column(name = "id_carrier_reference", nullable = false)
    public int getIdCarrierReference() {
        return idCarrierReference;
    }

    public void setIdCarrierReference(int idCarrierReference) {
        this.idCarrierReference = idCarrierReference;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductCarrierEntity that = (ProductCarrierEntity) o;
        return idProduct == that.idProduct &&
                idCarrierReference == that.idCarrierReference &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProduct, idCarrierReference, idShop);
    }
}
