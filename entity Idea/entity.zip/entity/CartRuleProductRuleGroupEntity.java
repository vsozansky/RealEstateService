package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "cart_rule_product_rule_group", schema = "ps1761", catalog = "")
public class CartRuleProductRuleGroupEntity {
    private int idProductRuleGroup;
    private int idCartRule;
    private int quantity;

    @Id
    @Column(name = "id_product_rule_group", nullable = false)
    public int getIdProductRuleGroup() {
        return idProductRuleGroup;
    }

    public void setIdProductRuleGroup(int idProductRuleGroup) {
        this.idProductRuleGroup = idProductRuleGroup;
    }

    @Basic
    @Column(name = "id_cart_rule", nullable = false)
    public int getIdCartRule() {
        return idCartRule;
    }

    public void setIdCartRule(int idCartRule) {
        this.idCartRule = idCartRule;
    }

    @Basic
    @Column(name = "quantity", nullable = false)
    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CartRuleProductRuleGroupEntity that = (CartRuleProductRuleGroupEntity) o;
        return idProductRuleGroup == that.idProductRuleGroup &&
                idCartRule == that.idCartRule &&
                quantity == that.quantity;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProductRuleGroup, idCartRule, quantity);
    }
}
