package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "product_attribute_image", schema = "ps1761", catalog = "")
@IdClass(ProductAttributeImageEntityPK.class)
public class ProductAttributeImageEntity {
    private int idProductAttribute;
    private int idImage;

    @Id
    @Column(name = "id_product_attribute", nullable = false)
    public int getIdProductAttribute() {
        return idProductAttribute;
    }

    public void setIdProductAttribute(int idProductAttribute) {
        this.idProductAttribute = idProductAttribute;
    }

    @Id
    @Column(name = "id_image", nullable = false)
    public int getIdImage() {
        return idImage;
    }

    public void setIdImage(int idImage) {
        this.idImage = idImage;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductAttributeImageEntity that = (ProductAttributeImageEntity) o;
        return idProductAttribute == that.idProductAttribute &&
                idImage == that.idImage;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProductAttribute, idImage);
    }
}
