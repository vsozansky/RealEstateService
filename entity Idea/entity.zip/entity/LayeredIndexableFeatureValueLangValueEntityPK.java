package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class LayeredIndexableFeatureValueLangValueEntityPK implements Serializable {
    private int idFeatureValue;
    private int idLang;

    @Column(name = "id_feature_value", nullable = false)
    @Id
    public int getIdFeatureValue() {
        return idFeatureValue;
    }

    public void setIdFeatureValue(int idFeatureValue) {
        this.idFeatureValue = idFeatureValue;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LayeredIndexableFeatureValueLangValueEntityPK that = (LayeredIndexableFeatureValueLangValueEntityPK) o;
        return idFeatureValue == that.idFeatureValue &&
                idLang == that.idLang;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idFeatureValue, idLang);
    }
}
