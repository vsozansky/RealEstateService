package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "order_message", schema = "ps1761", catalog = "")
public class OrderMessageEntity {
    private int idOrderMessage;
    private Timestamp dateAdd;

    @Id
    @Column(name = "id_order_message", nullable = false)
    public int getIdOrderMessage() {
        return idOrderMessage;
    }

    public void setIdOrderMessage(int idOrderMessage) {
        this.idOrderMessage = idOrderMessage;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderMessageEntity that = (OrderMessageEntity) o;
        return idOrderMessage == that.idOrderMessage &&
                Objects.equals(dateAdd, that.dateAdd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrderMessage, dateAdd);
    }
}
