package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "tag_count", schema = "ps1761", catalog = "")
@IdClass(TagCountEntityPK.class)
public class TagCountEntity {
    private int idGroup;
    private int idTag;
    private int idLang;
    private int idShop;
    private int counter;

    @Id
    @Column(name = "id_group", nullable = false)
    public int getIdGroup() {
        return idGroup;
    }

    public void setIdGroup(int idGroup) {
        this.idGroup = idGroup;
    }

    @Id
    @Column(name = "id_tag", nullable = false)
    public int getIdTag() {
        return idTag;
    }

    public void setIdTag(int idTag) {
        this.idTag = idTag;
    }

    @Basic
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "counter", nullable = false)
    public int getCounter() {
        return counter;
    }

    public void setCounter(int counter) {
        this.counter = counter;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TagCountEntity that = (TagCountEntity) o;
        return idGroup == that.idGroup &&
                idTag == that.idTag &&
                idLang == that.idLang &&
                idShop == that.idShop &&
                counter == that.counter;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idGroup, idTag, idLang, idShop, counter);
    }
}
