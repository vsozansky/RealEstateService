package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class CustomizedDataEntityPK implements Serializable {
    private int idCustomization;
    private byte type;
    private int index;

    @Column(name = "id_customization", nullable = false)
    @Id
    public int getIdCustomization() {
        return idCustomization;
    }

    public void setIdCustomization(int idCustomization) {
        this.idCustomization = idCustomization;
    }

    @Column(name = "type", nullable = false)
    @Id
    public byte getType() {
        return type;
    }

    public void setType(byte type) {
        this.type = type;
    }

    @Column(name = "index", nullable = false)
    @Id
    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CustomizedDataEntityPK that = (CustomizedDataEntityPK) o;
        return idCustomization == that.idCustomization &&
                type == that.type &&
                index == that.index;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCustomization, type, index);
    }
}
