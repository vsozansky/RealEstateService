package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "condition_advice", schema = "ps1761", catalog = "")
@IdClass(ConditionAdviceEntityPK.class)
public class ConditionAdviceEntity {
    private int idCondition;
    private int idAdvice;
    private byte display;

    @Id
    @Column(name = "id_condition", nullable = false)
    public int getIdCondition() {
        return idCondition;
    }

    public void setIdCondition(int idCondition) {
        this.idCondition = idCondition;
    }

    @Id
    @Column(name = "id_advice", nullable = false)
    public int getIdAdvice() {
        return idAdvice;
    }

    public void setIdAdvice(int idAdvice) {
        this.idAdvice = idAdvice;
    }

    @Basic
    @Column(name = "display", nullable = false)
    public byte getDisplay() {
        return display;
    }

    public void setDisplay(byte display) {
        this.display = display;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ConditionAdviceEntity that = (ConditionAdviceEntity) o;
        return idCondition == that.idCondition &&
                idAdvice == that.idAdvice &&
                display == that.display;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCondition, idAdvice, display);
    }
}
