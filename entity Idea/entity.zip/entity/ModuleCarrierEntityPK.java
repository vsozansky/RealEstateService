package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class ModuleCarrierEntityPK implements Serializable {
    private int idModule;
    private int idShop;
    private int idReference;

    @Column(name = "id_module", nullable = false)
    @Id
    public int getIdModule() {
        return idModule;
    }

    public void setIdModule(int idModule) {
        this.idModule = idModule;
    }

    @Column(name = "id_shop", nullable = false)
    @Id
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Column(name = "id_reference", nullable = false)
    @Id
    public int getIdReference() {
        return idReference;
    }

    public void setIdReference(int idReference) {
        this.idReference = idReference;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ModuleCarrierEntityPK that = (ModuleCarrierEntityPK) o;
        return idModule == that.idModule &&
                idShop == that.idShop &&
                idReference == that.idReference;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idModule, idShop, idReference);
    }
}
