package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class AccessEntityPK implements Serializable {
    private int idProfile;
    private int idAuthorizationRole;

    @Column(name = "id_profile", nullable = false)
    @Id
    public int getIdProfile() {
        return idProfile;
    }

    public void setIdProfile(int idProfile) {
        this.idProfile = idProfile;
    }

    @Column(name = "id_authorization_role", nullable = false)
    @Id
    public int getIdAuthorizationRole() {
        return idAuthorizationRole;
    }

    public void setIdAuthorizationRole(int idAuthorizationRole) {
        this.idAuthorizationRole = idAuthorizationRole;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AccessEntityPK that = (AccessEntityPK) o;
        return idProfile == that.idProfile &&
                idAuthorizationRole == that.idAuthorizationRole;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProfile, idAuthorizationRole);
    }
}
