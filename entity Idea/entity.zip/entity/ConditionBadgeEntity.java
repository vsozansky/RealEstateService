package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "condition_badge", schema = "ps1761", catalog = "")
@IdClass(ConditionBadgeEntityPK.class)
public class ConditionBadgeEntity {
    private int idCondition;
    private int idBadge;

    @Id
    @Column(name = "id_condition", nullable = false)
    public int getIdCondition() {
        return idCondition;
    }

    public void setIdCondition(int idCondition) {
        this.idCondition = idCondition;
    }

    @Id
    @Column(name = "id_badge", nullable = false)
    public int getIdBadge() {
        return idBadge;
    }

    public void setIdBadge(int idBadge) {
        this.idBadge = idBadge;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ConditionBadgeEntity that = (ConditionBadgeEntity) o;
        return idCondition == that.idCondition &&
                idBadge == that.idBadge;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCondition, idBadge);
    }
}
