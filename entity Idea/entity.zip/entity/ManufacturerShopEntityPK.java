package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class ManufacturerShopEntityPK implements Serializable {
    private int idManufacturer;
    private int idShop;

    @Column(name = "id_manufacturer", nullable = false)
    @Id
    public int getIdManufacturer() {
        return idManufacturer;
    }

    public void setIdManufacturer(int idManufacturer) {
        this.idManufacturer = idManufacturer;
    }

    @Column(name = "id_shop", nullable = false)
    @Id
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ManufacturerShopEntityPK that = (ManufacturerShopEntityPK) o;
        return idManufacturer == that.idManufacturer &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idManufacturer, idShop);
    }
}
