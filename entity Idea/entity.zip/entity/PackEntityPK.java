package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class PackEntityPK implements Serializable {
    private int idProductPack;
    private int idProductItem;
    private int idProductAttributeItem;

    @Column(name = "id_product_pack", nullable = false)
    @Id
    public int getIdProductPack() {
        return idProductPack;
    }

    public void setIdProductPack(int idProductPack) {
        this.idProductPack = idProductPack;
    }

    @Column(name = "id_product_item", nullable = false)
    @Id
    public int getIdProductItem() {
        return idProductItem;
    }

    public void setIdProductItem(int idProductItem) {
        this.idProductItem = idProductItem;
    }

    @Column(name = "id_product_attribute_item", nullable = false)
    @Id
    public int getIdProductAttributeItem() {
        return idProductAttributeItem;
    }

    public void setIdProductAttributeItem(int idProductAttributeItem) {
        this.idProductAttributeItem = idProductAttributeItem;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PackEntityPK that = (PackEntityPK) o;
        return idProductPack == that.idProductPack &&
                idProductItem == that.idProductItem &&
                idProductAttributeItem == that.idProductAttributeItem;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProductPack, idProductItem, idProductAttributeItem);
    }
}
