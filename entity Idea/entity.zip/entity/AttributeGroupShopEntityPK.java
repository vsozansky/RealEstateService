package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class AttributeGroupShopEntityPK implements Serializable {
    private int idAttributeGroup;
    private int idShop;

    @Column(name = "id_attribute_group", nullable = false)
    @Id
    public int getIdAttributeGroup() {
        return idAttributeGroup;
    }

    public void setIdAttributeGroup(int idAttributeGroup) {
        this.idAttributeGroup = idAttributeGroup;
    }

    @Column(name = "id_shop", nullable = false)
    @Id
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AttributeGroupShopEntityPK that = (AttributeGroupShopEntityPK) o;
        return idAttributeGroup == that.idAttributeGroup &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAttributeGroup, idShop);
    }
}
