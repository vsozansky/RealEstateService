package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class ImageLangEntityPK implements Serializable {
    private int idImage;
    private int idLang;

    @Column(name = "id_image", nullable = false)
    @Id
    public int getIdImage() {
        return idImage;
    }

    public void setIdImage(int idImage) {
        this.idImage = idImage;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ImageLangEntityPK that = (ImageLangEntityPK) o;
        return idImage == that.idImage &&
                idLang == that.idLang;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idImage, idLang);
    }
}
