package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "stock_mvt_reason_lang", schema = "ps1761", catalog = "")
@IdClass(StockMvtReasonLangEntityPK.class)
public class StockMvtReasonLangEntity {
    private int idStockMvtReason;
    private int idLang;
    private String name;

    @Id
    @Column(name = "id_stock_mvt_reason", nullable = false)
    public int getIdStockMvtReason() {
        return idStockMvtReason;
    }

    public void setIdStockMvtReason(int idStockMvtReason) {
        this.idStockMvtReason = idStockMvtReason;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 255)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StockMvtReasonLangEntity that = (StockMvtReasonLangEntity) o;
        return idStockMvtReason == that.idStockMvtReason &&
                idLang == that.idLang &&
                Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idStockMvtReason, idLang, name);
    }
}
