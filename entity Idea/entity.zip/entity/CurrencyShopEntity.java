package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name = "currency_shop", schema = "ps1761", catalog = "")
@IdClass(CurrencyShopEntityPK.class)
public class CurrencyShopEntity {
    private int idCurrency;
    private int idShop;
    private BigDecimal conversionRate;

    @Id
    @Column(name = "id_currency", nullable = false)
    public int getIdCurrency() {
        return idCurrency;
    }

    public void setIdCurrency(int idCurrency) {
        this.idCurrency = idCurrency;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "conversion_rate", nullable = false, precision = 6)
    public BigDecimal getConversionRate() {
        return conversionRate;
    }

    public void setConversionRate(BigDecimal conversionRate) {
        this.conversionRate = conversionRate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CurrencyShopEntity that = (CurrencyShopEntity) o;
        return idCurrency == that.idCurrency &&
                idShop == that.idShop &&
                Objects.equals(conversionRate, that.conversionRate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCurrency, idShop, conversionRate);
    }
}
