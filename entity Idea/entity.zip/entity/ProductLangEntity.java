package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "product_lang", schema = "ps1761", catalog = "")
@IdClass(ProductLangEntityPK.class)
public class ProductLangEntity {
    private int idProduct;
    private int idShop;
    private int idLang;
    private String description;
    private String descriptionShort;
    private String linkRewrite;
    private String metaDescription;
    private String metaKeywords;
    private String metaTitle;
    private String name;
    private String availableNow;
    private String availableLater;
    private String deliveryInStock;
    private String deliveryOutStock;

    @Id
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "description", nullable = true, length = -1)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Basic
    @Column(name = "description_short", nullable = true, length = -1)
    public String getDescriptionShort() {
        return descriptionShort;
    }

    public void setDescriptionShort(String descriptionShort) {
        this.descriptionShort = descriptionShort;
    }

    @Basic
    @Column(name = "link_rewrite", nullable = false, length = 128)
    public String getLinkRewrite() {
        return linkRewrite;
    }

    public void setLinkRewrite(String linkRewrite) {
        this.linkRewrite = linkRewrite;
    }

    @Basic
    @Column(name = "meta_description", nullable = true, length = 512)
    public String getMetaDescription() {
        return metaDescription;
    }

    public void setMetaDescription(String metaDescription) {
        this.metaDescription = metaDescription;
    }

    @Basic
    @Column(name = "meta_keywords", nullable = true, length = 255)
    public String getMetaKeywords() {
        return metaKeywords;
    }

    public void setMetaKeywords(String metaKeywords) {
        this.metaKeywords = metaKeywords;
    }

    @Basic
    @Column(name = "meta_title", nullable = true, length = 128)
    public String getMetaTitle() {
        return metaTitle;
    }

    public void setMetaTitle(String metaTitle) {
        this.metaTitle = metaTitle;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 128)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "available_now", nullable = true, length = 255)
    public String getAvailableNow() {
        return availableNow;
    }

    public void setAvailableNow(String availableNow) {
        this.availableNow = availableNow;
    }

    @Basic
    @Column(name = "available_later", nullable = true, length = 255)
    public String getAvailableLater() {
        return availableLater;
    }

    public void setAvailableLater(String availableLater) {
        this.availableLater = availableLater;
    }

    @Basic
    @Column(name = "delivery_in_stock", nullable = true, length = 255)
    public String getDeliveryInStock() {
        return deliveryInStock;
    }

    public void setDeliveryInStock(String deliveryInStock) {
        this.deliveryInStock = deliveryInStock;
    }

    @Basic
    @Column(name = "delivery_out_stock", nullable = true, length = 255)
    public String getDeliveryOutStock() {
        return deliveryOutStock;
    }

    public void setDeliveryOutStock(String deliveryOutStock) {
        this.deliveryOutStock = deliveryOutStock;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductLangEntity that = (ProductLangEntity) o;
        return idProduct == that.idProduct &&
                idShop == that.idShop &&
                idLang == that.idLang &&
                Objects.equals(description, that.description) &&
                Objects.equals(descriptionShort, that.descriptionShort) &&
                Objects.equals(linkRewrite, that.linkRewrite) &&
                Objects.equals(metaDescription, that.metaDescription) &&
                Objects.equals(metaKeywords, that.metaKeywords) &&
                Objects.equals(metaTitle, that.metaTitle) &&
                Objects.equals(name, that.name) &&
                Objects.equals(availableNow, that.availableNow) &&
                Objects.equals(availableLater, that.availableLater) &&
                Objects.equals(deliveryInStock, that.deliveryInStock) &&
                Objects.equals(deliveryOutStock, that.deliveryOutStock);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProduct, idShop, idLang, description, descriptionShort, linkRewrite, metaDescription, metaKeywords, metaTitle, name, availableNow, availableLater, deliveryInStock, deliveryOutStock);
    }
}
