package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class CmsRoleEntityPK implements Serializable {
    private int idCmsRole;
    private int idCms;

    @Column(name = "id_cms_role", nullable = false)
    @Id
    public int getIdCmsRole() {
        return idCmsRole;
    }

    public void setIdCmsRole(int idCmsRole) {
        this.idCmsRole = idCmsRole;
    }

    @Column(name = "id_cms", nullable = false)
    @Id
    public int getIdCms() {
        return idCms;
    }

    public void setIdCms(int idCms) {
        this.idCms = idCms;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CmsRoleEntityPK that = (CmsRoleEntityPK) o;
        return idCmsRole == that.idCmsRole &&
                idCms == that.idCms;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCmsRole, idCms);
    }
}
