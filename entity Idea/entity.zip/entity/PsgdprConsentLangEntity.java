package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "psgdpr_consent_lang", schema = "ps1761", catalog = "")
@IdClass(PsgdprConsentLangEntityPK.class)
public class PsgdprConsentLangEntity {
    private int idGdprConsent;
    private int idLang;
    private String message;
    private int idShop;

    @Id
    @Column(name = "id_gdpr_consent", nullable = false)
    public int getIdGdprConsent() {
        return idGdprConsent;
    }

    public void setIdGdprConsent(int idGdprConsent) {
        this.idGdprConsent = idGdprConsent;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "message", nullable = true, length = -1)
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PsgdprConsentLangEntity that = (PsgdprConsentLangEntity) o;
        return idGdprConsent == that.idGdprConsent &&
                idLang == that.idLang &&
                idShop == that.idShop &&
                Objects.equals(message, that.message);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idGdprConsent, idLang, message, idShop);
    }
}
