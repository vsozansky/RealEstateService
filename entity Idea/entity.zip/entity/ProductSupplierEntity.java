package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name = "product_supplier", schema = "ps1761", catalog = "")
public class ProductSupplierEntity {
    private int idProductSupplier;
    private int idProduct;
    private int idProductAttribute;
    private int idSupplier;
    private String productSupplierReference;
    private BigDecimal productSupplierPriceTe;
    private int idCurrency;

    @Id
    @Column(name = "id_product_supplier", nullable = false)
    public int getIdProductSupplier() {
        return idProductSupplier;
    }

    public void setIdProductSupplier(int idProductSupplier) {
        this.idProductSupplier = idProductSupplier;
    }

    @Basic
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Basic
    @Column(name = "id_product_attribute", nullable = false)
    public int getIdProductAttribute() {
        return idProductAttribute;
    }

    public void setIdProductAttribute(int idProductAttribute) {
        this.idProductAttribute = idProductAttribute;
    }

    @Basic
    @Column(name = "id_supplier", nullable = false)
    public int getIdSupplier() {
        return idSupplier;
    }

    public void setIdSupplier(int idSupplier) {
        this.idSupplier = idSupplier;
    }

    @Basic
    @Column(name = "product_supplier_reference", nullable = true, length = 64)
    public String getProductSupplierReference() {
        return productSupplierReference;
    }

    public void setProductSupplierReference(String productSupplierReference) {
        this.productSupplierReference = productSupplierReference;
    }

    @Basic
    @Column(name = "product_supplier_price_te", nullable = false, precision = 6)
    public BigDecimal getProductSupplierPriceTe() {
        return productSupplierPriceTe;
    }

    public void setProductSupplierPriceTe(BigDecimal productSupplierPriceTe) {
        this.productSupplierPriceTe = productSupplierPriceTe;
    }

    @Basic
    @Column(name = "id_currency", nullable = false)
    public int getIdCurrency() {
        return idCurrency;
    }

    public void setIdCurrency(int idCurrency) {
        this.idCurrency = idCurrency;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductSupplierEntity that = (ProductSupplierEntity) o;
        return idProductSupplier == that.idProductSupplier &&
                idProduct == that.idProduct &&
                idProductAttribute == that.idProductAttribute &&
                idSupplier == that.idSupplier &&
                idCurrency == that.idCurrency &&
                Objects.equals(productSupplierReference, that.productSupplierReference) &&
                Objects.equals(productSupplierPriceTe, that.productSupplierPriceTe);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProductSupplier, idProduct, idProductAttribute, idSupplier, productSupplierReference, productSupplierPriceTe, idCurrency);
    }
}
