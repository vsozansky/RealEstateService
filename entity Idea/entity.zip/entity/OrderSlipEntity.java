package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "order_slip", schema = "ps1761", catalog = "")
public class OrderSlipEntity {
    private int idOrderSlip;
    private BigDecimal conversionRate;
    private int idCustomer;
    private int idOrder;
    private BigDecimal totalProductsTaxExcl;
    private BigDecimal totalProductsTaxIncl;
    private BigDecimal totalShippingTaxExcl;
    private BigDecimal totalShippingTaxIncl;
    private byte shippingCost;
    private BigDecimal amount;
    private BigDecimal shippingCostAmount;
    private byte partial;
    private byte orderSlipType;
    private Timestamp dateAdd;
    private Timestamp dateUpd;

    @Id
    @Column(name = "id_order_slip", nullable = false)
    public int getIdOrderSlip() {
        return idOrderSlip;
    }

    public void setIdOrderSlip(int idOrderSlip) {
        this.idOrderSlip = idOrderSlip;
    }

    @Basic
    @Column(name = "conversion_rate", nullable = false, precision = 6)
    public BigDecimal getConversionRate() {
        return conversionRate;
    }

    public void setConversionRate(BigDecimal conversionRate) {
        this.conversionRate = conversionRate;
    }

    @Basic
    @Column(name = "id_customer", nullable = false)
    public int getIdCustomer() {
        return idCustomer;
    }

    public void setIdCustomer(int idCustomer) {
        this.idCustomer = idCustomer;
    }

    @Basic
    @Column(name = "id_order", nullable = false)
    public int getIdOrder() {
        return idOrder;
    }

    public void setIdOrder(int idOrder) {
        this.idOrder = idOrder;
    }

    @Basic
    @Column(name = "total_products_tax_excl", nullable = true, precision = 6)
    public BigDecimal getTotalProductsTaxExcl() {
        return totalProductsTaxExcl;
    }

    public void setTotalProductsTaxExcl(BigDecimal totalProductsTaxExcl) {
        this.totalProductsTaxExcl = totalProductsTaxExcl;
    }

    @Basic
    @Column(name = "total_products_tax_incl", nullable = true, precision = 6)
    public BigDecimal getTotalProductsTaxIncl() {
        return totalProductsTaxIncl;
    }

    public void setTotalProductsTaxIncl(BigDecimal totalProductsTaxIncl) {
        this.totalProductsTaxIncl = totalProductsTaxIncl;
    }

    @Basic
    @Column(name = "total_shipping_tax_excl", nullable = true, precision = 6)
    public BigDecimal getTotalShippingTaxExcl() {
        return totalShippingTaxExcl;
    }

    public void setTotalShippingTaxExcl(BigDecimal totalShippingTaxExcl) {
        this.totalShippingTaxExcl = totalShippingTaxExcl;
    }

    @Basic
    @Column(name = "total_shipping_tax_incl", nullable = true, precision = 6)
    public BigDecimal getTotalShippingTaxIncl() {
        return totalShippingTaxIncl;
    }

    public void setTotalShippingTaxIncl(BigDecimal totalShippingTaxIncl) {
        this.totalShippingTaxIncl = totalShippingTaxIncl;
    }

    @Basic
    @Column(name = "shipping_cost", nullable = false)
    public byte getShippingCost() {
        return shippingCost;
    }

    public void setShippingCost(byte shippingCost) {
        this.shippingCost = shippingCost;
    }

    @Basic
    @Column(name = "amount", nullable = false, precision = 2)
    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    @Basic
    @Column(name = "shipping_cost_amount", nullable = false, precision = 2)
    public BigDecimal getShippingCostAmount() {
        return shippingCostAmount;
    }

    public void setShippingCostAmount(BigDecimal shippingCostAmount) {
        this.shippingCostAmount = shippingCostAmount;
    }

    @Basic
    @Column(name = "partial", nullable = false)
    public byte getPartial() {
        return partial;
    }

    public void setPartial(byte partial) {
        this.partial = partial;
    }

    @Basic
    @Column(name = "order_slip_type", nullable = false)
    public byte getOrderSlipType() {
        return orderSlipType;
    }

    public void setOrderSlipType(byte orderSlipType) {
        this.orderSlipType = orderSlipType;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Basic
    @Column(name = "date_upd", nullable = false)
    public Timestamp getDateUpd() {
        return dateUpd;
    }

    public void setDateUpd(Timestamp dateUpd) {
        this.dateUpd = dateUpd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderSlipEntity that = (OrderSlipEntity) o;
        return idOrderSlip == that.idOrderSlip &&
                idCustomer == that.idCustomer &&
                idOrder == that.idOrder &&
                shippingCost == that.shippingCost &&
                partial == that.partial &&
                orderSlipType == that.orderSlipType &&
                Objects.equals(conversionRate, that.conversionRate) &&
                Objects.equals(totalProductsTaxExcl, that.totalProductsTaxExcl) &&
                Objects.equals(totalProductsTaxIncl, that.totalProductsTaxIncl) &&
                Objects.equals(totalShippingTaxExcl, that.totalShippingTaxExcl) &&
                Objects.equals(totalShippingTaxIncl, that.totalShippingTaxIncl) &&
                Objects.equals(amount, that.amount) &&
                Objects.equals(shippingCostAmount, that.shippingCostAmount) &&
                Objects.equals(dateAdd, that.dateAdd) &&
                Objects.equals(dateUpd, that.dateUpd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrderSlip, conversionRate, idCustomer, idOrder, totalProductsTaxExcl, totalProductsTaxIncl, totalShippingTaxExcl, totalShippingTaxIncl, shippingCost, amount, shippingCostAmount, partial, orderSlipType, dateAdd, dateUpd);
    }
}
