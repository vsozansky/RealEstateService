package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "warehouse_carrier", schema = "ps1761", catalog = "")
@IdClass(WarehouseCarrierEntityPK.class)
public class WarehouseCarrierEntity {
    private int idCarrier;
    private int idWarehouse;

    @Id
    @Column(name = "id_carrier", nullable = false)
    public int getIdCarrier() {
        return idCarrier;
    }

    public void setIdCarrier(int idCarrier) {
        this.idCarrier = idCarrier;
    }

    @Id
    @Column(name = "id_warehouse", nullable = false)
    public int getIdWarehouse() {
        return idWarehouse;
    }

    public void setIdWarehouse(int idWarehouse) {
        this.idWarehouse = idWarehouse;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WarehouseCarrierEntity that = (WarehouseCarrierEntity) o;
        return idCarrier == that.idCarrier &&
                idWarehouse == that.idWarehouse;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCarrier, idWarehouse);
    }
}
