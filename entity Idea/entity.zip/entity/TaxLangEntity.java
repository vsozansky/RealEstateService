package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "tax_lang", schema = "ps1761", catalog = "")
@IdClass(TaxLangEntityPK.class)
public class TaxLangEntity {
    private int idTax;
    private int idLang;
    private String name;

    @Id
    @Column(name = "id_tax", nullable = false)
    public int getIdTax() {
        return idTax;
    }

    public void setIdTax(int idTax) {
        this.idTax = idTax;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 32)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TaxLangEntity that = (TaxLangEntity) o;
        return idTax == that.idTax &&
                idLang == that.idLang &&
                Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idTax, idLang, name);
    }
}
