package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class PageViewedEntityPK implements Serializable {
    private int idPage;
    private int idShop;
    private int idDateRange;

    @Column(name = "id_page", nullable = false)
    @Id
    public int getIdPage() {
        return idPage;
    }

    public void setIdPage(int idPage) {
        this.idPage = idPage;
    }

    @Column(name = "id_shop", nullable = false)
    @Id
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Column(name = "id_date_range", nullable = false)
    @Id
    public int getIdDateRange() {
        return idDateRange;
    }

    public void setIdDateRange(int idDateRange) {
        this.idDateRange = idDateRange;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PageViewedEntityPK that = (PageViewedEntityPK) o;
        return idPage == that.idPage &&
                idShop == that.idShop &&
                idDateRange == that.idDateRange;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPage, idShop, idDateRange);
    }
}
