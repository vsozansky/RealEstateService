package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "order_state", schema = "ps1761", catalog = "")
public class OrderStateEntity {
    private int idOrderState;
    private Byte invoice;
    private byte sendEmail;
    private String moduleName;
    private String color;
    private byte unremovable;
    private byte hidden;
    private byte logable;
    private byte delivery;
    private byte shipped;
    private byte paid;
    private byte pdfInvoice;
    private byte pdfDelivery;
    private byte deleted;

    @Id
    @Column(name = "id_order_state", nullable = false)
    public int getIdOrderState() {
        return idOrderState;
    }

    public void setIdOrderState(int idOrderState) {
        this.idOrderState = idOrderState;
    }

    @Basic
    @Column(name = "invoice", nullable = true)
    public Byte getInvoice() {
        return invoice;
    }

    public void setInvoice(Byte invoice) {
        this.invoice = invoice;
    }

    @Basic
    @Column(name = "send_email", nullable = false)
    public byte getSendEmail() {
        return sendEmail;
    }

    public void setSendEmail(byte sendEmail) {
        this.sendEmail = sendEmail;
    }

    @Basic
    @Column(name = "module_name", nullable = true, length = 255)
    public String getModuleName() {
        return moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    @Basic
    @Column(name = "color", nullable = true, length = 32)
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Basic
    @Column(name = "unremovable", nullable = false)
    public byte getUnremovable() {
        return unremovable;
    }

    public void setUnremovable(byte unremovable) {
        this.unremovable = unremovable;
    }

    @Basic
    @Column(name = "hidden", nullable = false)
    public byte getHidden() {
        return hidden;
    }

    public void setHidden(byte hidden) {
        this.hidden = hidden;
    }

    @Basic
    @Column(name = "logable", nullable = false)
    public byte getLogable() {
        return logable;
    }

    public void setLogable(byte logable) {
        this.logable = logable;
    }

    @Basic
    @Column(name = "delivery", nullable = false)
    public byte getDelivery() {
        return delivery;
    }

    public void setDelivery(byte delivery) {
        this.delivery = delivery;
    }

    @Basic
    @Column(name = "shipped", nullable = false)
    public byte getShipped() {
        return shipped;
    }

    public void setShipped(byte shipped) {
        this.shipped = shipped;
    }

    @Basic
    @Column(name = "paid", nullable = false)
    public byte getPaid() {
        return paid;
    }

    public void setPaid(byte paid) {
        this.paid = paid;
    }

    @Basic
    @Column(name = "pdf_invoice", nullable = false)
    public byte getPdfInvoice() {
        return pdfInvoice;
    }

    public void setPdfInvoice(byte pdfInvoice) {
        this.pdfInvoice = pdfInvoice;
    }

    @Basic
    @Column(name = "pdf_delivery", nullable = false)
    public byte getPdfDelivery() {
        return pdfDelivery;
    }

    public void setPdfDelivery(byte pdfDelivery) {
        this.pdfDelivery = pdfDelivery;
    }

    @Basic
    @Column(name = "deleted", nullable = false)
    public byte getDeleted() {
        return deleted;
    }

    public void setDeleted(byte deleted) {
        this.deleted = deleted;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderStateEntity that = (OrderStateEntity) o;
        return idOrderState == that.idOrderState &&
                sendEmail == that.sendEmail &&
                unremovable == that.unremovable &&
                hidden == that.hidden &&
                logable == that.logable &&
                delivery == that.delivery &&
                shipped == that.shipped &&
                paid == that.paid &&
                pdfInvoice == that.pdfInvoice &&
                pdfDelivery == that.pdfDelivery &&
                deleted == that.deleted &&
                Objects.equals(invoice, that.invoice) &&
                Objects.equals(moduleName, that.moduleName) &&
                Objects.equals(color, that.color);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrderState, invoice, sendEmail, moduleName, color, unremovable, hidden, logable, delivery, shipped, paid, pdfInvoice, pdfDelivery, deleted);
    }
}
