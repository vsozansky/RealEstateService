package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class ProductCarrierEntityPK implements Serializable {
    private int idProduct;
    private int idCarrierReference;
    private int idShop;

    @Column(name = "id_product", nullable = false)
    @Id
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Column(name = "id_carrier_reference", nullable = false)
    @Id
    public int getIdCarrierReference() {
        return idCarrierReference;
    }

    public void setIdCarrierReference(int idCarrierReference) {
        this.idCarrierReference = idCarrierReference;
    }

    @Column(name = "id_shop", nullable = false)
    @Id
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductCarrierEntityPK that = (ProductCarrierEntityPK) o;
        return idProduct == that.idProduct &&
                idCarrierReference == that.idCarrierReference &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProduct, idCarrierReference, idShop);
    }
}
