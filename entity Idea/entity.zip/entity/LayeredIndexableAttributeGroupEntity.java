package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "layered_indexable_attribute_group", schema = "ps1761", catalog = "")
public class LayeredIndexableAttributeGroupEntity {
    private int idAttributeGroup;
    private byte indexable;

    @Id
    @Column(name = "id_attribute_group", nullable = false)
    public int getIdAttributeGroup() {
        return idAttributeGroup;
    }

    public void setIdAttributeGroup(int idAttributeGroup) {
        this.idAttributeGroup = idAttributeGroup;
    }

    @Basic
    @Column(name = "indexable", nullable = false)
    public byte getIndexable() {
        return indexable;
    }

    public void setIndexable(byte indexable) {
        this.indexable = indexable;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LayeredIndexableAttributeGroupEntity that = (LayeredIndexableAttributeGroupEntity) o;
        return idAttributeGroup == that.idAttributeGroup &&
                indexable == that.indexable;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAttributeGroup, indexable);
    }
}
