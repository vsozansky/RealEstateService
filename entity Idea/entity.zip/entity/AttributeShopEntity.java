package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "attribute_shop", schema = "ps1761", catalog = "")
@IdClass(AttributeShopEntityPK.class)
public class AttributeShopEntity {
    private int idAttribute;
    private int idShop;

    @Id
    @Column(name = "id_attribute", nullable = false)
    public int getIdAttribute() {
        return idAttribute;
    }

    public void setIdAttribute(int idAttribute) {
        this.idAttribute = idAttribute;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AttributeShopEntity that = (AttributeShopEntity) o;
        return idAttribute == that.idAttribute &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAttribute, idShop);
    }
}
