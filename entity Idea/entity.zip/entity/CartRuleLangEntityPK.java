package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class CartRuleLangEntityPK implements Serializable {
    private int idCartRule;
    private int idLang;

    @Column(name = "id_cart_rule", nullable = false)
    @Id
    public int getIdCartRule() {
        return idCartRule;
    }

    public void setIdCartRule(int idCartRule) {
        this.idCartRule = idCartRule;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CartRuleLangEntityPK that = (CartRuleLangEntityPK) o;
        return idCartRule == that.idCartRule &&
                idLang == that.idLang;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCartRule, idLang);
    }
}
