package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class SupplyOrderStateLangEntityPK implements Serializable {
    private int idSupplyOrderState;
    private int idLang;

    @Column(name = "id_supply_order_state", nullable = false)
    @Id
    public int getIdSupplyOrderState() {
        return idSupplyOrderState;
    }

    public void setIdSupplyOrderState(int idSupplyOrderState) {
        this.idSupplyOrderState = idSupplyOrderState;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SupplyOrderStateLangEntityPK that = (SupplyOrderStateLangEntityPK) o;
        return idSupplyOrderState == that.idSupplyOrderState &&
                idLang == that.idLang;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idSupplyOrderState, idLang);
    }
}
