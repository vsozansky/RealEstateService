package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "configuration_kpi_lang", schema = "ps1761", catalog = "")
@IdClass(ConfigurationKpiLangEntityPK.class)
public class ConfigurationKpiLangEntity {
    private int idConfigurationKpi;
    private int idLang;
    private String value;
    private Timestamp dateUpd;

    @Id
    @Column(name = "id_configuration_kpi", nullable = false)
    public int getIdConfigurationKpi() {
        return idConfigurationKpi;
    }

    public void setIdConfigurationKpi(int idConfigurationKpi) {
        this.idConfigurationKpi = idConfigurationKpi;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "value", nullable = true, length = -1)
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Basic
    @Column(name = "date_upd", nullable = true)
    public Timestamp getDateUpd() {
        return dateUpd;
    }

    public void setDateUpd(Timestamp dateUpd) {
        this.dateUpd = dateUpd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ConfigurationKpiLangEntity that = (ConfigurationKpiLangEntity) o;
        return idConfigurationKpi == that.idConfigurationKpi &&
                idLang == that.idLang &&
                Objects.equals(value, that.value) &&
                Objects.equals(dateUpd, that.dateUpd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idConfigurationKpi, idLang, value, dateUpd);
    }
}
