package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class SupplierShopEntityPK implements Serializable {
    private int idSupplier;
    private int idShop;

    @Column(name = "id_supplier", nullable = false)
    @Id
    public int getIdSupplier() {
        return idSupplier;
    }

    public void setIdSupplier(int idSupplier) {
        this.idSupplier = idSupplier;
    }

    @Column(name = "id_shop", nullable = false)
    @Id
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SupplierShopEntityPK that = (SupplierShopEntityPK) o;
        return idSupplier == that.idSupplier &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idSupplier, idShop);
    }
}
