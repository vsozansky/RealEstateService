package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "stock_mvt", schema = "ps1761", catalog = "")
public class StockMvtEntity {
    private long idStockMvt;
    private int idStock;
    private Integer idOrder;
    private Integer idSupplyOrder;
    private int idStockMvtReason;
    private int idEmployee;
    private String employeeLastname;
    private String employeeFirstname;
    private int physicalQuantity;
    private Timestamp dateAdd;
    private short sign;
    private BigDecimal priceTe;
    private BigDecimal lastWa;
    private BigDecimal currentWa;
    private Long referer;

    @Id
    @Column(name = "id_stock_mvt", nullable = false)
    public long getIdStockMvt() {
        return idStockMvt;
    }

    public void setIdStockMvt(long idStockMvt) {
        this.idStockMvt = idStockMvt;
    }

    @Basic
    @Column(name = "id_stock", nullable = false)
    public int getIdStock() {
        return idStock;
    }

    public void setIdStock(int idStock) {
        this.idStock = idStock;
    }

    @Basic
    @Column(name = "id_order", nullable = true)
    public Integer getIdOrder() {
        return idOrder;
    }

    public void setIdOrder(Integer idOrder) {
        this.idOrder = idOrder;
    }

    @Basic
    @Column(name = "id_supply_order", nullable = true)
    public Integer getIdSupplyOrder() {
        return idSupplyOrder;
    }

    public void setIdSupplyOrder(Integer idSupplyOrder) {
        this.idSupplyOrder = idSupplyOrder;
    }

    @Basic
    @Column(name = "id_stock_mvt_reason", nullable = false)
    public int getIdStockMvtReason() {
        return idStockMvtReason;
    }

    public void setIdStockMvtReason(int idStockMvtReason) {
        this.idStockMvtReason = idStockMvtReason;
    }

    @Basic
    @Column(name = "id_employee", nullable = false)
    public int getIdEmployee() {
        return idEmployee;
    }

    public void setIdEmployee(int idEmployee) {
        this.idEmployee = idEmployee;
    }

    @Basic
    @Column(name = "employee_lastname", nullable = true, length = 32)
    public String getEmployeeLastname() {
        return employeeLastname;
    }

    public void setEmployeeLastname(String employeeLastname) {
        this.employeeLastname = employeeLastname;
    }

    @Basic
    @Column(name = "employee_firstname", nullable = true, length = 32)
    public String getEmployeeFirstname() {
        return employeeFirstname;
    }

    public void setEmployeeFirstname(String employeeFirstname) {
        this.employeeFirstname = employeeFirstname;
    }

    @Basic
    @Column(name = "physical_quantity", nullable = false)
    public int getPhysicalQuantity() {
        return physicalQuantity;
    }

    public void setPhysicalQuantity(int physicalQuantity) {
        this.physicalQuantity = physicalQuantity;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Basic
    @Column(name = "sign", nullable = false)
    public short getSign() {
        return sign;
    }

    public void setSign(short sign) {
        this.sign = sign;
    }

    @Basic
    @Column(name = "price_te", nullable = true, precision = 6)
    public BigDecimal getPriceTe() {
        return priceTe;
    }

    public void setPriceTe(BigDecimal priceTe) {
        this.priceTe = priceTe;
    }

    @Basic
    @Column(name = "last_wa", nullable = true, precision = 6)
    public BigDecimal getLastWa() {
        return lastWa;
    }

    public void setLastWa(BigDecimal lastWa) {
        this.lastWa = lastWa;
    }

    @Basic
    @Column(name = "current_wa", nullable = true, precision = 6)
    public BigDecimal getCurrentWa() {
        return currentWa;
    }

    public void setCurrentWa(BigDecimal currentWa) {
        this.currentWa = currentWa;
    }

    @Basic
    @Column(name = "referer", nullable = true)
    public Long getReferer() {
        return referer;
    }

    public void setReferer(Long referer) {
        this.referer = referer;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StockMvtEntity that = (StockMvtEntity) o;
        return idStockMvt == that.idStockMvt &&
                idStock == that.idStock &&
                idStockMvtReason == that.idStockMvtReason &&
                idEmployee == that.idEmployee &&
                physicalQuantity == that.physicalQuantity &&
                sign == that.sign &&
                Objects.equals(idOrder, that.idOrder) &&
                Objects.equals(idSupplyOrder, that.idSupplyOrder) &&
                Objects.equals(employeeLastname, that.employeeLastname) &&
                Objects.equals(employeeFirstname, that.employeeFirstname) &&
                Objects.equals(dateAdd, that.dateAdd) &&
                Objects.equals(priceTe, that.priceTe) &&
                Objects.equals(lastWa, that.lastWa) &&
                Objects.equals(currentWa, that.currentWa) &&
                Objects.equals(referer, that.referer);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idStockMvt, idStock, idOrder, idSupplyOrder, idStockMvtReason, idEmployee, employeeLastname, employeeFirstname, physicalQuantity, dateAdd, sign, priceTe, lastWa, currentWa, referer);
    }
}
