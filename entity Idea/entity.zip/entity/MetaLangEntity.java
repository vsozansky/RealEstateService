package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "meta_lang", schema = "ps1761", catalog = "")
@IdClass(MetaLangEntityPK.class)
public class MetaLangEntity {
    private int idMeta;
    private int idShop;
    private int idLang;
    private String title;
    private String description;
    private String keywords;
    private String urlRewrite;

    @Id
    @Column(name = "id_meta", nullable = false)
    public int getIdMeta() {
        return idMeta;
    }

    public void setIdMeta(int idMeta) {
        this.idMeta = idMeta;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "title", nullable = true, length = 128)
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Basic
    @Column(name = "description", nullable = true, length = 255)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Basic
    @Column(name = "keywords", nullable = true, length = 255)
    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    @Basic
    @Column(name = "url_rewrite", nullable = false, length = 254)
    public String getUrlRewrite() {
        return urlRewrite;
    }

    public void setUrlRewrite(String urlRewrite) {
        this.urlRewrite = urlRewrite;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MetaLangEntity that = (MetaLangEntity) o;
        return idMeta == that.idMeta &&
                idShop == that.idShop &&
                idLang == that.idLang &&
                Objects.equals(title, that.title) &&
                Objects.equals(description, that.description) &&
                Objects.equals(keywords, that.keywords) &&
                Objects.equals(urlRewrite, that.urlRewrite);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idMeta, idShop, idLang, title, description, keywords, urlRewrite);
    }
}
