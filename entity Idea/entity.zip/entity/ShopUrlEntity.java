package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "shop_url", schema = "ps1761", catalog = "")
public class ShopUrlEntity {
    private int idShopUrl;
    private int idShop;
    private String domain;
    private String domainSsl;
    private String physicalUri;
    private String virtualUri;
    private byte main;
    private byte active;

    @Id
    @Column(name = "id_shop_url", nullable = false)
    public int getIdShopUrl() {
        return idShopUrl;
    }

    public void setIdShopUrl(int idShopUrl) {
        this.idShopUrl = idShopUrl;
    }

    @Basic
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "domain", nullable = false, length = 150)
    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    @Basic
    @Column(name = "domain_ssl", nullable = false, length = 150)
    public String getDomainSsl() {
        return domainSsl;
    }

    public void setDomainSsl(String domainSsl) {
        this.domainSsl = domainSsl;
    }

    @Basic
    @Column(name = "physical_uri", nullable = false, length = 64)
    public String getPhysicalUri() {
        return physicalUri;
    }

    public void setPhysicalUri(String physicalUri) {
        this.physicalUri = physicalUri;
    }

    @Basic
    @Column(name = "virtual_uri", nullable = false, length = 64)
    public String getVirtualUri() {
        return virtualUri;
    }

    public void setVirtualUri(String virtualUri) {
        this.virtualUri = virtualUri;
    }

    @Basic
    @Column(name = "main", nullable = false)
    public byte getMain() {
        return main;
    }

    public void setMain(byte main) {
        this.main = main;
    }

    @Basic
    @Column(name = "active", nullable = false)
    public byte getActive() {
        return active;
    }

    public void setActive(byte active) {
        this.active = active;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ShopUrlEntity that = (ShopUrlEntity) o;
        return idShopUrl == that.idShopUrl &&
                idShop == that.idShop &&
                main == that.main &&
                active == that.active &&
                Objects.equals(domain, that.domain) &&
                Objects.equals(domainSsl, that.domainSsl) &&
                Objects.equals(physicalUri, that.physicalUri) &&
                Objects.equals(virtualUri, that.virtualUri);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idShopUrl, idShop, domain, domainSsl, physicalUri, virtualUri, main, active);
    }
}
