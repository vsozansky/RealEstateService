package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name = "attribute_impact", schema = "ps1761", catalog = "")
public class AttributeImpactEntity {
    private int idAttributeImpact;
    private int idProduct;
    private int idAttribute;
    private BigDecimal weight;
    private BigDecimal price;

    @Id
    @Column(name = "id_attribute_impact", nullable = false)
    public int getIdAttributeImpact() {
        return idAttributeImpact;
    }

    public void setIdAttributeImpact(int idAttributeImpact) {
        this.idAttributeImpact = idAttributeImpact;
    }

    @Basic
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Basic
    @Column(name = "id_attribute", nullable = false)
    public int getIdAttribute() {
        return idAttribute;
    }

    public void setIdAttribute(int idAttribute) {
        this.idAttribute = idAttribute;
    }

    @Basic
    @Column(name = "weight", nullable = false, precision = 6)
    public BigDecimal getWeight() {
        return weight;
    }

    public void setWeight(BigDecimal weight) {
        this.weight = weight;
    }

    @Basic
    @Column(name = "price", nullable = false, precision = 2)
    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AttributeImpactEntity that = (AttributeImpactEntity) o;
        return idAttributeImpact == that.idAttributeImpact &&
                idProduct == that.idProduct &&
                idAttribute == that.idAttribute &&
                Objects.equals(weight, that.weight) &&
                Objects.equals(price, that.price);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAttributeImpact, idProduct, idAttribute, weight, price);
    }
}
