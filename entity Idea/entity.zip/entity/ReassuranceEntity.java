package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "reassurance", schema = "ps1761", catalog = "")
public class ReassuranceEntity {
    private int idReassurance;
    private int idShop;
    private String fileName;

    @Id
    @Column(name = "id_reassurance", nullable = false)
    public int getIdReassurance() {
        return idReassurance;
    }

    public void setIdReassurance(int idReassurance) {
        this.idReassurance = idReassurance;
    }

    @Basic
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "file_name", nullable = false, length = 100)
    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ReassuranceEntity that = (ReassuranceEntity) o;
        return idReassurance == that.idReassurance &&
                idShop == that.idShop &&
                Objects.equals(fileName, that.fileName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idReassurance, idShop, fileName);
    }
}
