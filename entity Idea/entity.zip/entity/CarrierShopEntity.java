package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "carrier_shop", schema = "ps1761", catalog = "")
@IdClass(CarrierShopEntityPK.class)
public class CarrierShopEntity {
    private int idCarrier;
    private int idShop;

    @Id
    @Column(name = "id_carrier", nullable = false)
    public int getIdCarrier() {
        return idCarrier;
    }

    public void setIdCarrier(int idCarrier) {
        this.idCarrier = idCarrier;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CarrierShopEntity that = (CarrierShopEntity) o;
        return idCarrier == that.idCarrier &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCarrier, idShop);
    }
}
