package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class CmsRoleLangEntityPK implements Serializable {
    private int idCmsRole;
    private int idLang;
    private int idShop;

    @Column(name = "id_cms_role", nullable = false)
    @Id
    public int getIdCmsRole() {
        return idCmsRole;
    }

    public void setIdCmsRole(int idCmsRole) {
        this.idCmsRole = idCmsRole;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Column(name = "id_shop", nullable = false)
    @Id
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CmsRoleLangEntityPK that = (CmsRoleLangEntityPK) o;
        return idCmsRole == that.idCmsRole &&
                idLang == that.idLang &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCmsRole, idLang, idShop);
    }
}
