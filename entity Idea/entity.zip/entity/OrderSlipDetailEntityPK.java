package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class OrderSlipDetailEntityPK implements Serializable {
    private int idOrderSlip;
    private int idOrderDetail;

    @Column(name = "id_order_slip", nullable = false)
    @Id
    public int getIdOrderSlip() {
        return idOrderSlip;
    }

    public void setIdOrderSlip(int idOrderSlip) {
        this.idOrderSlip = idOrderSlip;
    }

    @Column(name = "id_order_detail", nullable = false)
    @Id
    public int getIdOrderDetail() {
        return idOrderDetail;
    }

    public void setIdOrderDetail(int idOrderDetail) {
        this.idOrderDetail = idOrderDetail;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderSlipDetailEntityPK that = (OrderSlipDetailEntityPK) o;
        return idOrderSlip == that.idOrderSlip &&
                idOrderDetail == that.idOrderDetail;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrderSlip, idOrderDetail);
    }
}
