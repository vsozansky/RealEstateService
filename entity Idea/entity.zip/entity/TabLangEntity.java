package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "tab_lang", schema = "ps1761", catalog = "")
@IdClass(TabLangEntityPK.class)
public class TabLangEntity {
    private int idTab;
    private int idLang;
    private String name;

    @Id
    @Column(name = "id_tab", nullable = false)
    public int getIdTab() {
        return idTab;
    }

    public void setIdTab(int idTab) {
        this.idTab = idTab;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 128)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TabLangEntity that = (TabLangEntity) o;
        return idTab == that.idTab &&
                idLang == that.idLang &&
                Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idTab, idLang, name);
    }
}
