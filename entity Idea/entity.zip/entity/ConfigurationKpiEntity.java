package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "configuration_kpi", schema = "ps1761", catalog = "")
public class ConfigurationKpiEntity {
    private int idConfigurationKpi;
    private Integer idShopGroup;
    private Integer idShop;
    private String name;
    private String value;
    private Timestamp dateAdd;
    private Timestamp dateUpd;

    @Id
    @Column(name = "id_configuration_kpi", nullable = false)
    public int getIdConfigurationKpi() {
        return idConfigurationKpi;
    }

    public void setIdConfigurationKpi(int idConfigurationKpi) {
        this.idConfigurationKpi = idConfigurationKpi;
    }

    @Basic
    @Column(name = "id_shop_group", nullable = true)
    public Integer getIdShopGroup() {
        return idShopGroup;
    }

    public void setIdShopGroup(Integer idShopGroup) {
        this.idShopGroup = idShopGroup;
    }

    @Basic
    @Column(name = "id_shop", nullable = true)
    public Integer getIdShop() {
        return idShop;
    }

    public void setIdShop(Integer idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 64)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "value", nullable = true, length = -1)
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Basic
    @Column(name = "date_upd", nullable = false)
    public Timestamp getDateUpd() {
        return dateUpd;
    }

    public void setDateUpd(Timestamp dateUpd) {
        this.dateUpd = dateUpd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ConfigurationKpiEntity that = (ConfigurationKpiEntity) o;
        return idConfigurationKpi == that.idConfigurationKpi &&
                Objects.equals(idShopGroup, that.idShopGroup) &&
                Objects.equals(idShop, that.idShop) &&
                Objects.equals(name, that.name) &&
                Objects.equals(value, that.value) &&
                Objects.equals(dateAdd, that.dateAdd) &&
                Objects.equals(dateUpd, that.dateUpd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idConfigurationKpi, idShopGroup, idShop, name, value, dateAdd, dateUpd);
    }
}
