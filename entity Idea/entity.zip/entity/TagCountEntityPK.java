package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class TagCountEntityPK implements Serializable {
    private int idGroup;
    private int idTag;

    @Column(name = "id_group", nullable = false)
    @Id
    public int getIdGroup() {
        return idGroup;
    }

    public void setIdGroup(int idGroup) {
        this.idGroup = idGroup;
    }

    @Column(name = "id_tag", nullable = false)
    @Id
    public int getIdTag() {
        return idTag;
    }

    public void setIdTag(int idTag) {
        this.idTag = idTag;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TagCountEntityPK that = (TagCountEntityPK) o;
        return idGroup == that.idGroup &&
                idTag == that.idTag;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idGroup, idTag);
    }
}
