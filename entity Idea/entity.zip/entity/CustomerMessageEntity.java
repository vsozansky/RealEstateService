package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "customer_message", schema = "ps1761", catalog = "")
public class CustomerMessageEntity {
    private int idCustomerMessage;
    private Integer idCustomerThread;
    private Integer idEmployee;
    private String message;
    private String fileName;
    private String ipAddress;
    private String userAgent;
    private Timestamp dateAdd;
    private Timestamp dateUpd;
    private byte isPrivate;
    private byte read;

    @Id
    @Column(name = "id_customer_message", nullable = false)
    public int getIdCustomerMessage() {
        return idCustomerMessage;
    }

    public void setIdCustomerMessage(int idCustomerMessage) {
        this.idCustomerMessage = idCustomerMessage;
    }

    @Basic
    @Column(name = "id_customer_thread", nullable = true)
    public Integer getIdCustomerThread() {
        return idCustomerThread;
    }

    public void setIdCustomerThread(Integer idCustomerThread) {
        this.idCustomerThread = idCustomerThread;
    }

    @Basic
    @Column(name = "id_employee", nullable = true)
    public Integer getIdEmployee() {
        return idEmployee;
    }

    public void setIdEmployee(Integer idEmployee) {
        this.idEmployee = idEmployee;
    }

    @Basic
    @Column(name = "message", nullable = false, length = -1)
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Basic
    @Column(name = "file_name", nullable = true, length = 18)
    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    @Basic
    @Column(name = "ip_address", nullable = true, length = 16)
    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    @Basic
    @Column(name = "user_agent", nullable = true, length = 128)
    public String getUserAgent() {
        return userAgent;
    }

    public void setUserAgent(String userAgent) {
        this.userAgent = userAgent;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Basic
    @Column(name = "date_upd", nullable = false)
    public Timestamp getDateUpd() {
        return dateUpd;
    }

    public void setDateUpd(Timestamp dateUpd) {
        this.dateUpd = dateUpd;
    }

    @Basic
    @Column(name = "private", nullable = false)
    public byte getIsPrivate() {
        return isPrivate;
    }

    public void setIsPrivate(byte isPrivate) {
        this.isPrivate = isPrivate;
    }

    @Basic
    @Column(name = "read", nullable = false)
    public byte getRead() {
        return read;
    }

    public void setRead(byte read) {
        this.read = read;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CustomerMessageEntity that = (CustomerMessageEntity) o;
        return idCustomerMessage == that.idCustomerMessage &&
                isPrivate == that.isPrivate &&
                read == that.read &&
                Objects.equals(idCustomerThread, that.idCustomerThread) &&
                Objects.equals(idEmployee, that.idEmployee) &&
                Objects.equals(message, that.message) &&
                Objects.equals(fileName, that.fileName) &&
                Objects.equals(ipAddress, that.ipAddress) &&
                Objects.equals(userAgent, that.userAgent) &&
                Objects.equals(dateAdd, that.dateAdd) &&
                Objects.equals(dateUpd, that.dateUpd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCustomerMessage, idCustomerThread, idEmployee, message, fileName, ipAddress, userAgent, dateAdd, dateUpd, isPrivate, read);
    }
}
