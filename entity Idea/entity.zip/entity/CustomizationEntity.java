package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "customization", schema = "ps1761", catalog = "")
@IdClass(CustomizationEntityPK.class)
public class CustomizationEntity {
    private int idCustomization;
    private int idProductAttribute;
    private int idAddressDelivery;
    private int idCart;
    private int idProduct;
    private int quantity;
    private int quantityRefunded;
    private int quantityReturned;
    private byte inCart;

    @Id
    @Column(name = "id_customization", nullable = false)
    public int getIdCustomization() {
        return idCustomization;
    }

    public void setIdCustomization(int idCustomization) {
        this.idCustomization = idCustomization;
    }

    @Basic
    @Column(name = "id_product_attribute", nullable = false)
    public int getIdProductAttribute() {
        return idProductAttribute;
    }

    public void setIdProductAttribute(int idProductAttribute) {
        this.idProductAttribute = idProductAttribute;
    }

    @Id
    @Column(name = "id_address_delivery", nullable = false)
    public int getIdAddressDelivery() {
        return idAddressDelivery;
    }

    public void setIdAddressDelivery(int idAddressDelivery) {
        this.idAddressDelivery = idAddressDelivery;
    }

    @Id
    @Column(name = "id_cart", nullable = false)
    public int getIdCart() {
        return idCart;
    }

    public void setIdCart(int idCart) {
        this.idCart = idCart;
    }

    @Id
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Basic
    @Column(name = "quantity", nullable = false)
    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Basic
    @Column(name = "quantity_refunded", nullable = false)
    public int getQuantityRefunded() {
        return quantityRefunded;
    }

    public void setQuantityRefunded(int quantityRefunded) {
        this.quantityRefunded = quantityRefunded;
    }

    @Basic
    @Column(name = "quantity_returned", nullable = false)
    public int getQuantityReturned() {
        return quantityReturned;
    }

    public void setQuantityReturned(int quantityReturned) {
        this.quantityReturned = quantityReturned;
    }

    @Basic
    @Column(name = "in_cart", nullable = false)
    public byte getInCart() {
        return inCart;
    }

    public void setInCart(byte inCart) {
        this.inCart = inCart;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CustomizationEntity that = (CustomizationEntity) o;
        return idCustomization == that.idCustomization &&
                idProductAttribute == that.idProductAttribute &&
                idAddressDelivery == that.idAddressDelivery &&
                idCart == that.idCart &&
                idProduct == that.idProduct &&
                quantity == that.quantity &&
                quantityRefunded == that.quantityRefunded &&
                quantityReturned == that.quantityReturned &&
                inCart == that.inCart;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCustomization, idProductAttribute, idAddressDelivery, idCart, idProduct, quantity, quantityRefunded, quantityReturned, inCart);
    }
}
