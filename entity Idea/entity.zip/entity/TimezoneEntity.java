package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "timezone", schema = "ps1761", catalog = "")
public class TimezoneEntity {
    private int idTimezone;
    private String name;

    @Id
    @Column(name = "id_timezone", nullable = false)
    public int getIdTimezone() {
        return idTimezone;
    }

    public void setIdTimezone(int idTimezone) {
        this.idTimezone = idTimezone;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 32)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TimezoneEntity that = (TimezoneEntity) o;
        return idTimezone == that.idTimezone &&
                Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idTimezone, name);
    }
}
