package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "search_index", schema = "ps1761", catalog = "")
@IdClass(SearchIndexEntityPK.class)
public class SearchIndexEntity {
    private int idProduct;
    private int idWord;
    private short weight;

    @Id
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Id
    @Column(name = "id_word", nullable = false)
    public int getIdWord() {
        return idWord;
    }

    public void setIdWord(int idWord) {
        this.idWord = idWord;
    }

    @Basic
    @Column(name = "weight", nullable = false)
    public short getWeight() {
        return weight;
    }

    public void setWeight(short weight) {
        this.weight = weight;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SearchIndexEntity that = (SearchIndexEntity) o;
        return idProduct == that.idProduct &&
                idWord == that.idWord &&
                weight == that.weight;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProduct, idWord, weight);
    }
}
