package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "connections_source", schema = "ps1761", catalog = "")
public class ConnectionsSourceEntity {
    private int idConnectionsSource;
    private int idConnections;
    private String httpReferer;
    private String requestUri;
    private String keywords;
    private Timestamp dateAdd;

    @Id
    @Column(name = "id_connections_source", nullable = false)
    public int getIdConnectionsSource() {
        return idConnectionsSource;
    }

    public void setIdConnectionsSource(int idConnectionsSource) {
        this.idConnectionsSource = idConnectionsSource;
    }

    @Basic
    @Column(name = "id_connections", nullable = false)
    public int getIdConnections() {
        return idConnections;
    }

    public void setIdConnections(int idConnections) {
        this.idConnections = idConnections;
    }

    @Basic
    @Column(name = "http_referer", nullable = true, length = 255)
    public String getHttpReferer() {
        return httpReferer;
    }

    public void setHttpReferer(String httpReferer) {
        this.httpReferer = httpReferer;
    }

    @Basic
    @Column(name = "request_uri", nullable = true, length = 255)
    public String getRequestUri() {
        return requestUri;
    }

    public void setRequestUri(String requestUri) {
        this.requestUri = requestUri;
    }

    @Basic
    @Column(name = "keywords", nullable = true, length = 255)
    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ConnectionsSourceEntity that = (ConnectionsSourceEntity) o;
        return idConnectionsSource == that.idConnectionsSource &&
                idConnections == that.idConnections &&
                Objects.equals(httpReferer, that.httpReferer) &&
                Objects.equals(requestUri, that.requestUri) &&
                Objects.equals(keywords, that.keywords) &&
                Objects.equals(dateAdd, that.dateAdd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idConnectionsSource, idConnections, httpReferer, requestUri, keywords, dateAdd);
    }
}
