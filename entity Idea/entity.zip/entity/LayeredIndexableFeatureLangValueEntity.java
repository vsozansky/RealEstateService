package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "layered_indexable_feature_lang_value", schema = "ps1761", catalog = "")
@IdClass(LayeredIndexableFeatureLangValueEntityPK.class)
public class LayeredIndexableFeatureLangValueEntity {
    private int idFeature;
    private int idLang;
    private String urlName;
    private String metaTitle;

    @Id
    @Column(name = "id_feature", nullable = false)
    public int getIdFeature() {
        return idFeature;
    }

    public void setIdFeature(int idFeature) {
        this.idFeature = idFeature;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "url_name", nullable = false, length = 128)
    public String getUrlName() {
        return urlName;
    }

    public void setUrlName(String urlName) {
        this.urlName = urlName;
    }

    @Basic
    @Column(name = "meta_title", nullable = true, length = 128)
    public String getMetaTitle() {
        return metaTitle;
    }

    public void setMetaTitle(String metaTitle) {
        this.metaTitle = metaTitle;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LayeredIndexableFeatureLangValueEntity that = (LayeredIndexableFeatureLangValueEntity) o;
        return idFeature == that.idFeature &&
                idLang == that.idLang &&
                Objects.equals(urlName, that.urlName) &&
                Objects.equals(metaTitle, that.metaTitle);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idFeature, idLang, urlName, metaTitle);
    }
}
