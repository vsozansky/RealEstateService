package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class ProductTagEntityPK implements Serializable {
    private int idProduct;
    private int idTag;

    @Column(name = "id_product", nullable = false)
    @Id
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Column(name = "id_tag", nullable = false)
    @Id
    public int getIdTag() {
        return idTag;
    }

    public void setIdTag(int idTag) {
        this.idTag = idTag;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductTagEntityPK that = (ProductTagEntityPK) o;
        return idProduct == that.idProduct &&
                idTag == that.idTag;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProduct, idTag);
    }
}
