package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class QuickAccessLangEntityPK implements Serializable {
    private int idQuickAccess;
    private int idLang;

    @Column(name = "id_quick_access", nullable = false)
    @Id
    public int getIdQuickAccess() {
        return idQuickAccess;
    }

    public void setIdQuickAccess(int idQuickAccess) {
        this.idQuickAccess = idQuickAccess;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        QuickAccessLangEntityPK that = (QuickAccessLangEntityPK) o;
        return idQuickAccess == that.idQuickAccess &&
                idLang == that.idLang;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idQuickAccess, idLang);
    }
}
