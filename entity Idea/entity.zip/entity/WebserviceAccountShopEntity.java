package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "webservice_account_shop", schema = "ps1761", catalog = "")
@IdClass(WebserviceAccountShopEntityPK.class)
public class WebserviceAccountShopEntity {
    private int idWebserviceAccount;
    private int idShop;

    @Id
    @Column(name = "id_webservice_account", nullable = false)
    public int getIdWebserviceAccount() {
        return idWebserviceAccount;
    }

    public void setIdWebserviceAccount(int idWebserviceAccount) {
        this.idWebserviceAccount = idWebserviceAccount;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WebserviceAccountShopEntity that = (WebserviceAccountShopEntity) o;
        return idWebserviceAccount == that.idWebserviceAccount &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idWebserviceAccount, idShop);
    }
}
