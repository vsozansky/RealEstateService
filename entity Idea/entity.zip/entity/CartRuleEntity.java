package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "cart_rule", schema = "ps1761", catalog = "")
public class CartRuleEntity {
    private int idCartRule;
    private int idCustomer;
    private Timestamp dateFrom;
    private Timestamp dateTo;
    private String description;
    private int quantity;
    private int quantityPerUser;
    private int priority;
    private byte partialUse;
    private String code;
    private BigDecimal minimumAmount;
    private byte minimumAmountTax;
    private int minimumAmountCurrency;
    private byte minimumAmountShipping;
    private byte countryRestriction;
    private byte carrierRestriction;
    private byte groupRestriction;
    private byte cartRuleRestriction;
    private byte productRestriction;
    private byte shopRestriction;
    private byte freeShipping;
    private BigDecimal reductionPercent;
    private BigDecimal reductionAmount;
    private byte reductionTax;
    private int reductionCurrency;
    private int reductionProduct;
    private byte reductionExcludeSpecial;
    private int giftProduct;
    private int giftProductAttribute;
    private byte highlight;
    private byte active;
    private Timestamp dateAdd;
    private Timestamp dateUpd;

    @Id
    @Column(name = "id_cart_rule", nullable = false)
    public int getIdCartRule() {
        return idCartRule;
    }

    public void setIdCartRule(int idCartRule) {
        this.idCartRule = idCartRule;
    }

    @Basic
    @Column(name = "id_customer", nullable = false)
    public int getIdCustomer() {
        return idCustomer;
    }

    public void setIdCustomer(int idCustomer) {
        this.idCustomer = idCustomer;
    }

    @Basic
    @Column(name = "date_from", nullable = false)
    public Timestamp getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(Timestamp dateFrom) {
        this.dateFrom = dateFrom;
    }

    @Basic
    @Column(name = "date_to", nullable = false)
    public Timestamp getDateTo() {
        return dateTo;
    }

    public void setDateTo(Timestamp dateTo) {
        this.dateTo = dateTo;
    }

    @Basic
    @Column(name = "description", nullable = true, length = -1)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Basic
    @Column(name = "quantity", nullable = false)
    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Basic
    @Column(name = "quantity_per_user", nullable = false)
    public int getQuantityPerUser() {
        return quantityPerUser;
    }

    public void setQuantityPerUser(int quantityPerUser) {
        this.quantityPerUser = quantityPerUser;
    }

    @Basic
    @Column(name = "priority", nullable = false)
    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    @Basic
    @Column(name = "partial_use", nullable = false)
    public byte getPartialUse() {
        return partialUse;
    }

    public void setPartialUse(byte partialUse) {
        this.partialUse = partialUse;
    }

    @Basic
    @Column(name = "code", nullable = false, length = 254)
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Basic
    @Column(name = "minimum_amount", nullable = false, precision = 2)
    public BigDecimal getMinimumAmount() {
        return minimumAmount;
    }

    public void setMinimumAmount(BigDecimal minimumAmount) {
        this.minimumAmount = minimumAmount;
    }

    @Basic
    @Column(name = "minimum_amount_tax", nullable = false)
    public byte getMinimumAmountTax() {
        return minimumAmountTax;
    }

    public void setMinimumAmountTax(byte minimumAmountTax) {
        this.minimumAmountTax = minimumAmountTax;
    }

    @Basic
    @Column(name = "minimum_amount_currency", nullable = false)
    public int getMinimumAmountCurrency() {
        return minimumAmountCurrency;
    }

    public void setMinimumAmountCurrency(int minimumAmountCurrency) {
        this.minimumAmountCurrency = minimumAmountCurrency;
    }

    @Basic
    @Column(name = "minimum_amount_shipping", nullable = false)
    public byte getMinimumAmountShipping() {
        return minimumAmountShipping;
    }

    public void setMinimumAmountShipping(byte minimumAmountShipping) {
        this.minimumAmountShipping = minimumAmountShipping;
    }

    @Basic
    @Column(name = "country_restriction", nullable = false)
    public byte getCountryRestriction() {
        return countryRestriction;
    }

    public void setCountryRestriction(byte countryRestriction) {
        this.countryRestriction = countryRestriction;
    }

    @Basic
    @Column(name = "carrier_restriction", nullable = false)
    public byte getCarrierRestriction() {
        return carrierRestriction;
    }

    public void setCarrierRestriction(byte carrierRestriction) {
        this.carrierRestriction = carrierRestriction;
    }

    @Basic
    @Column(name = "group_restriction", nullable = false)
    public byte getGroupRestriction() {
        return groupRestriction;
    }

    public void setGroupRestriction(byte groupRestriction) {
        this.groupRestriction = groupRestriction;
    }

    @Basic
    @Column(name = "cart_rule_restriction", nullable = false)
    public byte getCartRuleRestriction() {
        return cartRuleRestriction;
    }

    public void setCartRuleRestriction(byte cartRuleRestriction) {
        this.cartRuleRestriction = cartRuleRestriction;
    }

    @Basic
    @Column(name = "product_restriction", nullable = false)
    public byte getProductRestriction() {
        return productRestriction;
    }

    public void setProductRestriction(byte productRestriction) {
        this.productRestriction = productRestriction;
    }

    @Basic
    @Column(name = "shop_restriction", nullable = false)
    public byte getShopRestriction() {
        return shopRestriction;
    }

    public void setShopRestriction(byte shopRestriction) {
        this.shopRestriction = shopRestriction;
    }

    @Basic
    @Column(name = "free_shipping", nullable = false)
    public byte getFreeShipping() {
        return freeShipping;
    }

    public void setFreeShipping(byte freeShipping) {
        this.freeShipping = freeShipping;
    }

    @Basic
    @Column(name = "reduction_percent", nullable = false, precision = 2)
    public BigDecimal getReductionPercent() {
        return reductionPercent;
    }

    public void setReductionPercent(BigDecimal reductionPercent) {
        this.reductionPercent = reductionPercent;
    }

    @Basic
    @Column(name = "reduction_amount", nullable = false, precision = 2)
    public BigDecimal getReductionAmount() {
        return reductionAmount;
    }

    public void setReductionAmount(BigDecimal reductionAmount) {
        this.reductionAmount = reductionAmount;
    }

    @Basic
    @Column(name = "reduction_tax", nullable = false)
    public byte getReductionTax() {
        return reductionTax;
    }

    public void setReductionTax(byte reductionTax) {
        this.reductionTax = reductionTax;
    }

    @Basic
    @Column(name = "reduction_currency", nullable = false)
    public int getReductionCurrency() {
        return reductionCurrency;
    }

    public void setReductionCurrency(int reductionCurrency) {
        this.reductionCurrency = reductionCurrency;
    }

    @Basic
    @Column(name = "reduction_product", nullable = false)
    public int getReductionProduct() {
        return reductionProduct;
    }

    public void setReductionProduct(int reductionProduct) {
        this.reductionProduct = reductionProduct;
    }

    @Basic
    @Column(name = "reduction_exclude_special", nullable = false)
    public byte getReductionExcludeSpecial() {
        return reductionExcludeSpecial;
    }

    public void setReductionExcludeSpecial(byte reductionExcludeSpecial) {
        this.reductionExcludeSpecial = reductionExcludeSpecial;
    }

    @Basic
    @Column(name = "gift_product", nullable = false)
    public int getGiftProduct() {
        return giftProduct;
    }

    public void setGiftProduct(int giftProduct) {
        this.giftProduct = giftProduct;
    }

    @Basic
    @Column(name = "gift_product_attribute", nullable = false)
    public int getGiftProductAttribute() {
        return giftProductAttribute;
    }

    public void setGiftProductAttribute(int giftProductAttribute) {
        this.giftProductAttribute = giftProductAttribute;
    }

    @Basic
    @Column(name = "highlight", nullable = false)
    public byte getHighlight() {
        return highlight;
    }

    public void setHighlight(byte highlight) {
        this.highlight = highlight;
    }

    @Basic
    @Column(name = "active", nullable = false)
    public byte getActive() {
        return active;
    }

    public void setActive(byte active) {
        this.active = active;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Basic
    @Column(name = "date_upd", nullable = false)
    public Timestamp getDateUpd() {
        return dateUpd;
    }

    public void setDateUpd(Timestamp dateUpd) {
        this.dateUpd = dateUpd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CartRuleEntity that = (CartRuleEntity) o;
        return idCartRule == that.idCartRule &&
                idCustomer == that.idCustomer &&
                quantity == that.quantity &&
                quantityPerUser == that.quantityPerUser &&
                priority == that.priority &&
                partialUse == that.partialUse &&
                minimumAmountTax == that.minimumAmountTax &&
                minimumAmountCurrency == that.minimumAmountCurrency &&
                minimumAmountShipping == that.minimumAmountShipping &&
                countryRestriction == that.countryRestriction &&
                carrierRestriction == that.carrierRestriction &&
                groupRestriction == that.groupRestriction &&
                cartRuleRestriction == that.cartRuleRestriction &&
                productRestriction == that.productRestriction &&
                shopRestriction == that.shopRestriction &&
                freeShipping == that.freeShipping &&
                reductionTax == that.reductionTax &&
                reductionCurrency == that.reductionCurrency &&
                reductionProduct == that.reductionProduct &&
                reductionExcludeSpecial == that.reductionExcludeSpecial &&
                giftProduct == that.giftProduct &&
                giftProductAttribute == that.giftProductAttribute &&
                highlight == that.highlight &&
                active == that.active &&
                Objects.equals(dateFrom, that.dateFrom) &&
                Objects.equals(dateTo, that.dateTo) &&
                Objects.equals(description, that.description) &&
                Objects.equals(code, that.code) &&
                Objects.equals(minimumAmount, that.minimumAmount) &&
                Objects.equals(reductionPercent, that.reductionPercent) &&
                Objects.equals(reductionAmount, that.reductionAmount) &&
                Objects.equals(dateAdd, that.dateAdd) &&
                Objects.equals(dateUpd, that.dateUpd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCartRule, idCustomer, dateFrom, dateTo, description, quantity, quantityPerUser, priority, partialUse, code, minimumAmount, minimumAmountTax, minimumAmountCurrency, minimumAmountShipping, countryRestriction, carrierRestriction, groupRestriction, cartRuleRestriction, productRestriction, shopRestriction, freeShipping, reductionPercent, reductionAmount, reductionTax, reductionCurrency, reductionProduct, reductionExcludeSpecial, giftProduct, giftProductAttribute, highlight, active, dateAdd, dateUpd);
    }
}
