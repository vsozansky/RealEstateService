package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "tab_module_preference", schema = "ps1761", catalog = "")
public class TabModulePreferenceEntity {
    private int idTabModulePreference;
    private int idEmployee;
    private int idTab;
    private String module;

    @Id
    @Column(name = "id_tab_module_preference", nullable = false)
    public int getIdTabModulePreference() {
        return idTabModulePreference;
    }

    public void setIdTabModulePreference(int idTabModulePreference) {
        this.idTabModulePreference = idTabModulePreference;
    }

    @Basic
    @Column(name = "id_employee", nullable = false)
    public int getIdEmployee() {
        return idEmployee;
    }

    public void setIdEmployee(int idEmployee) {
        this.idEmployee = idEmployee;
    }

    @Basic
    @Column(name = "id_tab", nullable = false)
    public int getIdTab() {
        return idTab;
    }

    public void setIdTab(int idTab) {
        this.idTab = idTab;
    }

    @Basic
    @Column(name = "module", nullable = false, length = 255)
    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TabModulePreferenceEntity that = (TabModulePreferenceEntity) o;
        return idTabModulePreference == that.idTabModulePreference &&
                idEmployee == that.idEmployee &&
                idTab == that.idTab &&
                Objects.equals(module, that.module);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idTabModulePreference, idEmployee, idTab, module);
    }
}
