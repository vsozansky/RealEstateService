package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "cms_lang", schema = "ps1761", catalog = "")
@IdClass(CmsLangEntityPK.class)
public class CmsLangEntity {
    private int idCms;
    private int idLang;
    private int idShop;
    private String metaTitle;
    private String headSeoTitle;
    private String metaDescription;
    private String metaKeywords;
    private String content;
    private String linkRewrite;

    @Id
    @Column(name = "id_cms", nullable = false)
    public int getIdCms() {
        return idCms;
    }

    public void setIdCms(int idCms) {
        this.idCms = idCms;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "meta_title", nullable = false, length = 255)
    public String getMetaTitle() {
        return metaTitle;
    }

    public void setMetaTitle(String metaTitle) {
        this.metaTitle = metaTitle;
    }

    @Basic
    @Column(name = "head_seo_title", nullable = true, length = 255)
    public String getHeadSeoTitle() {
        return headSeoTitle;
    }

    public void setHeadSeoTitle(String headSeoTitle) {
        this.headSeoTitle = headSeoTitle;
    }

    @Basic
    @Column(name = "meta_description", nullable = true, length = 512)
    public String getMetaDescription() {
        return metaDescription;
    }

    public void setMetaDescription(String metaDescription) {
        this.metaDescription = metaDescription;
    }

    @Basic
    @Column(name = "meta_keywords", nullable = true, length = 255)
    public String getMetaKeywords() {
        return metaKeywords;
    }

    public void setMetaKeywords(String metaKeywords) {
        this.metaKeywords = metaKeywords;
    }

    @Basic
    @Column(name = "content", nullable = true, length = -1)
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Basic
    @Column(name = "link_rewrite", nullable = false, length = 128)
    public String getLinkRewrite() {
        return linkRewrite;
    }

    public void setLinkRewrite(String linkRewrite) {
        this.linkRewrite = linkRewrite;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CmsLangEntity that = (CmsLangEntity) o;
        return idCms == that.idCms &&
                idLang == that.idLang &&
                idShop == that.idShop &&
                Objects.equals(metaTitle, that.metaTitle) &&
                Objects.equals(headSeoTitle, that.headSeoTitle) &&
                Objects.equals(metaDescription, that.metaDescription) &&
                Objects.equals(metaKeywords, that.metaKeywords) &&
                Objects.equals(content, that.content) &&
                Objects.equals(linkRewrite, that.linkRewrite);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCms, idLang, idShop, metaTitle, headSeoTitle, metaDescription, metaKeywords, content, linkRewrite);
    }
}
