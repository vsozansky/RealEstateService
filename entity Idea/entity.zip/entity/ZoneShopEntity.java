package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "zone_shop", schema = "ps1761", catalog = "")
@IdClass(ZoneShopEntityPK.class)
public class ZoneShopEntity {
    private int idZone;
    private int idShop;

    @Id
    @Column(name = "id_zone", nullable = false)
    public int getIdZone() {
        return idZone;
    }

    public void setIdZone(int idZone) {
        this.idZone = idZone;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ZoneShopEntity that = (ZoneShopEntity) o;
        return idZone == that.idZone &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idZone, idShop);
    }
}
