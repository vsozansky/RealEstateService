package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name = "group_reduction", schema = "ps1761", catalog = "")
public class GroupReductionEntity {
    private Object idGroupReduction;
    private int idGroup;
    private int idCategory;
    private BigDecimal reduction;

    @Id
    @Column(name = "id_group_reduction", nullable = false)
    public Object getIdGroupReduction() {
        return idGroupReduction;
    }

    public void setIdGroupReduction(Object idGroupReduction) {
        this.idGroupReduction = idGroupReduction;
    }

    @Basic
    @Column(name = "id_group", nullable = false)
    public int getIdGroup() {
        return idGroup;
    }

    public void setIdGroup(int idGroup) {
        this.idGroup = idGroup;
    }

    @Basic
    @Column(name = "id_category", nullable = false)
    public int getIdCategory() {
        return idCategory;
    }

    public void setIdCategory(int idCategory) {
        this.idCategory = idCategory;
    }

    @Basic
    @Column(name = "reduction", nullable = false, precision = 3)
    public BigDecimal getReduction() {
        return reduction;
    }

    public void setReduction(BigDecimal reduction) {
        this.reduction = reduction;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GroupReductionEntity that = (GroupReductionEntity) o;
        return idGroup == that.idGroup &&
                idCategory == that.idCategory &&
                Objects.equals(idGroupReduction, that.idGroupReduction) &&
                Objects.equals(reduction, that.reduction);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idGroupReduction, idGroup, idCategory, reduction);
    }
}
