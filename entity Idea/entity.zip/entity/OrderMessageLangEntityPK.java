package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class OrderMessageLangEntityPK implements Serializable {
    private int idOrderMessage;
    private int idLang;

    @Column(name = "id_order_message", nullable = false)
    @Id
    public int getIdOrderMessage() {
        return idOrderMessage;
    }

    public void setIdOrderMessage(int idOrderMessage) {
        this.idOrderMessage = idOrderMessage;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderMessageLangEntityPK that = (OrderMessageLangEntityPK) o;
        return idOrderMessage == that.idOrderMessage &&
                idLang == that.idLang;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrderMessage, idLang);
    }
}
