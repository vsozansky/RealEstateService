package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "cart_rule_shop", schema = "ps1761", catalog = "")
@IdClass(CartRuleShopEntityPK.class)
public class CartRuleShopEntity {
    private int idCartRule;
    private int idShop;

    @Id
    @Column(name = "id_cart_rule", nullable = false)
    public int getIdCartRule() {
        return idCartRule;
    }

    public void setIdCartRule(int idCartRule) {
        this.idCartRule = idCartRule;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CartRuleShopEntity that = (CartRuleShopEntity) o;
        return idCartRule == that.idCartRule &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCartRule, idShop);
    }
}
