package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "homeslider", schema = "ps1761", catalog = "")
@IdClass(HomesliderEntityPK.class)
public class HomesliderEntity {
    private int idHomesliderSlides;
    private int idShop;

    @Id
    @Column(name = "id_homeslider_slides", nullable = false)
    public int getIdHomesliderSlides() {
        return idHomesliderSlides;
    }

    public void setIdHomesliderSlides(int idHomesliderSlides) {
        this.idHomesliderSlides = idHomesliderSlides;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        HomesliderEntity that = (HomesliderEntity) o;
        return idHomesliderSlides == that.idHomesliderSlides &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idHomesliderSlides, idShop);
    }
}
