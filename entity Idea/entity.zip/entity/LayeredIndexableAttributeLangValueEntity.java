package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "layered_indexable_attribute_lang_value", schema = "ps1761", catalog = "")
@IdClass(LayeredIndexableAttributeLangValueEntityPK.class)
public class LayeredIndexableAttributeLangValueEntity {
    private int idAttribute;
    private int idLang;
    private String urlName;
    private String metaTitle;

    @Id
    @Column(name = "id_attribute", nullable = false)
    public int getIdAttribute() {
        return idAttribute;
    }

    public void setIdAttribute(int idAttribute) {
        this.idAttribute = idAttribute;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "url_name", nullable = true, length = 128)
    public String getUrlName() {
        return urlName;
    }

    public void setUrlName(String urlName) {
        this.urlName = urlName;
    }

    @Basic
    @Column(name = "meta_title", nullable = true, length = 128)
    public String getMetaTitle() {
        return metaTitle;
    }

    public void setMetaTitle(String metaTitle) {
        this.metaTitle = metaTitle;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LayeredIndexableAttributeLangValueEntity that = (LayeredIndexableAttributeLangValueEntity) o;
        return idAttribute == that.idAttribute &&
                idLang == that.idLang &&
                Objects.equals(urlName, that.urlName) &&
                Objects.equals(metaTitle, that.metaTitle);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAttribute, idLang, urlName, metaTitle);
    }
}
