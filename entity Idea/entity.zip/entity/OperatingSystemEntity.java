package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "operating_system", schema = "ps1761", catalog = "")
public class OperatingSystemEntity {
    private int idOperatingSystem;
    private String name;

    @Id
    @Column(name = "id_operating_system", nullable = false)
    public int getIdOperatingSystem() {
        return idOperatingSystem;
    }

    public void setIdOperatingSystem(int idOperatingSystem) {
        this.idOperatingSystem = idOperatingSystem;
    }

    @Basic
    @Column(name = "name", nullable = true, length = 64)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OperatingSystemEntity that = (OperatingSystemEntity) o;
        return idOperatingSystem == that.idOperatingSystem &&
                Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOperatingSystem, name);
    }
}
