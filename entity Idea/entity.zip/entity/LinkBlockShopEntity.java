package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "link_block_shop", schema = "ps1761", catalog = "")
@IdClass(LinkBlockShopEntityPK.class)
public class LinkBlockShopEntity {
    private int idLinkBlock;
    private int idShop;

    @Id
    @Column(name = "id_link_block", nullable = false)
    public int getIdLinkBlock() {
        return idLinkBlock;
    }

    public void setIdLinkBlock(int idLinkBlock) {
        this.idLinkBlock = idLinkBlock;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LinkBlockShopEntity that = (LinkBlockShopEntity) o;
        return idLinkBlock == that.idLinkBlock &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idLinkBlock, idShop);
    }
}
