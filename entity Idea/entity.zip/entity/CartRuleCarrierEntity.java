package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "cart_rule_carrier", schema = "ps1761", catalog = "")
@IdClass(CartRuleCarrierEntityPK.class)
public class CartRuleCarrierEntity {
    private int idCartRule;
    private int idCarrier;

    @Id
    @Column(name = "id_cart_rule", nullable = false)
    public int getIdCartRule() {
        return idCartRule;
    }

    public void setIdCartRule(int idCartRule) {
        this.idCartRule = idCartRule;
    }

    @Id
    @Column(name = "id_carrier", nullable = false)
    public int getIdCarrier() {
        return idCarrier;
    }

    public void setIdCarrier(int idCarrier) {
        this.idCarrier = idCarrier;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CartRuleCarrierEntity that = (CartRuleCarrierEntity) o;
        return idCartRule == that.idCartRule &&
                idCarrier == that.idCarrier;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCartRule, idCarrier);
    }
}
