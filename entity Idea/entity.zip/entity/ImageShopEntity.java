package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "image_shop", schema = "ps1761", catalog = "")
@IdClass(ImageShopEntityPK.class)
public class ImageShopEntity {
    private int idProduct;
    private int idImage;
    private int idShop;
    private Byte cover;

    @Basic
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Id
    @Column(name = "id_image", nullable = false)
    public int getIdImage() {
        return idImage;
    }

    public void setIdImage(int idImage) {
        this.idImage = idImage;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "cover", nullable = true)
    public Byte getCover() {
        return cover;
    }

    public void setCover(Byte cover) {
        this.cover = cover;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ImageShopEntity that = (ImageShopEntity) o;
        return idProduct == that.idProduct &&
                idImage == that.idImage &&
                idShop == that.idShop &&
                Objects.equals(cover, that.cover);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProduct, idImage, idShop, cover);
    }
}
