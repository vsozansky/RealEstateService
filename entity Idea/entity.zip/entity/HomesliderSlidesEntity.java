package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "homeslider_slides", schema = "ps1761", catalog = "")
public class HomesliderSlidesEntity {
    private int idHomesliderSlides;
    private int position;
    private byte active;

    @Id
    @Column(name = "id_homeslider_slides", nullable = false)
    public int getIdHomesliderSlides() {
        return idHomesliderSlides;
    }

    public void setIdHomesliderSlides(int idHomesliderSlides) {
        this.idHomesliderSlides = idHomesliderSlides;
    }

    @Basic
    @Column(name = "position", nullable = false)
    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    @Basic
    @Column(name = "active", nullable = false)
    public byte getActive() {
        return active;
    }

    public void setActive(byte active) {
        this.active = active;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        HomesliderSlidesEntity that = (HomesliderSlidesEntity) o;
        return idHomesliderSlides == that.idHomesliderSlides &&
                position == that.position &&
                active == that.active;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idHomesliderSlides, position, active);
    }
}
