package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "link_block", schema = "ps1761", catalog = "")
public class LinkBlockEntity {
    private int idLinkBlock;
    private Integer idHook;
    private int position;
    private String content;

    @Id
    @Column(name = "id_link_block", nullable = false)
    public int getIdLinkBlock() {
        return idLinkBlock;
    }

    public void setIdLinkBlock(int idLinkBlock) {
        this.idLinkBlock = idLinkBlock;
    }

    @Basic
    @Column(name = "id_hook", nullable = true)
    public Integer getIdHook() {
        return idHook;
    }

    public void setIdHook(Integer idHook) {
        this.idHook = idHook;
    }

    @Basic
    @Column(name = "position", nullable = false)
    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    @Basic
    @Column(name = "content", nullable = true, length = -1)
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LinkBlockEntity that = (LinkBlockEntity) o;
        return idLinkBlock == that.idLinkBlock &&
                position == that.position &&
                Objects.equals(idHook, that.idHook) &&
                Objects.equals(content, that.content);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idLinkBlock, idHook, position, content);
    }
}
