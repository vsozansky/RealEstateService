package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "layered_indexable_attribute_group_lang_value", schema = "ps1761", catalog = "")
@IdClass(LayeredIndexableAttributeGroupLangValueEntityPK.class)
public class LayeredIndexableAttributeGroupLangValueEntity {
    private int idAttributeGroup;
    private int idLang;
    private String urlName;
    private String metaTitle;

    @Id
    @Column(name = "id_attribute_group", nullable = false)
    public int getIdAttributeGroup() {
        return idAttributeGroup;
    }

    public void setIdAttributeGroup(int idAttributeGroup) {
        this.idAttributeGroup = idAttributeGroup;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "url_name", nullable = true, length = 128)
    public String getUrlName() {
        return urlName;
    }

    public void setUrlName(String urlName) {
        this.urlName = urlName;
    }

    @Basic
    @Column(name = "meta_title", nullable = true, length = 128)
    public String getMetaTitle() {
        return metaTitle;
    }

    public void setMetaTitle(String metaTitle) {
        this.metaTitle = metaTitle;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LayeredIndexableAttributeGroupLangValueEntity that = (LayeredIndexableAttributeGroupLangValueEntity) o;
        return idAttributeGroup == that.idAttributeGroup &&
                idLang == that.idLang &&
                Objects.equals(urlName, that.urlName) &&
                Objects.equals(metaTitle, that.metaTitle);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAttributeGroup, idLang, urlName, metaTitle);
    }
}
