package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name = "product_group_reduction_cache", schema = "ps1761", catalog = "")
@IdClass(ProductGroupReductionCacheEntityPK.class)
public class ProductGroupReductionCacheEntity {
    private int idProduct;
    private int idGroup;
    private BigDecimal reduction;

    @Id
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Id
    @Column(name = "id_group", nullable = false)
    public int getIdGroup() {
        return idGroup;
    }

    public void setIdGroup(int idGroup) {
        this.idGroup = idGroup;
    }

    @Basic
    @Column(name = "reduction", nullable = false, precision = 3)
    public BigDecimal getReduction() {
        return reduction;
    }

    public void setReduction(BigDecimal reduction) {
        this.reduction = reduction;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductGroupReductionCacheEntity that = (ProductGroupReductionCacheEntity) o;
        return idProduct == that.idProduct &&
                idGroup == that.idGroup &&
                Objects.equals(reduction, that.reduction);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProduct, idGroup, reduction);
    }
}
