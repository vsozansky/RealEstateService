package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "product")
public class ProductEntity {

    @Id
    @Column(name = "id_product", nullable = false)
    public int idProduct;

    @Basic
    @Column(name = "id_supplier", nullable = true)
    public Integer idSupplier;

    @Basic
    @Column(name = "id_manufacturer", nullable = true)
    public Integer idManufacturer;

    @Basic
    @Column(name = "id_category_default", nullable = true)
    public Integer idCategoryDefault;

    @Basic
    @Column(name = "id_shop_default", nullable = false)
    public int idShopDefault;

    @Basic
    @Column(name = "id_tax_rules_group", nullable = false)
    public int idTaxRulesGroup;

    @Basic
    @Column(name = "on_sale", nullable = false)
    public byte onSale;


    @Basic
    @Column(name = "online_only", nullable = false)
    public byte onlineOnly;

    @Basic
    @Column(name = "ean13", nullable = true, length = 13)
    public String ean13;

    @Basic
    @Column(name = "isbn", nullable = true, length = 32)
    public String isbn;

    @Basic
    @Column(name = "upc", nullable = true, length = 12)
    public String upc;

    @Basic
    @Column(name = "ecotax", nullable = false, precision = 6)
    public BigDecimal ecotax;

    @Basic
    @Column(name = "quantity", nullable = false)
    public int quantity;

    @Basic
    @Column(name = "minimal_quantity", nullable = false)
    public int minimalQuantity;

    @Basic
    @Column(name = "low_stock_threshold", nullable = true)
    public Integer lowStockThreshold;

    @Basic
    @Column(name = "low_stock_alert", nullable = false)
    public byte lowStockAlert;

    @Basic
    @Column(name = "price", nullable = false, precision = 6)
    public BigDecimal price;

    @Basic
    @Column(name = "wholesale_price", nullable = false, precision = 6)
    public BigDecimal wholesalePrice;

    @Basic
    @Column(name = "unity", nullable = true, length = 255)
    public String unity;

    @Basic
    @Column(name = "unit_price_ratio", nullable = false, precision = 6)
    public BigDecimal unitPriceRatio;

    @Basic
    @Column(name = "additional_shipping_cost", nullable = false, precision = 2)
    public BigDecimal additionalShippingCost;

    @Basic
    @Column(name = "reference", nullable = true, length = 64)
    public String reference;

    @Basic
    @Column(name = "supplier_reference", nullable = true, length = 64)
    public String supplierReference;

    @Basic
    @Column(name = "location", nullable = true, length = 64)
    public String location;

    @Basic
    @Column(name = "width", nullable = false, precision = 6)
    public BigDecimal width;

    @Basic
    @Column(name = "height", nullable = false, precision = 6)
    public BigDecimal height;

    @Basic
    @Column(name = "depth", nullable = false, precision = 6)
    public BigDecimal depth;

    @Basic
    @Column(name = "weight", nullable = false, precision = 6)
    public BigDecimal weight;

    @Basic
    @Column(name = "out_of_stock", nullable = false)
    public int outOfStock;

    @Basic
    @Column(name = "additional_delivery_times", nullable = false)
    public byte additionalDeliveryTimes;

    @Basic
    @Column(name = "quantity_discount", nullable = true)
    public Byte quantityDiscount;

    @Basic
    @Column(name = "customizable", nullable = false)
    public byte customizable;

    @Basic
    @Column(name = "uploadable_files", nullable = false)
    public byte uploadableFiles;

    @Basic
    @Column(name = "text_fields", nullable = false)
    public byte textFields;

    @Basic
    @Column(name = "active", nullable = false)
    public byte active;

    @Basic
    @Column(name = "redirect_type", nullable = false)
    public Object redirectType;

    @Basic
    @Column(name = "id_type_redirected", nullable = false)
    public int idTypeRedirected;

    @Basic
    @Column(name = "available_for_order", nullable = false)
    public byte availableForOrder;

    @Basic
    @Column(name = "available_date", nullable = true)
    public Date availableDate;

    @Basic
    @Column(name = "show_condition", nullable = false)
    public byte showCondition;

    @Basic
    @Column(name = "condition", nullable = false)
    public Object condition;

    @Basic
    @Column(name = "show_price", nullable = false)
    public byte showPrice;

    @Basic
    @Column(name = "indexed", nullable = false)
    public byte indexed;

    @Basic
    @Column(name = "visibility", nullable = false)
    public Object visibility;

    @Basic
    @Column(name = "cache_is_pack", nullable = false)
    public byte cacheIsPack;

    @Basic
    @Column(name = "cache_has_attachments", nullable = false)
    public byte cacheHasAttachments;

    @Basic
    @Column(name = "is_virtual", nullable = false)
    public byte isVirtual;

    @Basic
    @Column(name = "cache_default_attribute", nullable = true)
    public Integer cacheDefaultAttribute;

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp dateAdd;

    @Basic
    @Column(name = "date_upd", nullable = false)
    public Timestamp dateUpd;

    @Basic
    @Column(name = "advanced_stock_management", nullable = false)
    public byte advancedStockManagement;

    @Basic
    @Column(name = "pack_stock_type", nullable = false)
    public int packStockType;

    @Basic
    @Column(name = "state", nullable = false)
    public int state;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductEntity that = (ProductEntity) o;
        return idProduct == that.idProduct &&
                idShopDefault == that.idShopDefault &&
                idTaxRulesGroup == that.idTaxRulesGroup &&
                onSale == that.onSale &&
                onlineOnly == that.onlineOnly &&
                quantity == that.quantity &&
                minimalQuantity == that.minimalQuantity &&
                lowStockAlert == that.lowStockAlert &&
                outOfStock == that.outOfStock &&
                additionalDeliveryTimes == that.additionalDeliveryTimes &&
                customizable == that.customizable &&
                uploadableFiles == that.uploadableFiles &&
                textFields == that.textFields &&
                active == that.active &&
                idTypeRedirected == that.idTypeRedirected &&
                availableForOrder == that.availableForOrder &&
                showCondition == that.showCondition &&
                showPrice == that.showPrice &&
                indexed == that.indexed &&
                cacheIsPack == that.cacheIsPack &&
                cacheHasAttachments == that.cacheHasAttachments &&
                isVirtual == that.isVirtual &&
                advancedStockManagement == that.advancedStockManagement &&
                packStockType == that.packStockType &&
                state == that.state &&
                Objects.equals(idSupplier, that.idSupplier) &&
                Objects.equals(idManufacturer, that.idManufacturer) &&
                Objects.equals(idCategoryDefault, that.idCategoryDefault) &&
                Objects.equals(ean13, that.ean13) &&
                Objects.equals(isbn, that.isbn) &&
                Objects.equals(upc, that.upc) &&
                Objects.equals(ecotax, that.ecotax) &&
                Objects.equals(lowStockThreshold, that.lowStockThreshold) &&
                Objects.equals(price, that.price) &&
                Objects.equals(wholesalePrice, that.wholesalePrice) &&
                Objects.equals(unity, that.unity) &&
                Objects.equals(unitPriceRatio, that.unitPriceRatio) &&
                Objects.equals(additionalShippingCost, that.additionalShippingCost) &&
                Objects.equals(reference, that.reference) &&
                Objects.equals(supplierReference, that.supplierReference) &&
                Objects.equals(location, that.location) &&
                Objects.equals(width, that.width) &&
                Objects.equals(height, that.height) &&
                Objects.equals(depth, that.depth) &&
                Objects.equals(weight, that.weight) &&
                Objects.equals(quantityDiscount, that.quantityDiscount) &&
                Objects.equals(redirectType, that.redirectType) &&
                Objects.equals(availableDate, that.availableDate) &&
                Objects.equals(condition, that.condition) &&
                Objects.equals(visibility, that.visibility) &&
                Objects.equals(cacheDefaultAttribute, that.cacheDefaultAttribute) &&
                Objects.equals(dateAdd, that.dateAdd) &&
                Objects.equals(dateUpd, that.dateUpd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProduct, idSupplier, idManufacturer, idCategoryDefault, idShopDefault, idTaxRulesGroup, onSale, onlineOnly, ean13, isbn, upc, ecotax, quantity, minimalQuantity, lowStockThreshold, lowStockAlert, price, wholesalePrice, unity, unitPriceRatio, additionalShippingCost, reference, supplierReference, location, width, height, depth, weight, outOfStock, additionalDeliveryTimes, quantityDiscount, customizable, uploadableFiles, textFields, active, redirectType, idTypeRedirected, availableForOrder, availableDate, showCondition, condition, showPrice, indexed, visibility, cacheIsPack, cacheHasAttachments, isVirtual, cacheDefaultAttribute, dateAdd, dateUpd, advancedStockManagement, packStockType, state);
    }
}
