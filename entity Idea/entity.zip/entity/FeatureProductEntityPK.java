package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class FeatureProductEntityPK implements Serializable {
    private int idFeature;
    private int idProduct;
    private int idFeatureValue;

    @Column(name = "id_feature", nullable = false)
    @Id
    public int getIdFeature() {
        return idFeature;
    }

    public void setIdFeature(int idFeature) {
        this.idFeature = idFeature;
    }

    @Column(name = "id_product", nullable = false)
    @Id
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Column(name = "id_feature_value", nullable = false)
    @Id
    public int getIdFeatureValue() {
        return idFeatureValue;
    }

    public void setIdFeatureValue(int idFeatureValue) {
        this.idFeatureValue = idFeatureValue;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FeatureProductEntityPK that = (FeatureProductEntityPK) o;
        return idFeature == that.idFeature &&
                idProduct == that.idProduct &&
                idFeatureValue == that.idFeatureValue;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idFeature, idProduct, idFeatureValue);
    }
}
