package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "tax_rule", schema = "ps1761", catalog = "")
public class TaxRuleEntity {
    private int idTaxRule;
    private int idTaxRulesGroup;
    private int idCountry;
    private int idState;
    private String zipcodeFrom;
    private String zipcodeTo;
    private int idTax;
    private int behavior;
    private String description;

    @Id
    @Column(name = "id_tax_rule", nullable = false)
    public int getIdTaxRule() {
        return idTaxRule;
    }

    public void setIdTaxRule(int idTaxRule) {
        this.idTaxRule = idTaxRule;
    }

    @Basic
    @Column(name = "id_tax_rules_group", nullable = false)
    public int getIdTaxRulesGroup() {
        return idTaxRulesGroup;
    }

    public void setIdTaxRulesGroup(int idTaxRulesGroup) {
        this.idTaxRulesGroup = idTaxRulesGroup;
    }

    @Basic
    @Column(name = "id_country", nullable = false)
    public int getIdCountry() {
        return idCountry;
    }

    public void setIdCountry(int idCountry) {
        this.idCountry = idCountry;
    }

    @Basic
    @Column(name = "id_state", nullable = false)
    public int getIdState() {
        return idState;
    }

    public void setIdState(int idState) {
        this.idState = idState;
    }

    @Basic
    @Column(name = "zipcode_from", nullable = false, length = 12)
    public String getZipcodeFrom() {
        return zipcodeFrom;
    }

    public void setZipcodeFrom(String zipcodeFrom) {
        this.zipcodeFrom = zipcodeFrom;
    }

    @Basic
    @Column(name = "zipcode_to", nullable = false, length = 12)
    public String getZipcodeTo() {
        return zipcodeTo;
    }

    public void setZipcodeTo(String zipcodeTo) {
        this.zipcodeTo = zipcodeTo;
    }

    @Basic
    @Column(name = "id_tax", nullable = false)
    public int getIdTax() {
        return idTax;
    }

    public void setIdTax(int idTax) {
        this.idTax = idTax;
    }

    @Basic
    @Column(name = "behavior", nullable = false)
    public int getBehavior() {
        return behavior;
    }

    public void setBehavior(int behavior) {
        this.behavior = behavior;
    }

    @Basic
    @Column(name = "description", nullable = false, length = 100)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TaxRuleEntity that = (TaxRuleEntity) o;
        return idTaxRule == that.idTaxRule &&
                idTaxRulesGroup == that.idTaxRulesGroup &&
                idCountry == that.idCountry &&
                idState == that.idState &&
                idTax == that.idTax &&
                behavior == that.behavior &&
                Objects.equals(zipcodeFrom, that.zipcodeFrom) &&
                Objects.equals(zipcodeTo, that.zipcodeTo) &&
                Objects.equals(description, that.description);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idTaxRule, idTaxRulesGroup, idCountry, idState, zipcodeFrom, zipcodeTo, idTax, behavior, description);
    }
}
