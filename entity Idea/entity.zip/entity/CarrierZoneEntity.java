package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "carrier_zone", schema = "ps1761", catalog = "")
@IdClass(CarrierZoneEntityPK.class)
public class CarrierZoneEntity {
    private int idCarrier;
    private int idZone;

    @Id
    @Column(name = "id_carrier", nullable = false)
    public int getIdCarrier() {
        return idCarrier;
    }

    public void setIdCarrier(int idCarrier) {
        this.idCarrier = idCarrier;
    }

    @Id
    @Column(name = "id_zone", nullable = false)
    public int getIdZone() {
        return idZone;
    }

    public void setIdZone(int idZone) {
        this.idZone = idZone;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CarrierZoneEntity that = (CarrierZoneEntity) o;
        return idCarrier == that.idCarrier &&
                idZone == that.idZone;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCarrier, idZone);
    }
}
