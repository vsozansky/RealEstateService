package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name = "stock", schema = "ps1761", catalog = "")
public class StockEntity {
    private int idStock;
    private int idWarehouse;
    private int idProduct;
    private int idProductAttribute;
    private String reference;
    private String ean13;
    private String isbn;
    private String upc;
    private int physicalQuantity;
    private int usableQuantity;
    private BigDecimal priceTe;

    @Id
    @Column(name = "id_stock", nullable = false)
    public int getIdStock() {
        return idStock;
    }

    public void setIdStock(int idStock) {
        this.idStock = idStock;
    }

    @Basic
    @Column(name = "id_warehouse", nullable = false)
    public int getIdWarehouse() {
        return idWarehouse;
    }

    public void setIdWarehouse(int idWarehouse) {
        this.idWarehouse = idWarehouse;
    }

    @Basic
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Basic
    @Column(name = "id_product_attribute", nullable = false)
    public int getIdProductAttribute() {
        return idProductAttribute;
    }

    public void setIdProductAttribute(int idProductAttribute) {
        this.idProductAttribute = idProductAttribute;
    }

    @Basic
    @Column(name = "reference", nullable = false, length = 64)
    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    @Basic
    @Column(name = "ean13", nullable = true, length = 13)
    public String getEan13() {
        return ean13;
    }

    public void setEan13(String ean13) {
        this.ean13 = ean13;
    }

    @Basic
    @Column(name = "isbn", nullable = true, length = 32)
    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    @Basic
    @Column(name = "upc", nullable = true, length = 12)
    public String getUpc() {
        return upc;
    }

    public void setUpc(String upc) {
        this.upc = upc;
    }

    @Basic
    @Column(name = "physical_quantity", nullable = false)
    public int getPhysicalQuantity() {
        return physicalQuantity;
    }

    public void setPhysicalQuantity(int physicalQuantity) {
        this.physicalQuantity = physicalQuantity;
    }

    @Basic
    @Column(name = "usable_quantity", nullable = false)
    public int getUsableQuantity() {
        return usableQuantity;
    }

    public void setUsableQuantity(int usableQuantity) {
        this.usableQuantity = usableQuantity;
    }

    @Basic
    @Column(name = "price_te", nullable = true, precision = 6)
    public BigDecimal getPriceTe() {
        return priceTe;
    }

    public void setPriceTe(BigDecimal priceTe) {
        this.priceTe = priceTe;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StockEntity that = (StockEntity) o;
        return idStock == that.idStock &&
                idWarehouse == that.idWarehouse &&
                idProduct == that.idProduct &&
                idProductAttribute == that.idProductAttribute &&
                physicalQuantity == that.physicalQuantity &&
                usableQuantity == that.usableQuantity &&
                Objects.equals(reference, that.reference) &&
                Objects.equals(ean13, that.ean13) &&
                Objects.equals(isbn, that.isbn) &&
                Objects.equals(upc, that.upc) &&
                Objects.equals(priceTe, that.priceTe);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idStock, idWarehouse, idProduct, idProductAttribute, reference, ean13, isbn, upc, physicalQuantity, usableQuantity, priceTe);
    }
}
