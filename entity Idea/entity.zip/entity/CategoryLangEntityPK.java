package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class CategoryLangEntityPK implements Serializable {
    private int idCategory;
    private int idShop;
    private int idLang;

    @Column(name = "id_category", nullable = false)
    @Id
    public int getIdCategory() {
        return idCategory;
    }

    public void setIdCategory(int idCategory) {
        this.idCategory = idCategory;
    }

    @Column(name = "id_shop", nullable = false)
    @Id
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CategoryLangEntityPK that = (CategoryLangEntityPK) o;
        return idCategory == that.idCategory &&
                idShop == that.idShop &&
                idLang == that.idLang;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCategory, idShop, idLang);
    }
}
