package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class ConditionBadgeEntityPK implements Serializable {
    private int idCondition;
    private int idBadge;

    @Column(name = "id_condition", nullable = false)
    @Id
    public int getIdCondition() {
        return idCondition;
    }

    public void setIdCondition(int idCondition) {
        this.idCondition = idCondition;
    }

    @Column(name = "id_badge", nullable = false)
    @Id
    public int getIdBadge() {
        return idBadge;
    }

    public void setIdBadge(int idBadge) {
        this.idBadge = idBadge;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ConditionBadgeEntityPK that = (ConditionBadgeEntityPK) o;
        return idCondition == that.idCondition &&
                idBadge == that.idBadge;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCondition, idBadge);
    }
}
