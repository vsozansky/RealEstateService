package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "supply_order", schema = "ps1761", catalog = "")
public class SupplyOrderEntity {
    private int idSupplyOrder;
    private int idSupplier;
    private String supplierName;
    private int idLang;
    private int idWarehouse;
    private int idSupplyOrderState;
    private int idCurrency;
    private int idRefCurrency;
    private String reference;
    private Timestamp dateAdd;
    private Timestamp dateUpd;
    private Timestamp dateDeliveryExpected;
    private BigDecimal totalTe;
    private BigDecimal totalWithDiscountTe;
    private BigDecimal totalTax;
    private BigDecimal totalTi;
    private BigDecimal discountRate;
    private BigDecimal discountValueTe;
    private Byte isTemplate;

    @Id
    @Column(name = "id_supply_order", nullable = false)
    public int getIdSupplyOrder() {
        return idSupplyOrder;
    }

    public void setIdSupplyOrder(int idSupplyOrder) {
        this.idSupplyOrder = idSupplyOrder;
    }

    @Basic
    @Column(name = "id_supplier", nullable = false)
    public int getIdSupplier() {
        return idSupplier;
    }

    public void setIdSupplier(int idSupplier) {
        this.idSupplier = idSupplier;
    }

    @Basic
    @Column(name = "supplier_name", nullable = false, length = 64)
    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    @Basic
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "id_warehouse", nullable = false)
    public int getIdWarehouse() {
        return idWarehouse;
    }

    public void setIdWarehouse(int idWarehouse) {
        this.idWarehouse = idWarehouse;
    }

    @Basic
    @Column(name = "id_supply_order_state", nullable = false)
    public int getIdSupplyOrderState() {
        return idSupplyOrderState;
    }

    public void setIdSupplyOrderState(int idSupplyOrderState) {
        this.idSupplyOrderState = idSupplyOrderState;
    }

    @Basic
    @Column(name = "id_currency", nullable = false)
    public int getIdCurrency() {
        return idCurrency;
    }

    public void setIdCurrency(int idCurrency) {
        this.idCurrency = idCurrency;
    }

    @Basic
    @Column(name = "id_ref_currency", nullable = false)
    public int getIdRefCurrency() {
        return idRefCurrency;
    }

    public void setIdRefCurrency(int idRefCurrency) {
        this.idRefCurrency = idRefCurrency;
    }

    @Basic
    @Column(name = "reference", nullable = false, length = 64)
    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Basic
    @Column(name = "date_upd", nullable = false)
    public Timestamp getDateUpd() {
        return dateUpd;
    }

    public void setDateUpd(Timestamp dateUpd) {
        this.dateUpd = dateUpd;
    }

    @Basic
    @Column(name = "date_delivery_expected", nullable = true)
    public Timestamp getDateDeliveryExpected() {
        return dateDeliveryExpected;
    }

    public void setDateDeliveryExpected(Timestamp dateDeliveryExpected) {
        this.dateDeliveryExpected = dateDeliveryExpected;
    }

    @Basic
    @Column(name = "total_te", nullable = true, precision = 6)
    public BigDecimal getTotalTe() {
        return totalTe;
    }

    public void setTotalTe(BigDecimal totalTe) {
        this.totalTe = totalTe;
    }

    @Basic
    @Column(name = "total_with_discount_te", nullable = true, precision = 6)
    public BigDecimal getTotalWithDiscountTe() {
        return totalWithDiscountTe;
    }

    public void setTotalWithDiscountTe(BigDecimal totalWithDiscountTe) {
        this.totalWithDiscountTe = totalWithDiscountTe;
    }

    @Basic
    @Column(name = "total_tax", nullable = true, precision = 6)
    public BigDecimal getTotalTax() {
        return totalTax;
    }

    public void setTotalTax(BigDecimal totalTax) {
        this.totalTax = totalTax;
    }

    @Basic
    @Column(name = "total_ti", nullable = true, precision = 6)
    public BigDecimal getTotalTi() {
        return totalTi;
    }

    public void setTotalTi(BigDecimal totalTi) {
        this.totalTi = totalTi;
    }

    @Basic
    @Column(name = "discount_rate", nullable = true, precision = 6)
    public BigDecimal getDiscountRate() {
        return discountRate;
    }

    public void setDiscountRate(BigDecimal discountRate) {
        this.discountRate = discountRate;
    }

    @Basic
    @Column(name = "discount_value_te", nullable = true, precision = 6)
    public BigDecimal getDiscountValueTe() {
        return discountValueTe;
    }

    public void setDiscountValueTe(BigDecimal discountValueTe) {
        this.discountValueTe = discountValueTe;
    }

    @Basic
    @Column(name = "is_template", nullable = true)
    public Byte getIsTemplate() {
        return isTemplate;
    }

    public void setIsTemplate(Byte isTemplate) {
        this.isTemplate = isTemplate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SupplyOrderEntity that = (SupplyOrderEntity) o;
        return idSupplyOrder == that.idSupplyOrder &&
                idSupplier == that.idSupplier &&
                idLang == that.idLang &&
                idWarehouse == that.idWarehouse &&
                idSupplyOrderState == that.idSupplyOrderState &&
                idCurrency == that.idCurrency &&
                idRefCurrency == that.idRefCurrency &&
                Objects.equals(supplierName, that.supplierName) &&
                Objects.equals(reference, that.reference) &&
                Objects.equals(dateAdd, that.dateAdd) &&
                Objects.equals(dateUpd, that.dateUpd) &&
                Objects.equals(dateDeliveryExpected, that.dateDeliveryExpected) &&
                Objects.equals(totalTe, that.totalTe) &&
                Objects.equals(totalWithDiscountTe, that.totalWithDiscountTe) &&
                Objects.equals(totalTax, that.totalTax) &&
                Objects.equals(totalTi, that.totalTi) &&
                Objects.equals(discountRate, that.discountRate) &&
                Objects.equals(discountValueTe, that.discountValueTe) &&
                Objects.equals(isTemplate, that.isTemplate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idSupplyOrder, idSupplier, supplierName, idLang, idWarehouse, idSupplyOrderState, idCurrency, idRefCurrency, reference, dateAdd, dateUpd, dateDeliveryExpected, totalTe, totalWithDiscountTe, totalTax, totalTi, discountRate, discountValueTe, isTemplate);
    }
}
