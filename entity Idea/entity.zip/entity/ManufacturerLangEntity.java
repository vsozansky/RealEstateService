package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "manufacturer_lang", schema = "ps1761", catalog = "")
@IdClass(ManufacturerLangEntityPK.class)
public class ManufacturerLangEntity {
    private int idManufacturer;
    private int idLang;
    private String description;
    private String shortDescription;
    private String metaTitle;
    private String metaKeywords;
    private String metaDescription;

    @Id
    @Column(name = "id_manufacturer", nullable = false)
    public int getIdManufacturer() {
        return idManufacturer;
    }

    public void setIdManufacturer(int idManufacturer) {
        this.idManufacturer = idManufacturer;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "description", nullable = true, length = -1)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Basic
    @Column(name = "short_description", nullable = true, length = -1)
    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    @Basic
    @Column(name = "meta_title", nullable = true, length = 255)
    public String getMetaTitle() {
        return metaTitle;
    }

    public void setMetaTitle(String metaTitle) {
        this.metaTitle = metaTitle;
    }

    @Basic
    @Column(name = "meta_keywords", nullable = true, length = 255)
    public String getMetaKeywords() {
        return metaKeywords;
    }

    public void setMetaKeywords(String metaKeywords) {
        this.metaKeywords = metaKeywords;
    }

    @Basic
    @Column(name = "meta_description", nullable = true, length = 512)
    public String getMetaDescription() {
        return metaDescription;
    }

    public void setMetaDescription(String metaDescription) {
        this.metaDescription = metaDescription;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ManufacturerLangEntity that = (ManufacturerLangEntity) o;
        return idManufacturer == that.idManufacturer &&
                idLang == that.idLang &&
                Objects.equals(description, that.description) &&
                Objects.equals(shortDescription, that.shortDescription) &&
                Objects.equals(metaTitle, that.metaTitle) &&
                Objects.equals(metaKeywords, that.metaKeywords) &&
                Objects.equals(metaDescription, that.metaDescription);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idManufacturer, idLang, description, shortDescription, metaTitle, metaKeywords, metaDescription);
    }
}
