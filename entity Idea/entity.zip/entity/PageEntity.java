package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "page", schema = "ps1761", catalog = "")
public class PageEntity {
    private int idPage;
    private int idPageType;
    private Integer idObject;

    @Id
    @Column(name = "id_page", nullable = false)
    public int getIdPage() {
        return idPage;
    }

    public void setIdPage(int idPage) {
        this.idPage = idPage;
    }

    @Basic
    @Column(name = "id_page_type", nullable = false)
    public int getIdPageType() {
        return idPageType;
    }

    public void setIdPageType(int idPageType) {
        this.idPageType = idPageType;
    }

    @Basic
    @Column(name = "id_object", nullable = true)
    public Integer getIdObject() {
        return idObject;
    }

    public void setIdObject(Integer idObject) {
        this.idObject = idObject;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PageEntity that = (PageEntity) o;
        return idPage == that.idPage &&
                idPageType == that.idPageType &&
                Objects.equals(idObject, that.idObject);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPage, idPageType, idObject);
    }
}
