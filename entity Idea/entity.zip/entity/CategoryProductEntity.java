package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "category_product", schema = "ps1761", catalog = "")
@IdClass(CategoryProductEntityPK.class)
public class CategoryProductEntity {
    private int idCategory;
    private int idProduct;
    private int position;

    @Id
    @Column(name = "id_category", nullable = false)
    public int getIdCategory() {
        return idCategory;
    }

    public void setIdCategory(int idCategory) {
        this.idCategory = idCategory;
    }

    @Id
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Basic
    @Column(name = "position", nullable = false)
    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CategoryProductEntity that = (CategoryProductEntity) o;
        return idCategory == that.idCategory &&
                idProduct == that.idProduct &&
                position == that.position;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCategory, idProduct, position);
    }
}
