package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "layered_product_attribute", schema = "ps1761", catalog = "")
@IdClass(LayeredProductAttributeEntityPK.class)
public class LayeredProductAttributeEntity {
    private int idAttribute;
    private int idProduct;
    private int idAttributeGroup;
    private int idShop;

    @Id
    @Column(name = "id_attribute", nullable = false)
    public int getIdAttribute() {
        return idAttribute;
    }

    public void setIdAttribute(int idAttribute) {
        this.idAttribute = idAttribute;
    }

    @Id
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Basic
    @Column(name = "id_attribute_group", nullable = false)
    public int getIdAttributeGroup() {
        return idAttributeGroup;
    }

    public void setIdAttributeGroup(int idAttributeGroup) {
        this.idAttributeGroup = idAttributeGroup;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LayeredProductAttributeEntity that = (LayeredProductAttributeEntity) o;
        return idAttribute == that.idAttribute &&
                idProduct == that.idProduct &&
                idAttributeGroup == that.idAttributeGroup &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAttribute, idProduct, idAttributeGroup, idShop);
    }
}
