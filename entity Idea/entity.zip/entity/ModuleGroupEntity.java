package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "module_group", schema = "ps1761", catalog = "")
@IdClass(ModuleGroupEntityPK.class)
public class ModuleGroupEntity {
    private int idModule;
    private int idShop;
    private int idGroup;

    @Id
    @Column(name = "id_module", nullable = false)
    public int getIdModule() {
        return idModule;
    }

    public void setIdModule(int idModule) {
        this.idModule = idModule;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Id
    @Column(name = "id_group", nullable = false)
    public int getIdGroup() {
        return idGroup;
    }

    public void setIdGroup(int idGroup) {
        this.idGroup = idGroup;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ModuleGroupEntity that = (ModuleGroupEntity) o;
        return idModule == that.idModule &&
                idShop == that.idShop &&
                idGroup == that.idGroup;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idModule, idShop, idGroup);
    }
}
