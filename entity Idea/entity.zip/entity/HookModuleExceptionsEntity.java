package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "hook_module_exceptions", schema = "ps1761", catalog = "")
public class HookModuleExceptionsEntity {
    private int idHookModuleExceptions;
    private int idShop;
    private int idModule;
    private int idHook;
    private String fileName;

    @Id
    @Column(name = "id_hook_module_exceptions", nullable = false)
    public int getIdHookModuleExceptions() {
        return idHookModuleExceptions;
    }

    public void setIdHookModuleExceptions(int idHookModuleExceptions) {
        this.idHookModuleExceptions = idHookModuleExceptions;
    }

    @Basic
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "id_module", nullable = false)
    public int getIdModule() {
        return idModule;
    }

    public void setIdModule(int idModule) {
        this.idModule = idModule;
    }

    @Basic
    @Column(name = "id_hook", nullable = false)
    public int getIdHook() {
        return idHook;
    }

    public void setIdHook(int idHook) {
        this.idHook = idHook;
    }

    @Basic
    @Column(name = "file_name", nullable = true, length = 255)
    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        HookModuleExceptionsEntity that = (HookModuleExceptionsEntity) o;
        return idHookModuleExceptions == that.idHookModuleExceptions &&
                idShop == that.idShop &&
                idModule == that.idModule &&
                idHook == that.idHook &&
                Objects.equals(fileName, that.fileName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idHookModuleExceptions, idShop, idModule, idHook, fileName);
    }
}
