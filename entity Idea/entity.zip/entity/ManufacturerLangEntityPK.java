package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class ManufacturerLangEntityPK implements Serializable {
    private int idManufacturer;
    private int idLang;

    @Column(name = "id_manufacturer", nullable = false)
    @Id
    public int getIdManufacturer() {
        return idManufacturer;
    }

    public void setIdManufacturer(int idManufacturer) {
        this.idManufacturer = idManufacturer;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ManufacturerLangEntityPK that = (ManufacturerLangEntityPK) o;
        return idManufacturer == that.idManufacturer &&
                idLang == that.idLang;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idManufacturer, idLang);
    }
}
