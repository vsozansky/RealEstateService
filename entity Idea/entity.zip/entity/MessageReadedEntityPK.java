package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class MessageReadedEntityPK implements Serializable {
    private int idMessage;
    private int idEmployee;

    @Column(name = "id_message", nullable = false)
    @Id
    public int getIdMessage() {
        return idMessage;
    }

    public void setIdMessage(int idMessage) {
        this.idMessage = idMessage;
    }

    @Column(name = "id_employee", nullable = false)
    @Id
    public int getIdEmployee() {
        return idEmployee;
    }

    public void setIdEmployee(int idEmployee) {
        this.idEmployee = idEmployee;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MessageReadedEntityPK that = (MessageReadedEntityPK) o;
        return idMessage == that.idMessage &&
                idEmployee == that.idEmployee;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idMessage, idEmployee);
    }
}
