package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "attribute_group", schema = "ps1761", catalog = "")
public class AttributeGroupEntity {
    private int idAttributeGroup;
    private byte isColorGroup;
    private String groupType;
    private int position;

    @Id
    @Column(name = "id_attribute_group", nullable = false)
    public int getIdAttributeGroup() {
        return idAttributeGroup;
    }

    public void setIdAttributeGroup(int idAttributeGroup) {
        this.idAttributeGroup = idAttributeGroup;
    }

    @Basic
    @Column(name = "is_color_group", nullable = false)
    public byte getIsColorGroup() {
        return isColorGroup;
    }

    public void setIsColorGroup(byte isColorGroup) {
        this.isColorGroup = isColorGroup;
    }

    @Basic
    @Column(name = "group_type", nullable = false, length = 255)
    public String getGroupType() {
        return groupType;
    }

    public void setGroupType(String groupType) {
        this.groupType = groupType;
    }

    @Basic
    @Column(name = "position", nullable = false)
    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AttributeGroupEntity that = (AttributeGroupEntity) o;
        return idAttributeGroup == that.idAttributeGroup &&
                isColorGroup == that.isColorGroup &&
                position == that.position &&
                Objects.equals(groupType, that.groupType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAttributeGroup, isColorGroup, groupType, position);
    }
}
