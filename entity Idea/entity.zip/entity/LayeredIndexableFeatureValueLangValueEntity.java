package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "layered_indexable_feature_value_lang_value", schema = "ps1761", catalog = "")
@IdClass(LayeredIndexableFeatureValueLangValueEntityPK.class)
public class LayeredIndexableFeatureValueLangValueEntity {
    private int idFeatureValue;
    private int idLang;
    private String urlName;
    private String metaTitle;

    @Id
    @Column(name = "id_feature_value", nullable = false)
    public int getIdFeatureValue() {
        return idFeatureValue;
    }

    public void setIdFeatureValue(int idFeatureValue) {
        this.idFeatureValue = idFeatureValue;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "url_name", nullable = true, length = 128)
    public String getUrlName() {
        return urlName;
    }

    public void setUrlName(String urlName) {
        this.urlName = urlName;
    }

    @Basic
    @Column(name = "meta_title", nullable = true, length = 128)
    public String getMetaTitle() {
        return metaTitle;
    }

    public void setMetaTitle(String metaTitle) {
        this.metaTitle = metaTitle;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LayeredIndexableFeatureValueLangValueEntity that = (LayeredIndexableFeatureValueLangValueEntity) o;
        return idFeatureValue == that.idFeatureValue &&
                idLang == that.idLang &&
                Objects.equals(urlName, that.urlName) &&
                Objects.equals(metaTitle, that.metaTitle);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idFeatureValue, idLang, urlName, metaTitle);
    }
}
