package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class StoreShopEntityPK implements Serializable {
    private int idStore;
    private int idShop;

    @Column(name = "id_store", nullable = false)
    @Id
    public int getIdStore() {
        return idStore;
    }

    public void setIdStore(int idStore) {
        this.idStore = idStore;
    }

    @Column(name = "id_shop", nullable = false)
    @Id
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StoreShopEntityPK that = (StoreShopEntityPK) o;
        return idStore == that.idStore &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idStore, idShop);
    }
}
