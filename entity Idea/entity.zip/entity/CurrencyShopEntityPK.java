package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class CurrencyShopEntityPK implements Serializable {
    private int idCurrency;
    private int idShop;

    @Column(name = "id_currency", nullable = false)
    @Id
    public int getIdCurrency() {
        return idCurrency;
    }

    public void setIdCurrency(int idCurrency) {
        this.idCurrency = idCurrency;
    }

    @Column(name = "id_shop", nullable = false)
    @Id
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CurrencyShopEntityPK that = (CurrencyShopEntityPK) o;
        return idCurrency == that.idCurrency &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCurrency, idShop);
    }
}
