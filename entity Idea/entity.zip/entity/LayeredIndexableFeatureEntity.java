package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "layered_indexable_feature", schema = "ps1761", catalog = "")
public class LayeredIndexableFeatureEntity {
    private int idFeature;
    private byte indexable;

    @Id
    @Column(name = "id_feature", nullable = false)
    public int getIdFeature() {
        return idFeature;
    }

    public void setIdFeature(int idFeature) {
        this.idFeature = idFeature;
    }

    @Basic
    @Column(name = "indexable", nullable = false)
    public byte getIndexable() {
        return indexable;
    }

    public void setIndexable(byte indexable) {
        this.indexable = indexable;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LayeredIndexableFeatureEntity that = (LayeredIndexableFeatureEntity) o;
        return idFeature == that.idFeature &&
                indexable == that.indexable;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idFeature, indexable);
    }
}
