package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class WarehouseShopEntityPK implements Serializable {
    private int idShop;
    private int idWarehouse;

    @Column(name = "id_shop", nullable = false)
    @Id
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Column(name = "id_warehouse", nullable = false)
    @Id
    public int getIdWarehouse() {
        return idWarehouse;
    }

    public void setIdWarehouse(int idWarehouse) {
        this.idWarehouse = idWarehouse;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WarehouseShopEntityPK that = (WarehouseShopEntityPK) o;
        return idShop == that.idShop &&
                idWarehouse == that.idWarehouse;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idShop, idWarehouse);
    }
}
