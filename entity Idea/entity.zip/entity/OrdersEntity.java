package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "orders", schema = "ps1761", catalog = "")
public class OrdersEntity {
    private int idOrder;
    private String reference;
    private int idShopGroup;
    private int idShop;
    private int idCarrier;
    private int idLang;
    private int idCustomer;
    private int idCart;
    private int idCurrency;
    private int idAddressDelivery;
    private int idAddressInvoice;
    private int currentState;
    private String secureKey;
    private String payment;
    private BigDecimal conversionRate;
    private String module;
    private byte recyclable;
    private byte gift;
    private String giftMessage;
    private byte mobileTheme;
    private String shippingNumber;
    private BigDecimal totalDiscounts;
    private BigDecimal totalDiscountsTaxIncl;
    private BigDecimal totalDiscountsTaxExcl;
    private BigDecimal totalPaid;
    private BigDecimal totalPaidTaxIncl;
    private BigDecimal totalPaidTaxExcl;
    private BigDecimal totalPaidReal;
    private BigDecimal totalProducts;
    private BigDecimal totalProductsWt;
    private BigDecimal totalShipping;
    private BigDecimal totalShippingTaxIncl;
    private BigDecimal totalShippingTaxExcl;
    private BigDecimal carrierTaxRate;
    private BigDecimal totalWrapping;
    private BigDecimal totalWrappingTaxIncl;
    private BigDecimal totalWrappingTaxExcl;
    private byte roundMode;
    private byte roundType;
    private int invoiceNumber;
    private int deliveryNumber;
    private Timestamp invoiceDate;
    private Timestamp deliveryDate;
    private int valid;
    private Timestamp dateAdd;
    private Timestamp dateUpd;

    @Id
    @Column(name = "id_order", nullable = false)
    public int getIdOrder() {
        return idOrder;
    }

    public void setIdOrder(int idOrder) {
        this.idOrder = idOrder;
    }

    @Basic
    @Column(name = "reference", nullable = true, length = 9)
    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    @Basic
    @Column(name = "id_shop_group", nullable = false)
    public int getIdShopGroup() {
        return idShopGroup;
    }

    public void setIdShopGroup(int idShopGroup) {
        this.idShopGroup = idShopGroup;
    }

    @Basic
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "id_carrier", nullable = false)
    public int getIdCarrier() {
        return idCarrier;
    }

    public void setIdCarrier(int idCarrier) {
        this.idCarrier = idCarrier;
    }

    @Basic
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "id_customer", nullable = false)
    public int getIdCustomer() {
        return idCustomer;
    }

    public void setIdCustomer(int idCustomer) {
        this.idCustomer = idCustomer;
    }

    @Basic
    @Column(name = "id_cart", nullable = false)
    public int getIdCart() {
        return idCart;
    }

    public void setIdCart(int idCart) {
        this.idCart = idCart;
    }

    @Basic
    @Column(name = "id_currency", nullable = false)
    public int getIdCurrency() {
        return idCurrency;
    }

    public void setIdCurrency(int idCurrency) {
        this.idCurrency = idCurrency;
    }

    @Basic
    @Column(name = "id_address_delivery", nullable = false)
    public int getIdAddressDelivery() {
        return idAddressDelivery;
    }

    public void setIdAddressDelivery(int idAddressDelivery) {
        this.idAddressDelivery = idAddressDelivery;
    }

    @Basic
    @Column(name = "id_address_invoice", nullable = false)
    public int getIdAddressInvoice() {
        return idAddressInvoice;
    }

    public void setIdAddressInvoice(int idAddressInvoice) {
        this.idAddressInvoice = idAddressInvoice;
    }

    @Basic
    @Column(name = "current_state", nullable = false)
    public int getCurrentState() {
        return currentState;
    }

    public void setCurrentState(int currentState) {
        this.currentState = currentState;
    }

    @Basic
    @Column(name = "secure_key", nullable = false, length = 32)
    public String getSecureKey() {
        return secureKey;
    }

    public void setSecureKey(String secureKey) {
        this.secureKey = secureKey;
    }

    @Basic
    @Column(name = "payment", nullable = false, length = 255)
    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        this.payment = payment;
    }

    @Basic
    @Column(name = "conversion_rate", nullable = false, precision = 6)
    public BigDecimal getConversionRate() {
        return conversionRate;
    }

    public void setConversionRate(BigDecimal conversionRate) {
        this.conversionRate = conversionRate;
    }

    @Basic
    @Column(name = "module", nullable = true, length = 255)
    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    @Basic
    @Column(name = "recyclable", nullable = false)
    public byte getRecyclable() {
        return recyclable;
    }

    public void setRecyclable(byte recyclable) {
        this.recyclable = recyclable;
    }

    @Basic
    @Column(name = "gift", nullable = false)
    public byte getGift() {
        return gift;
    }

    public void setGift(byte gift) {
        this.gift = gift;
    }

    @Basic
    @Column(name = "gift_message", nullable = true, length = -1)
    public String getGiftMessage() {
        return giftMessage;
    }

    public void setGiftMessage(String giftMessage) {
        this.giftMessage = giftMessage;
    }

    @Basic
    @Column(name = "mobile_theme", nullable = false)
    public byte getMobileTheme() {
        return mobileTheme;
    }

    public void setMobileTheme(byte mobileTheme) {
        this.mobileTheme = mobileTheme;
    }

    @Basic
    @Column(name = "shipping_number", nullable = true, length = 64)
    public String getShippingNumber() {
        return shippingNumber;
    }

    public void setShippingNumber(String shippingNumber) {
        this.shippingNumber = shippingNumber;
    }

    @Basic
    @Column(name = "total_discounts", nullable = false, precision = 6)
    public BigDecimal getTotalDiscounts() {
        return totalDiscounts;
    }

    public void setTotalDiscounts(BigDecimal totalDiscounts) {
        this.totalDiscounts = totalDiscounts;
    }

    @Basic
    @Column(name = "total_discounts_tax_incl", nullable = false, precision = 6)
    public BigDecimal getTotalDiscountsTaxIncl() {
        return totalDiscountsTaxIncl;
    }

    public void setTotalDiscountsTaxIncl(BigDecimal totalDiscountsTaxIncl) {
        this.totalDiscountsTaxIncl = totalDiscountsTaxIncl;
    }

    @Basic
    @Column(name = "total_discounts_tax_excl", nullable = false, precision = 6)
    public BigDecimal getTotalDiscountsTaxExcl() {
        return totalDiscountsTaxExcl;
    }

    public void setTotalDiscountsTaxExcl(BigDecimal totalDiscountsTaxExcl) {
        this.totalDiscountsTaxExcl = totalDiscountsTaxExcl;
    }

    @Basic
    @Column(name = "total_paid", nullable = false, precision = 6)
    public BigDecimal getTotalPaid() {
        return totalPaid;
    }

    public void setTotalPaid(BigDecimal totalPaid) {
        this.totalPaid = totalPaid;
    }

    @Basic
    @Column(name = "total_paid_tax_incl", nullable = false, precision = 6)
    public BigDecimal getTotalPaidTaxIncl() {
        return totalPaidTaxIncl;
    }

    public void setTotalPaidTaxIncl(BigDecimal totalPaidTaxIncl) {
        this.totalPaidTaxIncl = totalPaidTaxIncl;
    }

    @Basic
    @Column(name = "total_paid_tax_excl", nullable = false, precision = 6)
    public BigDecimal getTotalPaidTaxExcl() {
        return totalPaidTaxExcl;
    }

    public void setTotalPaidTaxExcl(BigDecimal totalPaidTaxExcl) {
        this.totalPaidTaxExcl = totalPaidTaxExcl;
    }

    @Basic
    @Column(name = "total_paid_real", nullable = false, precision = 6)
    public BigDecimal getTotalPaidReal() {
        return totalPaidReal;
    }

    public void setTotalPaidReal(BigDecimal totalPaidReal) {
        this.totalPaidReal = totalPaidReal;
    }

    @Basic
    @Column(name = "total_products", nullable = false, precision = 6)
    public BigDecimal getTotalProducts() {
        return totalProducts;
    }

    public void setTotalProducts(BigDecimal totalProducts) {
        this.totalProducts = totalProducts;
    }

    @Basic
    @Column(name = "total_products_wt", nullable = false, precision = 6)
    public BigDecimal getTotalProductsWt() {
        return totalProductsWt;
    }

    public void setTotalProductsWt(BigDecimal totalProductsWt) {
        this.totalProductsWt = totalProductsWt;
    }

    @Basic
    @Column(name = "total_shipping", nullable = false, precision = 6)
    public BigDecimal getTotalShipping() {
        return totalShipping;
    }

    public void setTotalShipping(BigDecimal totalShipping) {
        this.totalShipping = totalShipping;
    }

    @Basic
    @Column(name = "total_shipping_tax_incl", nullable = false, precision = 6)
    public BigDecimal getTotalShippingTaxIncl() {
        return totalShippingTaxIncl;
    }

    public void setTotalShippingTaxIncl(BigDecimal totalShippingTaxIncl) {
        this.totalShippingTaxIncl = totalShippingTaxIncl;
    }

    @Basic
    @Column(name = "total_shipping_tax_excl", nullable = false, precision = 6)
    public BigDecimal getTotalShippingTaxExcl() {
        return totalShippingTaxExcl;
    }

    public void setTotalShippingTaxExcl(BigDecimal totalShippingTaxExcl) {
        this.totalShippingTaxExcl = totalShippingTaxExcl;
    }

    @Basic
    @Column(name = "carrier_tax_rate", nullable = false, precision = 3)
    public BigDecimal getCarrierTaxRate() {
        return carrierTaxRate;
    }

    public void setCarrierTaxRate(BigDecimal carrierTaxRate) {
        this.carrierTaxRate = carrierTaxRate;
    }

    @Basic
    @Column(name = "total_wrapping", nullable = false, precision = 6)
    public BigDecimal getTotalWrapping() {
        return totalWrapping;
    }

    public void setTotalWrapping(BigDecimal totalWrapping) {
        this.totalWrapping = totalWrapping;
    }

    @Basic
    @Column(name = "total_wrapping_tax_incl", nullable = false, precision = 6)
    public BigDecimal getTotalWrappingTaxIncl() {
        return totalWrappingTaxIncl;
    }

    public void setTotalWrappingTaxIncl(BigDecimal totalWrappingTaxIncl) {
        this.totalWrappingTaxIncl = totalWrappingTaxIncl;
    }

    @Basic
    @Column(name = "total_wrapping_tax_excl", nullable = false, precision = 6)
    public BigDecimal getTotalWrappingTaxExcl() {
        return totalWrappingTaxExcl;
    }

    public void setTotalWrappingTaxExcl(BigDecimal totalWrappingTaxExcl) {
        this.totalWrappingTaxExcl = totalWrappingTaxExcl;
    }

    @Basic
    @Column(name = "round_mode", nullable = false)
    public byte getRoundMode() {
        return roundMode;
    }

    public void setRoundMode(byte roundMode) {
        this.roundMode = roundMode;
    }

    @Basic
    @Column(name = "round_type", nullable = false)
    public byte getRoundType() {
        return roundType;
    }

    public void setRoundType(byte roundType) {
        this.roundType = roundType;
    }

    @Basic
    @Column(name = "invoice_number", nullable = false)
    public int getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(int invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    @Basic
    @Column(name = "delivery_number", nullable = false)
    public int getDeliveryNumber() {
        return deliveryNumber;
    }

    public void setDeliveryNumber(int deliveryNumber) {
        this.deliveryNumber = deliveryNumber;
    }

    @Basic
    @Column(name = "invoice_date", nullable = false)
    public Timestamp getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(Timestamp invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    @Basic
    @Column(name = "delivery_date", nullable = false)
    public Timestamp getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(Timestamp deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    @Basic
    @Column(name = "valid", nullable = false)
    public int getValid() {
        return valid;
    }

    public void setValid(int valid) {
        this.valid = valid;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Basic
    @Column(name = "date_upd", nullable = false)
    public Timestamp getDateUpd() {
        return dateUpd;
    }

    public void setDateUpd(Timestamp dateUpd) {
        this.dateUpd = dateUpd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrdersEntity that = (OrdersEntity) o;
        return idOrder == that.idOrder &&
                idShopGroup == that.idShopGroup &&
                idShop == that.idShop &&
                idCarrier == that.idCarrier &&
                idLang == that.idLang &&
                idCustomer == that.idCustomer &&
                idCart == that.idCart &&
                idCurrency == that.idCurrency &&
                idAddressDelivery == that.idAddressDelivery &&
                idAddressInvoice == that.idAddressInvoice &&
                currentState == that.currentState &&
                recyclable == that.recyclable &&
                gift == that.gift &&
                mobileTheme == that.mobileTheme &&
                roundMode == that.roundMode &&
                roundType == that.roundType &&
                invoiceNumber == that.invoiceNumber &&
                deliveryNumber == that.deliveryNumber &&
                valid == that.valid &&
                Objects.equals(reference, that.reference) &&
                Objects.equals(secureKey, that.secureKey) &&
                Objects.equals(payment, that.payment) &&
                Objects.equals(conversionRate, that.conversionRate) &&
                Objects.equals(module, that.module) &&
                Objects.equals(giftMessage, that.giftMessage) &&
                Objects.equals(shippingNumber, that.shippingNumber) &&
                Objects.equals(totalDiscounts, that.totalDiscounts) &&
                Objects.equals(totalDiscountsTaxIncl, that.totalDiscountsTaxIncl) &&
                Objects.equals(totalDiscountsTaxExcl, that.totalDiscountsTaxExcl) &&
                Objects.equals(totalPaid, that.totalPaid) &&
                Objects.equals(totalPaidTaxIncl, that.totalPaidTaxIncl) &&
                Objects.equals(totalPaidTaxExcl, that.totalPaidTaxExcl) &&
                Objects.equals(totalPaidReal, that.totalPaidReal) &&
                Objects.equals(totalProducts, that.totalProducts) &&
                Objects.equals(totalProductsWt, that.totalProductsWt) &&
                Objects.equals(totalShipping, that.totalShipping) &&
                Objects.equals(totalShippingTaxIncl, that.totalShippingTaxIncl) &&
                Objects.equals(totalShippingTaxExcl, that.totalShippingTaxExcl) &&
                Objects.equals(carrierTaxRate, that.carrierTaxRate) &&
                Objects.equals(totalWrapping, that.totalWrapping) &&
                Objects.equals(totalWrappingTaxIncl, that.totalWrappingTaxIncl) &&
                Objects.equals(totalWrappingTaxExcl, that.totalWrappingTaxExcl) &&
                Objects.equals(invoiceDate, that.invoiceDate) &&
                Objects.equals(deliveryDate, that.deliveryDate) &&
                Objects.equals(dateAdd, that.dateAdd) &&
                Objects.equals(dateUpd, that.dateUpd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrder, reference, idShopGroup, idShop, idCarrier, idLang, idCustomer, idCart, idCurrency, idAddressDelivery, idAddressInvoice, currentState, secureKey, payment, conversionRate, module, recyclable, gift, giftMessage, mobileTheme, shippingNumber, totalDiscounts, totalDiscountsTaxIncl, totalDiscountsTaxExcl, totalPaid, totalPaidTaxIncl, totalPaidTaxExcl, totalPaidReal, totalProducts, totalProductsWt, totalShipping, totalShippingTaxIncl, totalShippingTaxExcl, carrierTaxRate, totalWrapping, totalWrappingTaxIncl, totalWrappingTaxExcl, roundMode, roundType, invoiceNumber, deliveryNumber, invoiceDate, deliveryDate, valid, dateAdd, dateUpd);
    }
}
