package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "sekeyword", schema = "ps1761", catalog = "")
public class SekeywordEntity {
    private int idSekeyword;
    private int idShop;
    private int idShopGroup;
    private String keyword;
    private Timestamp dateAdd;

    @Id
    @Column(name = "id_sekeyword", nullable = false)
    public int getIdSekeyword() {
        return idSekeyword;
    }

    public void setIdSekeyword(int idSekeyword) {
        this.idSekeyword = idSekeyword;
    }

    @Basic
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "id_shop_group", nullable = false)
    public int getIdShopGroup() {
        return idShopGroup;
    }

    public void setIdShopGroup(int idShopGroup) {
        this.idShopGroup = idShopGroup;
    }

    @Basic
    @Column(name = "keyword", nullable = false, length = 256)
    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SekeywordEntity that = (SekeywordEntity) o;
        return idSekeyword == that.idSekeyword &&
                idShop == that.idShop &&
                idShopGroup == that.idShopGroup &&
                Objects.equals(keyword, that.keyword) &&
                Objects.equals(dateAdd, that.dateAdd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idSekeyword, idShop, idShopGroup, keyword, dateAdd);
    }
}
