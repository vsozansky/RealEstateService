package com.jprestashop.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Objects;

@Entity
@Table(name = "linksmenutop_lang", schema = "ps1761", catalog = "")
public class LinksmenutopLangEntity {
    private int idLinksmenutop;
    private int idLang;
    private int idShop;
    private String label;
    private String link;

    @Basic
    @Column(name = "id_linksmenutop", nullable = false)
    public int getIdLinksmenutop() {
        return idLinksmenutop;
    }

    public void setIdLinksmenutop(int idLinksmenutop) {
        this.idLinksmenutop = idLinksmenutop;
    }

    @Basic
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "label", nullable = false, length = 128)
    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    @Basic
    @Column(name = "link", nullable = false, length = 128)
    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LinksmenutopLangEntity that = (LinksmenutopLangEntity) o;
        return idLinksmenutop == that.idLinksmenutop &&
                idLang == that.idLang &&
                idShop == that.idShop &&
                Objects.equals(label, that.label) &&
                Objects.equals(link, that.link);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idLinksmenutop, idLang, idShop, label, link);
    }
}
