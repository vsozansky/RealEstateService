package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class TabLangEntityPK implements Serializable {
    private int idTab;
    private int idLang;

    @Column(name = "id_tab", nullable = false)
    @Id
    public int getIdTab() {
        return idTab;
    }

    public void setIdTab(int idTab) {
        this.idTab = idTab;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TabLangEntityPK that = (TabLangEntityPK) o;
        return idTab == that.idTab &&
                idLang == that.idLang;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idTab, idLang);
    }
}
