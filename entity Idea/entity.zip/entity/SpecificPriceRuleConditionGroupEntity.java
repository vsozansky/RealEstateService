package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "specific_price_rule_condition_group", schema = "ps1761", catalog = "")
@IdClass(SpecificPriceRuleConditionGroupEntityPK.class)
public class SpecificPriceRuleConditionGroupEntity {
    private int idSpecificPriceRuleConditionGroup;
    private int idSpecificPriceRule;

    @Id
    @Column(name = "id_specific_price_rule_condition_group", nullable = false)
    public int getIdSpecificPriceRuleConditionGroup() {
        return idSpecificPriceRuleConditionGroup;
    }

    public void setIdSpecificPriceRuleConditionGroup(int idSpecificPriceRuleConditionGroup) {
        this.idSpecificPriceRuleConditionGroup = idSpecificPriceRuleConditionGroup;
    }

    @Id
    @Column(name = "id_specific_price_rule", nullable = false)
    public int getIdSpecificPriceRule() {
        return idSpecificPriceRule;
    }

    public void setIdSpecificPriceRule(int idSpecificPriceRule) {
        this.idSpecificPriceRule = idSpecificPriceRule;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SpecificPriceRuleConditionGroupEntity that = (SpecificPriceRuleConditionGroupEntity) o;
        return idSpecificPriceRuleConditionGroup == that.idSpecificPriceRuleConditionGroup &&
                idSpecificPriceRule == that.idSpecificPriceRule;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idSpecificPriceRuleConditionGroup, idSpecificPriceRule);
    }
}
