package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "layered_filter_shop", schema = "ps1761", catalog = "")
@IdClass(LayeredFilterShopEntityPK.class)
public class LayeredFilterShopEntity {
    private int idLayeredFilter;
    private int idShop;

    @Id
    @Column(name = "id_layered_filter", nullable = false)
    public int getIdLayeredFilter() {
        return idLayeredFilter;
    }

    public void setIdLayeredFilter(int idLayeredFilter) {
        this.idLayeredFilter = idLayeredFilter;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LayeredFilterShopEntity that = (LayeredFilterShopEntity) o;
        return idLayeredFilter == that.idLayeredFilter &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idLayeredFilter, idShop);
    }
}
