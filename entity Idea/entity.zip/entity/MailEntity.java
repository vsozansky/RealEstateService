package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "mail", schema = "ps1761", catalog = "")
public class MailEntity {
    private int idMail;
    private String recipient;
    private String template;
    private String subject;
    private int idLang;
    private Timestamp dateAdd;

    @Id
    @Column(name = "id_mail", nullable = false)
    public int getIdMail() {
        return idMail;
    }

    public void setIdMail(int idMail) {
        this.idMail = idMail;
    }

    @Basic
    @Column(name = "recipient", nullable = false, length = 126)
    public String getRecipient() {
        return recipient;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    @Basic
    @Column(name = "template", nullable = false, length = 62)
    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    @Basic
    @Column(name = "subject", nullable = false, length = 254)
    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    @Basic
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MailEntity that = (MailEntity) o;
        return idMail == that.idMail &&
                idLang == that.idLang &&
                Objects.equals(recipient, that.recipient) &&
                Objects.equals(template, that.template) &&
                Objects.equals(subject, that.subject) &&
                Objects.equals(dateAdd, that.dateAdd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idMail, recipient, template, subject, idLang, dateAdd);
    }
}
