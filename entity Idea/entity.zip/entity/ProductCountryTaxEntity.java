package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "product_country_tax", schema = "ps1761", catalog = "")
@IdClass(ProductCountryTaxEntityPK.class)
public class ProductCountryTaxEntity {
    private int idProduct;
    private int idCountry;
    private int idTax;

    @Id
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Id
    @Column(name = "id_country", nullable = false)
    public int getIdCountry() {
        return idCountry;
    }

    public void setIdCountry(int idCountry) {
        this.idCountry = idCountry;
    }

    @Basic
    @Column(name = "id_tax", nullable = false)
    public int getIdTax() {
        return idTax;
    }

    public void setIdTax(int idTax) {
        this.idTax = idTax;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductCountryTaxEntity that = (ProductCountryTaxEntity) o;
        return idProduct == that.idProduct &&
                idCountry == that.idCountry &&
                idTax == that.idTax;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProduct, idCountry, idTax);
    }
}
