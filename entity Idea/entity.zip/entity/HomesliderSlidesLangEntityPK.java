package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class HomesliderSlidesLangEntityPK implements Serializable {
    private int idHomesliderSlides;
    private int idLang;

    @Column(name = "id_homeslider_slides", nullable = false)
    @Id
    public int getIdHomesliderSlides() {
        return idHomesliderSlides;
    }

    public void setIdHomesliderSlides(int idHomesliderSlides) {
        this.idHomesliderSlides = idHomesliderSlides;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        HomesliderSlidesLangEntityPK that = (HomesliderSlidesLangEntityPK) o;
        return idHomesliderSlides == that.idHomesliderSlides &&
                idLang == that.idLang;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idHomesliderSlides, idLang);
    }
}
