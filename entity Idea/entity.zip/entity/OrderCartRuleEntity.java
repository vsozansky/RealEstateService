package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name = "order_cart_rule", schema = "ps1761", catalog = "")
public class OrderCartRuleEntity {
    private int idOrderCartRule;
    private int idOrder;
    private int idCartRule;
    private Integer idOrderInvoice;
    private String name;
    private BigDecimal value;
    private BigDecimal valueTaxExcl;
    private byte freeShipping;

    @Id
    @Column(name = "id_order_cart_rule", nullable = false)
    public int getIdOrderCartRule() {
        return idOrderCartRule;
    }

    public void setIdOrderCartRule(int idOrderCartRule) {
        this.idOrderCartRule = idOrderCartRule;
    }

    @Basic
    @Column(name = "id_order", nullable = false)
    public int getIdOrder() {
        return idOrder;
    }

    public void setIdOrder(int idOrder) {
        this.idOrder = idOrder;
    }

    @Basic
    @Column(name = "id_cart_rule", nullable = false)
    public int getIdCartRule() {
        return idCartRule;
    }

    public void setIdCartRule(int idCartRule) {
        this.idCartRule = idCartRule;
    }

    @Basic
    @Column(name = "id_order_invoice", nullable = true)
    public Integer getIdOrderInvoice() {
        return idOrderInvoice;
    }

    public void setIdOrderInvoice(Integer idOrderInvoice) {
        this.idOrderInvoice = idOrderInvoice;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 254)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "value", nullable = false, precision = 2)
    public BigDecimal getValue() {
        return value;
    }

    public void setValue(BigDecimal value) {
        this.value = value;
    }

    @Basic
    @Column(name = "value_tax_excl", nullable = false, precision = 2)
    public BigDecimal getValueTaxExcl() {
        return valueTaxExcl;
    }

    public void setValueTaxExcl(BigDecimal valueTaxExcl) {
        this.valueTaxExcl = valueTaxExcl;
    }

    @Basic
    @Column(name = "free_shipping", nullable = false)
    public byte getFreeShipping() {
        return freeShipping;
    }

    public void setFreeShipping(byte freeShipping) {
        this.freeShipping = freeShipping;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderCartRuleEntity that = (OrderCartRuleEntity) o;
        return idOrderCartRule == that.idOrderCartRule &&
                idOrder == that.idOrder &&
                idCartRule == that.idCartRule &&
                freeShipping == that.freeShipping &&
                Objects.equals(idOrderInvoice, that.idOrderInvoice) &&
                Objects.equals(name, that.name) &&
                Objects.equals(value, that.value) &&
                Objects.equals(valueTaxExcl, that.valueTaxExcl);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrderCartRule, idOrder, idCartRule, idOrderInvoice, name, value, valueTaxExcl, freeShipping);
    }
}
