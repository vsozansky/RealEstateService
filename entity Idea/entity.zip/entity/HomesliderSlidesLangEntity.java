package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "homeslider_slides_lang", schema = "ps1761", catalog = "")
@IdClass(HomesliderSlidesLangEntityPK.class)
public class HomesliderSlidesLangEntity {
    private int idHomesliderSlides;
    private int idLang;
    private String title;
    private String description;
    private String legend;
    private String url;
    private String image;

    @Id
    @Column(name = "id_homeslider_slides", nullable = false)
    public int getIdHomesliderSlides() {
        return idHomesliderSlides;
    }

    public void setIdHomesliderSlides(int idHomesliderSlides) {
        this.idHomesliderSlides = idHomesliderSlides;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "title", nullable = false, length = 255)
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Basic
    @Column(name = "description", nullable = false, length = -1)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Basic
    @Column(name = "legend", nullable = false, length = 255)
    public String getLegend() {
        return legend;
    }

    public void setLegend(String legend) {
        this.legend = legend;
    }

    @Basic
    @Column(name = "url", nullable = false, length = 255)
    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Basic
    @Column(name = "image", nullable = false, length = 255)
    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        HomesliderSlidesLangEntity that = (HomesliderSlidesLangEntity) o;
        return idHomesliderSlides == that.idHomesliderSlides &&
                idLang == that.idLang &&
                Objects.equals(title, that.title) &&
                Objects.equals(description, that.description) &&
                Objects.equals(legend, that.legend) &&
                Objects.equals(url, that.url) &&
                Objects.equals(image, that.image);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idHomesliderSlides, idLang, title, description, legend, url, image);
    }
}
