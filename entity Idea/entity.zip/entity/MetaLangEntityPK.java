package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class MetaLangEntityPK implements Serializable {
    private int idMeta;
    private int idShop;
    private int idLang;

    @Column(name = "id_meta", nullable = false)
    @Id
    public int getIdMeta() {
        return idMeta;
    }

    public void setIdMeta(int idMeta) {
        this.idMeta = idMeta;
    }

    @Column(name = "id_shop", nullable = false)
    @Id
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MetaLangEntityPK that = (MetaLangEntityPK) o;
        return idMeta == that.idMeta &&
                idShop == that.idShop &&
                idLang == that.idLang;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idMeta, idShop, idLang);
    }
}
