package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "order_message_lang", schema = "ps1761", catalog = "")
@IdClass(OrderMessageLangEntityPK.class)
public class OrderMessageLangEntity {
    private int idOrderMessage;
    private int idLang;
    private String name;
    private String message;

    @Id
    @Column(name = "id_order_message", nullable = false)
    public int getIdOrderMessage() {
        return idOrderMessage;
    }

    public void setIdOrderMessage(int idOrderMessage) {
        this.idOrderMessage = idOrderMessage;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 128)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "message", nullable = false, length = -1)
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderMessageLangEntity that = (OrderMessageLangEntity) o;
        return idOrderMessage == that.idOrderMessage &&
                idLang == that.idLang &&
                Objects.equals(name, that.name) &&
                Objects.equals(message, that.message);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrderMessage, idLang, name, message);
    }
}
