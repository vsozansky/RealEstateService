package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class ConditionEntityPK implements Serializable {
    private int idCondition;
    private int idPsCondition;

    @Column(name = "id_condition", nullable = false)
    @Id
    public int getIdCondition() {
        return idCondition;
    }

    public void setIdCondition(int idCondition) {
        this.idCondition = idCondition;
    }

    @Column(name = "id_ps_condition", nullable = false)
    @Id
    public int getIdPsCondition() {
        return idPsCondition;
    }

    public void setIdPsCondition(int idPsCondition) {
        this.idPsCondition = idPsCondition;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ConditionEntityPK that = (ConditionEntityPK) o;
        return idCondition == that.idCondition &&
                idPsCondition == that.idPsCondition;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCondition, idPsCondition);
    }
}
