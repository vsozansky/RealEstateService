package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "cart_rule_country", schema = "ps1761", catalog = "")
@IdClass(CartRuleCountryEntityPK.class)
public class CartRuleCountryEntity {
    private int idCartRule;
    private int idCountry;

    @Id
    @Column(name = "id_cart_rule", nullable = false)
    public int getIdCartRule() {
        return idCartRule;
    }

    public void setIdCartRule(int idCartRule) {
        this.idCartRule = idCartRule;
    }

    @Id
    @Column(name = "id_country", nullable = false)
    public int getIdCountry() {
        return idCountry;
    }

    public void setIdCountry(int idCountry) {
        this.idCountry = idCountry;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CartRuleCountryEntity that = (CartRuleCountryEntity) o;
        return idCartRule == that.idCartRule &&
                idCountry == that.idCountry;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCartRule, idCountry);
    }
}
