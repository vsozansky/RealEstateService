package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "category_shop", schema = "ps1761", catalog = "")
@IdClass(CategoryShopEntityPK.class)
public class CategoryShopEntity {
    private int idCategory;
    private int idShop;
    private int position;

    @Id
    @Column(name = "id_category", nullable = false)
    public int getIdCategory() {
        return idCategory;
    }

    public void setIdCategory(int idCategory) {
        this.idCategory = idCategory;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "position", nullable = false)
    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CategoryShopEntity that = (CategoryShopEntity) o;
        return idCategory == that.idCategory &&
                idShop == that.idShop &&
                position == that.position;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCategory, idShop, position);
    }
}
