package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "smarty_last_flush", schema = "ps1761", catalog = "")
public class SmartyLastFlushEntity {
    private Object type;
    private Timestamp lastFlush;

    @Id
    @Column(name = "type", nullable = false)
    public Object getType() {
        return type;
    }

    public void setType(Object type) {
        this.type = type;
    }

    @Basic
    @Column(name = "last_flush", nullable = false)
    public Timestamp getLastFlush() {
        return lastFlush;
    }

    public void setLastFlush(Timestamp lastFlush) {
        this.lastFlush = lastFlush;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SmartyLastFlushEntity that = (SmartyLastFlushEntity) o;
        return Objects.equals(type, that.type) &&
                Objects.equals(lastFlush, that.lastFlush);
    }

    @Override
    public int hashCode() {
        return Objects.hash(type, lastFlush);
    }
}
