package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "cms_shop", schema = "ps1761", catalog = "")
@IdClass(CmsShopEntityPK.class)
public class CmsShopEntity {
    private int idCms;
    private int idShop;

    @Id
    @Column(name = "id_cms", nullable = false)
    public int getIdCms() {
        return idCms;
    }

    public void setIdCms(int idCms) {
        this.idCms = idCms;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CmsShopEntity that = (CmsShopEntity) o;
        return idCms == that.idCms &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCms, idShop);
    }
}
