package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "order_invoice_payment", schema = "ps1761", catalog = "")
@IdClass(OrderInvoicePaymentEntityPK.class)
public class OrderInvoicePaymentEntity {
    private int idOrderInvoice;
    private int idOrderPayment;
    private int idOrder;

    @Id
    @Column(name = "id_order_invoice", nullable = false)
    public int getIdOrderInvoice() {
        return idOrderInvoice;
    }

    public void setIdOrderInvoice(int idOrderInvoice) {
        this.idOrderInvoice = idOrderInvoice;
    }

    @Id
    @Column(name = "id_order_payment", nullable = false)
    public int getIdOrderPayment() {
        return idOrderPayment;
    }

    public void setIdOrderPayment(int idOrderPayment) {
        this.idOrderPayment = idOrderPayment;
    }

    @Basic
    @Column(name = "id_order", nullable = false)
    public int getIdOrder() {
        return idOrder;
    }

    public void setIdOrder(int idOrder) {
        this.idOrder = idOrder;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderInvoicePaymentEntity that = (OrderInvoicePaymentEntity) o;
        return idOrderInvoice == that.idOrderInvoice &&
                idOrderPayment == that.idOrderPayment &&
                idOrder == that.idOrder;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrderInvoice, idOrderPayment, idOrder);
    }
}
