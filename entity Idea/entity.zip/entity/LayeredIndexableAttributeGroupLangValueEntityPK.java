package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class LayeredIndexableAttributeGroupLangValueEntityPK implements Serializable {
    private int idAttributeGroup;
    private int idLang;

    @Column(name = "id_attribute_group", nullable = false)
    @Id
    public int getIdAttributeGroup() {
        return idAttributeGroup;
    }

    public void setIdAttributeGroup(int idAttributeGroup) {
        this.idAttributeGroup = idAttributeGroup;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LayeredIndexableAttributeGroupLangValueEntityPK that = (LayeredIndexableAttributeGroupLangValueEntityPK) o;
        return idAttributeGroup == that.idAttributeGroup &&
                idLang == that.idLang;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAttributeGroup, idLang);
    }
}
