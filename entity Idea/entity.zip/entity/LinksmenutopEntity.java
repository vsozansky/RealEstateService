package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "linksmenutop", schema = "ps1761", catalog = "")
public class LinksmenutopEntity {
    private int idLinksmenutop;
    private int idShop;
    private byte newWindow;

    @Id
    @Column(name = "id_linksmenutop", nullable = false)
    public int getIdLinksmenutop() {
        return idLinksmenutop;
    }

    public void setIdLinksmenutop(int idLinksmenutop) {
        this.idLinksmenutop = idLinksmenutop;
    }

    @Basic
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "new_window", nullable = false)
    public byte getNewWindow() {
        return newWindow;
    }

    public void setNewWindow(byte newWindow) {
        this.newWindow = newWindow;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LinksmenutopEntity that = (LinksmenutopEntity) o;
        return idLinksmenutop == that.idLinksmenutop &&
                idShop == that.idShop &&
                newWindow == that.newWindow;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idLinksmenutop, idShop, newWindow);
    }
}
