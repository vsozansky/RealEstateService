package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class CartProductEntityPK implements Serializable {
    private int idCart;
    private int idProduct;
    private int idAddressDelivery;
    private int idProductAttribute;
    private int idCustomization;

    @Column(name = "id_cart", nullable = false)
    @Id
    public int getIdCart() {
        return idCart;
    }

    public void setIdCart(int idCart) {
        this.idCart = idCart;
    }

    @Column(name = "id_product", nullable = false)
    @Id
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Column(name = "id_address_delivery", nullable = false)
    @Id
    public int getIdAddressDelivery() {
        return idAddressDelivery;
    }

    public void setIdAddressDelivery(int idAddressDelivery) {
        this.idAddressDelivery = idAddressDelivery;
    }

    @Column(name = "id_product_attribute", nullable = false)
    @Id
    public int getIdProductAttribute() {
        return idProductAttribute;
    }

    public void setIdProductAttribute(int idProductAttribute) {
        this.idProductAttribute = idProductAttribute;
    }

    @Column(name = "id_customization", nullable = false)
    @Id
    public int getIdCustomization() {
        return idCustomization;
    }

    public void setIdCustomization(int idCustomization) {
        this.idCustomization = idCustomization;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CartProductEntityPK that = (CartProductEntityPK) o;
        return idCart == that.idCart &&
                idProduct == that.idProduct &&
                idAddressDelivery == that.idAddressDelivery &&
                idProductAttribute == that.idProductAttribute &&
                idCustomization == that.idCustomization;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCart, idProduct, idAddressDelivery, idProductAttribute, idCustomization);
    }
}
