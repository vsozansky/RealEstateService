package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class OrderStateLangEntityPK implements Serializable {
    private int idOrderState;
    private int idLang;

    @Column(name = "id_order_state", nullable = false)
    @Id
    public int getIdOrderState() {
        return idOrderState;
    }

    public void setIdOrderState(int idOrderState) {
        this.idOrderState = idOrderState;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderStateLangEntityPK that = (OrderStateLangEntityPK) o;
        return idOrderState == that.idOrderState &&
                idLang == that.idLang;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrderState, idLang);
    }
}
