package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "order_state_lang", schema = "ps1761", catalog = "")
@IdClass(OrderStateLangEntityPK.class)
public class OrderStateLangEntity {
    private int idOrderState;
    private int idLang;
    private String name;
    private String template;

    @Id
    @Column(name = "id_order_state", nullable = false)
    public int getIdOrderState() {
        return idOrderState;
    }

    public void setIdOrderState(int idOrderState) {
        this.idOrderState = idOrderState;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 64)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "template", nullable = false, length = 64)
    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderStateLangEntity that = (OrderStateLangEntity) o;
        return idOrderState == that.idOrderState &&
                idLang == that.idLang &&
                Objects.equals(name, that.name) &&
                Objects.equals(template, that.template);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrderState, idLang, name, template);
    }
}
