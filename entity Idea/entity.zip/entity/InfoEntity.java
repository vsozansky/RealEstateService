package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Objects;

@Entity
@Table(name = "info", schema = "ps1761", catalog = "")
public class InfoEntity {
    private int idInfo;

    @Id
    @Column(name = "id_info", nullable = false)
    public int getIdInfo() {
        return idInfo;
    }

    public void setIdInfo(int idInfo) {
        this.idInfo = idInfo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InfoEntity that = (InfoEntity) o;
        return idInfo == that.idInfo;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idInfo);
    }
}
