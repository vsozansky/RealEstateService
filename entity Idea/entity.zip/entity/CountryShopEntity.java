package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "country_shop", schema = "ps1761", catalog = "")
@IdClass(CountryShopEntityPK.class)
public class CountryShopEntity {
    private int idCountry;
    private int idShop;

    @Id
    @Column(name = "id_country", nullable = false)
    public int getIdCountry() {
        return idCountry;
    }

    public void setIdCountry(int idCountry) {
        this.idCountry = idCountry;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CountryShopEntity that = (CountryShopEntity) o;
        return idCountry == that.idCountry &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCountry, idShop);
    }
}
