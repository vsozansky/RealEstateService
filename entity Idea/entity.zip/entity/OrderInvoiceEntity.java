package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "order_invoice", schema = "ps1761", catalog = "")
public class OrderInvoiceEntity {
    private int idOrderInvoice;
    private int idOrder;
    private int number;
    private int deliveryNumber;
    private Timestamp deliveryDate;
    private BigDecimal totalDiscountTaxExcl;
    private BigDecimal totalDiscountTaxIncl;
    private BigDecimal totalPaidTaxExcl;
    private BigDecimal totalPaidTaxIncl;
    private BigDecimal totalProducts;
    private BigDecimal totalProductsWt;
    private BigDecimal totalShippingTaxExcl;
    private BigDecimal totalShippingTaxIncl;
    private int shippingTaxComputationMethod;
    private BigDecimal totalWrappingTaxExcl;
    private BigDecimal totalWrappingTaxIncl;
    private String shopAddress;
    private String note;
    private Timestamp dateAdd;

    @Id
    @Column(name = "id_order_invoice", nullable = false)
    public int getIdOrderInvoice() {
        return idOrderInvoice;
    }

    public void setIdOrderInvoice(int idOrderInvoice) {
        this.idOrderInvoice = idOrderInvoice;
    }

    @Basic
    @Column(name = "id_order", nullable = false)
    public int getIdOrder() {
        return idOrder;
    }

    public void setIdOrder(int idOrder) {
        this.idOrder = idOrder;
    }

    @Basic
    @Column(name = "number", nullable = false)
    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    @Basic
    @Column(name = "delivery_number", nullable = false)
    public int getDeliveryNumber() {
        return deliveryNumber;
    }

    public void setDeliveryNumber(int deliveryNumber) {
        this.deliveryNumber = deliveryNumber;
    }

    @Basic
    @Column(name = "delivery_date", nullable = true)
    public Timestamp getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(Timestamp deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    @Basic
    @Column(name = "total_discount_tax_excl", nullable = false, precision = 6)
    public BigDecimal getTotalDiscountTaxExcl() {
        return totalDiscountTaxExcl;
    }

    public void setTotalDiscountTaxExcl(BigDecimal totalDiscountTaxExcl) {
        this.totalDiscountTaxExcl = totalDiscountTaxExcl;
    }

    @Basic
    @Column(name = "total_discount_tax_incl", nullable = false, precision = 6)
    public BigDecimal getTotalDiscountTaxIncl() {
        return totalDiscountTaxIncl;
    }

    public void setTotalDiscountTaxIncl(BigDecimal totalDiscountTaxIncl) {
        this.totalDiscountTaxIncl = totalDiscountTaxIncl;
    }

    @Basic
    @Column(name = "total_paid_tax_excl", nullable = false, precision = 6)
    public BigDecimal getTotalPaidTaxExcl() {
        return totalPaidTaxExcl;
    }

    public void setTotalPaidTaxExcl(BigDecimal totalPaidTaxExcl) {
        this.totalPaidTaxExcl = totalPaidTaxExcl;
    }

    @Basic
    @Column(name = "total_paid_tax_incl", nullable = false, precision = 6)
    public BigDecimal getTotalPaidTaxIncl() {
        return totalPaidTaxIncl;
    }

    public void setTotalPaidTaxIncl(BigDecimal totalPaidTaxIncl) {
        this.totalPaidTaxIncl = totalPaidTaxIncl;
    }

    @Basic
    @Column(name = "total_products", nullable = false, precision = 6)
    public BigDecimal getTotalProducts() {
        return totalProducts;
    }

    public void setTotalProducts(BigDecimal totalProducts) {
        this.totalProducts = totalProducts;
    }

    @Basic
    @Column(name = "total_products_wt", nullable = false, precision = 6)
    public BigDecimal getTotalProductsWt() {
        return totalProductsWt;
    }

    public void setTotalProductsWt(BigDecimal totalProductsWt) {
        this.totalProductsWt = totalProductsWt;
    }

    @Basic
    @Column(name = "total_shipping_tax_excl", nullable = false, precision = 6)
    public BigDecimal getTotalShippingTaxExcl() {
        return totalShippingTaxExcl;
    }

    public void setTotalShippingTaxExcl(BigDecimal totalShippingTaxExcl) {
        this.totalShippingTaxExcl = totalShippingTaxExcl;
    }

    @Basic
    @Column(name = "total_shipping_tax_incl", nullable = false, precision = 6)
    public BigDecimal getTotalShippingTaxIncl() {
        return totalShippingTaxIncl;
    }

    public void setTotalShippingTaxIncl(BigDecimal totalShippingTaxIncl) {
        this.totalShippingTaxIncl = totalShippingTaxIncl;
    }

    @Basic
    @Column(name = "shipping_tax_computation_method", nullable = false)
    public int getShippingTaxComputationMethod() {
        return shippingTaxComputationMethod;
    }

    public void setShippingTaxComputationMethod(int shippingTaxComputationMethod) {
        this.shippingTaxComputationMethod = shippingTaxComputationMethod;
    }

    @Basic
    @Column(name = "total_wrapping_tax_excl", nullable = false, precision = 6)
    public BigDecimal getTotalWrappingTaxExcl() {
        return totalWrappingTaxExcl;
    }

    public void setTotalWrappingTaxExcl(BigDecimal totalWrappingTaxExcl) {
        this.totalWrappingTaxExcl = totalWrappingTaxExcl;
    }

    @Basic
    @Column(name = "total_wrapping_tax_incl", nullable = false, precision = 6)
    public BigDecimal getTotalWrappingTaxIncl() {
        return totalWrappingTaxIncl;
    }

    public void setTotalWrappingTaxIncl(BigDecimal totalWrappingTaxIncl) {
        this.totalWrappingTaxIncl = totalWrappingTaxIncl;
    }

    @Basic
    @Column(name = "shop_address", nullable = true, length = -1)
    public String getShopAddress() {
        return shopAddress;
    }

    public void setShopAddress(String shopAddress) {
        this.shopAddress = shopAddress;
    }

    @Basic
    @Column(name = "note", nullable = true, length = -1)
    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderInvoiceEntity that = (OrderInvoiceEntity) o;
        return idOrderInvoice == that.idOrderInvoice &&
                idOrder == that.idOrder &&
                number == that.number &&
                deliveryNumber == that.deliveryNumber &&
                shippingTaxComputationMethod == that.shippingTaxComputationMethod &&
                Objects.equals(deliveryDate, that.deliveryDate) &&
                Objects.equals(totalDiscountTaxExcl, that.totalDiscountTaxExcl) &&
                Objects.equals(totalDiscountTaxIncl, that.totalDiscountTaxIncl) &&
                Objects.equals(totalPaidTaxExcl, that.totalPaidTaxExcl) &&
                Objects.equals(totalPaidTaxIncl, that.totalPaidTaxIncl) &&
                Objects.equals(totalProducts, that.totalProducts) &&
                Objects.equals(totalProductsWt, that.totalProductsWt) &&
                Objects.equals(totalShippingTaxExcl, that.totalShippingTaxExcl) &&
                Objects.equals(totalShippingTaxIncl, that.totalShippingTaxIncl) &&
                Objects.equals(totalWrappingTaxExcl, that.totalWrappingTaxExcl) &&
                Objects.equals(totalWrappingTaxIncl, that.totalWrappingTaxIncl) &&
                Objects.equals(shopAddress, that.shopAddress) &&
                Objects.equals(note, that.note) &&
                Objects.equals(dateAdd, that.dateAdd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrderInvoice, idOrder, number, deliveryNumber, deliveryDate, totalDiscountTaxExcl, totalDiscountTaxIncl, totalPaidTaxExcl, totalPaidTaxIncl, totalProducts, totalProductsWt, totalShippingTaxExcl, totalShippingTaxIncl, shippingTaxComputationMethod, totalWrappingTaxExcl, totalWrappingTaxIncl, shopAddress, note, dateAdd);
    }
}
