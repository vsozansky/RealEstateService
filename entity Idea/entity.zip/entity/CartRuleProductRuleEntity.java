package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "cart_rule_product_rule", schema = "ps1761", catalog = "")
public class CartRuleProductRuleEntity {
    private int idProductRule;
    private int idProductRuleGroup;
    private Object type;

    @Id
    @Column(name = "id_product_rule", nullable = false)
    public int getIdProductRule() {
        return idProductRule;
    }

    public void setIdProductRule(int idProductRule) {
        this.idProductRule = idProductRule;
    }

    @Basic
    @Column(name = "id_product_rule_group", nullable = false)
    public int getIdProductRuleGroup() {
        return idProductRuleGroup;
    }

    public void setIdProductRuleGroup(int idProductRuleGroup) {
        this.idProductRuleGroup = idProductRuleGroup;
    }

    @Basic
    @Column(name = "type", nullable = false)
    public Object getType() {
        return type;
    }

    public void setType(Object type) {
        this.type = type;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CartRuleProductRuleEntity that = (CartRuleProductRuleEntity) o;
        return idProductRule == that.idProductRule &&
                idProductRuleGroup == that.idProductRuleGroup &&
                Objects.equals(type, that.type);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProductRule, idProductRuleGroup, type);
    }
}
