package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "authorization_role", schema = "ps1761", catalog = "")
public class AuthorizationRoleEntity {
    private int idAuthorizationRole;
    private String slug;

    @Id
    @Column(name = "id_authorization_role", nullable = false)
    public int getIdAuthorizationRole() {
        return idAuthorizationRole;
    }

    public void setIdAuthorizationRole(int idAuthorizationRole) {
        this.idAuthorizationRole = idAuthorizationRole;
    }

    @Basic
    @Column(name = "slug", nullable = false, length = 255)
    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AuthorizationRoleEntity that = (AuthorizationRoleEntity) o;
        return idAuthorizationRole == that.idAuthorizationRole &&
                Objects.equals(slug, that.slug);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAuthorizationRole, slug);
    }
}
