package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name = "tax", schema = "ps1761", catalog = "")
public class TaxEntity {
    private int idTax;
    private BigDecimal rate;
    private byte active;
    private byte deleted;

    @Id
    @Column(name = "id_tax", nullable = false)
    public int getIdTax() {
        return idTax;
    }

    public void setIdTax(int idTax) {
        this.idTax = idTax;
    }

    @Basic
    @Column(name = "rate", nullable = false, precision = 3)
    public BigDecimal getRate() {
        return rate;
    }

    public void setRate(BigDecimal rate) {
        this.rate = rate;
    }

    @Basic
    @Column(name = "active", nullable = false)
    public byte getActive() {
        return active;
    }

    public void setActive(byte active) {
        this.active = active;
    }

    @Basic
    @Column(name = "deleted", nullable = false)
    public byte getDeleted() {
        return deleted;
    }

    public void setDeleted(byte deleted) {
        this.deleted = deleted;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TaxEntity taxEntity = (TaxEntity) o;
        return idTax == taxEntity.idTax &&
                active == taxEntity.active &&
                deleted == taxEntity.deleted &&
                Objects.equals(rate, taxEntity.rate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idTax, rate, active, deleted);
    }
}
