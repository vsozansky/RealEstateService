package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "store_shop", schema = "ps1761", catalog = "")
@IdClass(StoreShopEntityPK.class)
public class StoreShopEntity {
    private int idStore;
    private int idShop;

    @Id
    @Column(name = "id_store", nullable = false)
    public int getIdStore() {
        return idStore;
    }

    public void setIdStore(int idStore) {
        this.idStore = idStore;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StoreShopEntity that = (StoreShopEntity) o;
        return idStore == that.idStore &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idStore, idShop);
    }
}
