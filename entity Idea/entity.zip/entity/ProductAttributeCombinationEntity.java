package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "product_attribute_combination", schema = "ps1761", catalog = "")
@IdClass(ProductAttributeCombinationEntityPK.class)
public class ProductAttributeCombinationEntity {
    private int idAttribute;
    private int idProductAttribute;

    @Id
    @Column(name = "id_attribute", nullable = false)
    public int getIdAttribute() {
        return idAttribute;
    }

    public void setIdAttribute(int idAttribute) {
        this.idAttribute = idAttribute;
    }

    @Id
    @Column(name = "id_product_attribute", nullable = false)
    public int getIdProductAttribute() {
        return idProductAttribute;
    }

    public void setIdProductAttribute(int idProductAttribute) {
        this.idProductAttribute = idProductAttribute;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductAttributeCombinationEntity that = (ProductAttributeCombinationEntity) o;
        return idAttribute == that.idAttribute &&
                idProductAttribute == that.idProductAttribute;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAttribute, idProductAttribute);
    }
}
