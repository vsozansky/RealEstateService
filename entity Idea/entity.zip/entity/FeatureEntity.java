package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "feature", schema = "ps1761", catalog = "")
public class FeatureEntity {
    private int idFeature;
    private int position;

    @Id
    @Column(name = "id_feature", nullable = false)
    public int getIdFeature() {
        return idFeature;
    }

    public void setIdFeature(int idFeature) {
        this.idFeature = idFeature;
    }

    @Basic
    @Column(name = "position", nullable = false)
    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FeatureEntity that = (FeatureEntity) o;
        return idFeature == that.idFeature &&
                position == that.position;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idFeature, position);
    }
}
