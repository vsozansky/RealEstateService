package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class ProductAttachmentEntityPK implements Serializable {
    private int idProduct;
    private int idAttachment;

    @Column(name = "id_product", nullable = false)
    @Id
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Column(name = "id_attachment", nullable = false)
    @Id
    public int getIdAttachment() {
        return idAttachment;
    }

    public void setIdAttachment(int idAttachment) {
        this.idAttachment = idAttachment;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductAttachmentEntityPK that = (ProductAttachmentEntityPK) o;
        return idProduct == that.idProduct &&
                idAttachment == that.idAttachment;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProduct, idAttachment);
    }
}
