package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "referrer", schema = "ps1761", catalog = "")
public class ReferrerEntity {
    private int idReferrer;
    private String name;
    private String passwd;
    private String httpRefererRegexp;
    private String httpRefererLike;
    private String requestUriRegexp;
    private String requestUriLike;
    private String httpRefererRegexpNot;
    private String httpRefererLikeNot;
    private String requestUriRegexpNot;
    private String requestUriLikeNot;
    private BigDecimal baseFee;
    private BigDecimal percentFee;
    private BigDecimal clickFee;
    private Timestamp dateAdd;

    @Id
    @Column(name = "id_referrer", nullable = false)
    public int getIdReferrer() {
        return idReferrer;
    }

    public void setIdReferrer(int idReferrer) {
        this.idReferrer = idReferrer;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 64)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "passwd", nullable = true, length = 255)
    public String getPasswd() {
        return passwd;
    }

    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    @Basic
    @Column(name = "http_referer_regexp", nullable = true, length = 64)
    public String getHttpRefererRegexp() {
        return httpRefererRegexp;
    }

    public void setHttpRefererRegexp(String httpRefererRegexp) {
        this.httpRefererRegexp = httpRefererRegexp;
    }

    @Basic
    @Column(name = "http_referer_like", nullable = true, length = 64)
    public String getHttpRefererLike() {
        return httpRefererLike;
    }

    public void setHttpRefererLike(String httpRefererLike) {
        this.httpRefererLike = httpRefererLike;
    }

    @Basic
    @Column(name = "request_uri_regexp", nullable = true, length = 64)
    public String getRequestUriRegexp() {
        return requestUriRegexp;
    }

    public void setRequestUriRegexp(String requestUriRegexp) {
        this.requestUriRegexp = requestUriRegexp;
    }

    @Basic
    @Column(name = "request_uri_like", nullable = true, length = 64)
    public String getRequestUriLike() {
        return requestUriLike;
    }

    public void setRequestUriLike(String requestUriLike) {
        this.requestUriLike = requestUriLike;
    }

    @Basic
    @Column(name = "http_referer_regexp_not", nullable = true, length = 64)
    public String getHttpRefererRegexpNot() {
        return httpRefererRegexpNot;
    }

    public void setHttpRefererRegexpNot(String httpRefererRegexpNot) {
        this.httpRefererRegexpNot = httpRefererRegexpNot;
    }

    @Basic
    @Column(name = "http_referer_like_not", nullable = true, length = 64)
    public String getHttpRefererLikeNot() {
        return httpRefererLikeNot;
    }

    public void setHttpRefererLikeNot(String httpRefererLikeNot) {
        this.httpRefererLikeNot = httpRefererLikeNot;
    }

    @Basic
    @Column(name = "request_uri_regexp_not", nullable = true, length = 64)
    public String getRequestUriRegexpNot() {
        return requestUriRegexpNot;
    }

    public void setRequestUriRegexpNot(String requestUriRegexpNot) {
        this.requestUriRegexpNot = requestUriRegexpNot;
    }

    @Basic
    @Column(name = "request_uri_like_not", nullable = true, length = 64)
    public String getRequestUriLikeNot() {
        return requestUriLikeNot;
    }

    public void setRequestUriLikeNot(String requestUriLikeNot) {
        this.requestUriLikeNot = requestUriLikeNot;
    }

    @Basic
    @Column(name = "base_fee", nullable = false, precision = 2)
    public BigDecimal getBaseFee() {
        return baseFee;
    }

    public void setBaseFee(BigDecimal baseFee) {
        this.baseFee = baseFee;
    }

    @Basic
    @Column(name = "percent_fee", nullable = false, precision = 2)
    public BigDecimal getPercentFee() {
        return percentFee;
    }

    public void setPercentFee(BigDecimal percentFee) {
        this.percentFee = percentFee;
    }

    @Basic
    @Column(name = "click_fee", nullable = false, precision = 2)
    public BigDecimal getClickFee() {
        return clickFee;
    }

    public void setClickFee(BigDecimal clickFee) {
        this.clickFee = clickFee;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ReferrerEntity that = (ReferrerEntity) o;
        return idReferrer == that.idReferrer &&
                Objects.equals(name, that.name) &&
                Objects.equals(passwd, that.passwd) &&
                Objects.equals(httpRefererRegexp, that.httpRefererRegexp) &&
                Objects.equals(httpRefererLike, that.httpRefererLike) &&
                Objects.equals(requestUriRegexp, that.requestUriRegexp) &&
                Objects.equals(requestUriLike, that.requestUriLike) &&
                Objects.equals(httpRefererRegexpNot, that.httpRefererRegexpNot) &&
                Objects.equals(httpRefererLikeNot, that.httpRefererLikeNot) &&
                Objects.equals(requestUriRegexpNot, that.requestUriRegexpNot) &&
                Objects.equals(requestUriLikeNot, that.requestUriLikeNot) &&
                Objects.equals(baseFee, that.baseFee) &&
                Objects.equals(percentFee, that.percentFee) &&
                Objects.equals(clickFee, that.clickFee) &&
                Objects.equals(dateAdd, that.dateAdd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idReferrer, name, passwd, httpRefererRegexp, httpRefererLike, requestUriRegexp, requestUriLike, httpRefererRegexpNot, httpRefererLikeNot, requestUriRegexpNot, requestUriLikeNot, baseFee, percentFee, clickFee, dateAdd);
    }
}
