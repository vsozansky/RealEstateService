package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "cms_category_lang", schema = "ps1761", catalog = "")
@IdClass(CmsCategoryLangEntityPK.class)
public class CmsCategoryLangEntity {
    private int idCmsCategory;
    private int idLang;
    private int idShop;
    private String name;
    private String description;
    private String linkRewrite;
    private String metaTitle;
    private String metaKeywords;
    private String metaDescription;

    @Id
    @Column(name = "id_cms_category", nullable = false)
    public int getIdCmsCategory() {
        return idCmsCategory;
    }

    public void setIdCmsCategory(int idCmsCategory) {
        this.idCmsCategory = idCmsCategory;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 128)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "description", nullable = true, length = -1)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Basic
    @Column(name = "link_rewrite", nullable = false, length = 128)
    public String getLinkRewrite() {
        return linkRewrite;
    }

    public void setLinkRewrite(String linkRewrite) {
        this.linkRewrite = linkRewrite;
    }

    @Basic
    @Column(name = "meta_title", nullable = true, length = 255)
    public String getMetaTitle() {
        return metaTitle;
    }

    public void setMetaTitle(String metaTitle) {
        this.metaTitle = metaTitle;
    }

    @Basic
    @Column(name = "meta_keywords", nullable = true, length = 255)
    public String getMetaKeywords() {
        return metaKeywords;
    }

    public void setMetaKeywords(String metaKeywords) {
        this.metaKeywords = metaKeywords;
    }

    @Basic
    @Column(name = "meta_description", nullable = true, length = 512)
    public String getMetaDescription() {
        return metaDescription;
    }

    public void setMetaDescription(String metaDescription) {
        this.metaDescription = metaDescription;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CmsCategoryLangEntity that = (CmsCategoryLangEntity) o;
        return idCmsCategory == that.idCmsCategory &&
                idLang == that.idLang &&
                idShop == that.idShop &&
                Objects.equals(name, that.name) &&
                Objects.equals(description, that.description) &&
                Objects.equals(linkRewrite, that.linkRewrite) &&
                Objects.equals(metaTitle, that.metaTitle) &&
                Objects.equals(metaKeywords, that.metaKeywords) &&
                Objects.equals(metaDescription, that.metaDescription);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCmsCategory, idLang, idShop, name, description, linkRewrite, metaTitle, metaKeywords, metaDescription);
    }
}
