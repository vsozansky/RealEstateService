package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class CountryShopEntityPK implements Serializable {
    private int idCountry;
    private int idShop;

    @Column(name = "id_country", nullable = false)
    @Id
    public int getIdCountry() {
        return idCountry;
    }

    public void setIdCountry(int idCountry) {
        this.idCountry = idCountry;
    }

    @Column(name = "id_shop", nullable = false)
    @Id
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CountryShopEntityPK that = (CountryShopEntityPK) o;
        return idCountry == that.idCountry &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCountry, idShop);
    }
}
