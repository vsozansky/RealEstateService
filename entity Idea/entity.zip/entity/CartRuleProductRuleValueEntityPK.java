package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class CartRuleProductRuleValueEntityPK implements Serializable {
    private int idProductRule;
    private int idItem;

    @Column(name = "id_product_rule", nullable = false)
    @Id
    public int getIdProductRule() {
        return idProductRule;
    }

    public void setIdProductRule(int idProductRule) {
        this.idProductRule = idProductRule;
    }

    @Column(name = "id_item", nullable = false)
    @Id
    public int getIdItem() {
        return idItem;
    }

    public void setIdItem(int idItem) {
        this.idItem = idItem;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CartRuleProductRuleValueEntityPK that = (CartRuleProductRuleValueEntityPK) o;
        return idProductRule == that.idProductRule &&
                idItem == that.idItem;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProductRule, idItem);
    }
}
