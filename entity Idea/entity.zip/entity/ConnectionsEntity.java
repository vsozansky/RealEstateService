package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "connections", schema = "ps1761", catalog = "")
public class ConnectionsEntity {
    private int idConnections;
    private int idShopGroup;
    private int idShop;
    private int idGuest;
    private int idPage;
    private Long ipAddress;
    private Timestamp dateAdd;
    private String httpReferer;

    @Id
    @Column(name = "id_connections", nullable = false)
    public int getIdConnections() {
        return idConnections;
    }

    public void setIdConnections(int idConnections) {
        this.idConnections = idConnections;
    }

    @Basic
    @Column(name = "id_shop_group", nullable = false)
    public int getIdShopGroup() {
        return idShopGroup;
    }

    public void setIdShopGroup(int idShopGroup) {
        this.idShopGroup = idShopGroup;
    }

    @Basic
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "id_guest", nullable = false)
    public int getIdGuest() {
        return idGuest;
    }

    public void setIdGuest(int idGuest) {
        this.idGuest = idGuest;
    }

    @Basic
    @Column(name = "id_page", nullable = false)
    public int getIdPage() {
        return idPage;
    }

    public void setIdPage(int idPage) {
        this.idPage = idPage;
    }

    @Basic
    @Column(name = "ip_address", nullable = true)
    public Long getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(Long ipAddress) {
        this.ipAddress = ipAddress;
    }

    @Basic
    @Column(name = "date_add", nullable = false)
    public Timestamp getDateAdd() {
        return dateAdd;
    }

    public void setDateAdd(Timestamp dateAdd) {
        this.dateAdd = dateAdd;
    }

    @Basic
    @Column(name = "http_referer", nullable = true, length = 255)
    public String getHttpReferer() {
        return httpReferer;
    }

    public void setHttpReferer(String httpReferer) {
        this.httpReferer = httpReferer;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ConnectionsEntity that = (ConnectionsEntity) o;
        return idConnections == that.idConnections &&
                idShopGroup == that.idShopGroup &&
                idShop == that.idShop &&
                idGuest == that.idGuest &&
                idPage == that.idPage &&
                Objects.equals(ipAddress, that.ipAddress) &&
                Objects.equals(dateAdd, that.dateAdd) &&
                Objects.equals(httpReferer, that.httpReferer);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idConnections, idShopGroup, idShop, idGuest, idPage, ipAddress, dateAdd, httpReferer);
    }
}
