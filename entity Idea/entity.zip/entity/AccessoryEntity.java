package com.jprestashop.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Objects;

@Entity
@Table(name = "accessory", schema = "ps1761", catalog = "")
public class AccessoryEntity {
    private int idProduct1;
    private int idProduct2;

    @Basic
    @Column(name = "id_product_1", nullable = false)
    public int getIdProduct1() {
        return idProduct1;
    }

    public void setIdProduct1(int idProduct1) {
        this.idProduct1 = idProduct1;
    }

    @Basic
    @Column(name = "id_product_2", nullable = false)
    public int getIdProduct2() {
        return idProduct2;
    }

    public void setIdProduct2(int idProduct2) {
        this.idProduct2 = idProduct2;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AccessoryEntity that = (AccessoryEntity) o;
        return idProduct1 == that.idProduct1 &&
                idProduct2 == that.idProduct2;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProduct1, idProduct2);
    }
}
