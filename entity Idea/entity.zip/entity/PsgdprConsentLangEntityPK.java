package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class PsgdprConsentLangEntityPK implements Serializable {
    private int idGdprConsent;
    private int idLang;
    private int idShop;

    @Column(name = "id_gdpr_consent", nullable = false)
    @Id
    public int getIdGdprConsent() {
        return idGdprConsent;
    }

    public void setIdGdprConsent(int idGdprConsent) {
        this.idGdprConsent = idGdprConsent;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Column(name = "id_shop", nullable = false)
    @Id
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PsgdprConsentLangEntityPK that = (PsgdprConsentLangEntityPK) o;
        return idGdprConsent == that.idGdprConsent &&
                idLang == that.idLang &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idGdprConsent, idLang, idShop);
    }
}
