package com.jprestashop.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "emailsubscription", schema = "ps1761", catalog = "")
public class EmailsubscriptionEntity {
    private int id;
    private int idShop;
    private int idShopGroup;
    private String email;
    private Timestamp newsletterDateAdd;
    private String ipRegistrationNewsletter;
    private String httpReferer;
    private byte active;

    @Id
    @Column(name = "id", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "id_shop_group", nullable = false)
    public int getIdShopGroup() {
        return idShopGroup;
    }

    public void setIdShopGroup(int idShopGroup) {
        this.idShopGroup = idShopGroup;
    }

    @Basic
    @Column(name = "email", nullable = false, length = 255)
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Basic
    @Column(name = "newsletter_date_add", nullable = true)
    public Timestamp getNewsletterDateAdd() {
        return newsletterDateAdd;
    }

    public void setNewsletterDateAdd(Timestamp newsletterDateAdd) {
        this.newsletterDateAdd = newsletterDateAdd;
    }

    @Basic
    @Column(name = "ip_registration_newsletter", nullable = false, length = 15)
    public String getIpRegistrationNewsletter() {
        return ipRegistrationNewsletter;
    }

    public void setIpRegistrationNewsletter(String ipRegistrationNewsletter) {
        this.ipRegistrationNewsletter = ipRegistrationNewsletter;
    }

    @Basic
    @Column(name = "http_referer", nullable = true, length = 255)
    public String getHttpReferer() {
        return httpReferer;
    }

    public void setHttpReferer(String httpReferer) {
        this.httpReferer = httpReferer;
    }

    @Basic
    @Column(name = "active", nullable = false)
    public byte getActive() {
        return active;
    }

    public void setActive(byte active) {
        this.active = active;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EmailsubscriptionEntity that = (EmailsubscriptionEntity) o;
        return id == that.id &&
                idShop == that.idShop &&
                idShopGroup == that.idShopGroup &&
                active == that.active &&
                Objects.equals(email, that.email) &&
                Objects.equals(newsletterDateAdd, that.newsletterDateAdd) &&
                Objects.equals(ipRegistrationNewsletter, that.ipRegistrationNewsletter) &&
                Objects.equals(httpReferer, that.httpReferer);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, idShop, idShopGroup, email, newsletterDateAdd, ipRegistrationNewsletter, httpReferer, active);
    }
}
