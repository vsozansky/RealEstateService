package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "module_shop", schema = "ps1761", catalog = "")
@IdClass(ModuleShopEntityPK.class)
public class ModuleShopEntity {
    private int idModule;
    private int idShop;
    private byte enableDevice;

    @Id
    @Column(name = "id_module", nullable = false)
    public int getIdModule() {
        return idModule;
    }

    public void setIdModule(int idModule) {
        this.idModule = idModule;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "enable_device", nullable = false)
    public byte getEnableDevice() {
        return enableDevice;
    }

    public void setEnableDevice(byte enableDevice) {
        this.enableDevice = enableDevice;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ModuleShopEntity that = (ModuleShopEntity) o;
        return idModule == that.idModule &&
                idShop == that.idShop &&
                enableDevice == that.enableDevice;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idModule, idShop, enableDevice);
    }
}
