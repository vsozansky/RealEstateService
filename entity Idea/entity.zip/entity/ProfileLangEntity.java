package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "profile_lang", schema = "ps1761", catalog = "")
@IdClass(ProfileLangEntityPK.class)
public class ProfileLangEntity {
    private int idLang;
    private int idProfile;
    private String name;

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Id
    @Column(name = "id_profile", nullable = false)
    public int getIdProfile() {
        return idProfile;
    }

    public void setIdProfile(int idProfile) {
        this.idProfile = idProfile;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 128)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProfileLangEntity that = (ProfileLangEntity) o;
        return idLang == that.idLang &&
                idProfile == that.idProfile &&
                Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idLang, idProfile, name);
    }
}
