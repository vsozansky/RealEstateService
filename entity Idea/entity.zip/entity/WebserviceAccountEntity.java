package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "webservice_account", schema = "ps1761", catalog = "")
public class WebserviceAccountEntity {
    private int idWebserviceAccount;
    private String key;
    private String description;
    private String className;
    private byte isModule;
    private String moduleName;
    private byte active;

    @Id
    @Column(name = "id_webservice_account", nullable = false)
    public int getIdWebserviceAccount() {
        return idWebserviceAccount;
    }

    public void setIdWebserviceAccount(int idWebserviceAccount) {
        this.idWebserviceAccount = idWebserviceAccount;
    }

    @Basic
    @Column(name = "key", nullable = false, length = 32)
    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    @Basic
    @Column(name = "description", nullable = true, length = -1)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Basic
    @Column(name = "class_name", nullable = false, length = 50)
    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    @Basic
    @Column(name = "is_module", nullable = false)
    public byte getIsModule() {
        return isModule;
    }

    public void setIsModule(byte isModule) {
        this.isModule = isModule;
    }

    @Basic
    @Column(name = "module_name", nullable = true, length = 50)
    public String getModuleName() {
        return moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    @Basic
    @Column(name = "active", nullable = false)
    public byte getActive() {
        return active;
    }

    public void setActive(byte active) {
        this.active = active;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WebserviceAccountEntity that = (WebserviceAccountEntity) o;
        return idWebserviceAccount == that.idWebserviceAccount &&
                isModule == that.isModule &&
                active == that.active &&
                Objects.equals(key, that.key) &&
                Objects.equals(description, that.description) &&
                Objects.equals(className, that.className) &&
                Objects.equals(moduleName, that.moduleName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idWebserviceAccount, key, description, className, isModule, moduleName, active);
    }
}
