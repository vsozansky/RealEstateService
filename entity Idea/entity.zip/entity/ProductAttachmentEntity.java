package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "product_attachment", schema = "ps1761", catalog = "")
@IdClass(ProductAttachmentEntityPK.class)
public class ProductAttachmentEntity {
    private int idProduct;
    private int idAttachment;

    @Id
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Id
    @Column(name = "id_attachment", nullable = false)
    public int getIdAttachment() {
        return idAttachment;
    }

    public void setIdAttachment(int idAttachment) {
        this.idAttachment = idAttachment;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductAttachmentEntity that = (ProductAttachmentEntity) o;
        return idProduct == that.idProduct &&
                idAttachment == that.idAttachment;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProduct, idAttachment);
    }
}
