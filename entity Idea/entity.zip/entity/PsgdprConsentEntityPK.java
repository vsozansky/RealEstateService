package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class PsgdprConsentEntityPK implements Serializable {
    private int idGdprConsent;
    private int idModule;

    @Column(name = "id_gdpr_consent", nullable = false)
    @Id
    public int getIdGdprConsent() {
        return idGdprConsent;
    }

    public void setIdGdprConsent(int idGdprConsent) {
        this.idGdprConsent = idGdprConsent;
    }

    @Column(name = "id_module", nullable = false)
    @Id
    public int getIdModule() {
        return idModule;
    }

    public void setIdModule(int idModule) {
        this.idModule = idModule;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PsgdprConsentEntityPK that = (PsgdprConsentEntityPK) o;
        return idGdprConsent == that.idGdprConsent &&
                idModule == that.idModule;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idGdprConsent, idModule);
    }
}
