package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "quick_access", schema = "ps1761", catalog = "")
public class QuickAccessEntity {
    private int idQuickAccess;
    private byte newWindow;
    private String link;

    @Id
    @Column(name = "id_quick_access", nullable = false)
    public int getIdQuickAccess() {
        return idQuickAccess;
    }

    public void setIdQuickAccess(int idQuickAccess) {
        this.idQuickAccess = idQuickAccess;
    }

    @Basic
    @Column(name = "new_window", nullable = false)
    public byte getNewWindow() {
        return newWindow;
    }

    public void setNewWindow(byte newWindow) {
        this.newWindow = newWindow;
    }

    @Basic
    @Column(name = "link", nullable = false, length = 255)
    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        QuickAccessEntity that = (QuickAccessEntity) o;
        return idQuickAccess == that.idQuickAccess &&
                newWindow == that.newWindow &&
                Objects.equals(link, that.link);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idQuickAccess, newWindow, link);
    }
}
