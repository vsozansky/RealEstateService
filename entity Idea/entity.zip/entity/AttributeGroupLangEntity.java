package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "attribute_group_lang", schema = "ps1761", catalog = "")
@IdClass(AttributeGroupLangEntityPK.class)
public class AttributeGroupLangEntity {
    private int idAttributeGroup;
    private int idLang;
    private String name;
    private String publicName;

    @Id
    @Column(name = "id_attribute_group", nullable = false)
    public int getIdAttributeGroup() {
        return idAttributeGroup;
    }

    public void setIdAttributeGroup(int idAttributeGroup) {
        this.idAttributeGroup = idAttributeGroup;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 128)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "public_name", nullable = false, length = 64)
    public String getPublicName() {
        return publicName;
    }

    public void setPublicName(String publicName) {
        this.publicName = publicName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AttributeGroupLangEntity that = (AttributeGroupLangEntity) o;
        return idAttributeGroup == that.idAttributeGroup &&
                idLang == that.idLang &&
                Objects.equals(name, that.name) &&
                Objects.equals(publicName, that.publicName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAttributeGroup, idLang, name, publicName);
    }
}
