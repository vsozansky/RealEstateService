package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class BadgeLangEntityPK implements Serializable {
    private int idBadge;
    private int idLang;

    @Column(name = "id_badge", nullable = false)
    @Id
    public int getIdBadge() {
        return idBadge;
    }

    public void setIdBadge(int idBadge) {
        this.idBadge = idBadge;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BadgeLangEntityPK that = (BadgeLangEntityPK) o;
        return idBadge == that.idBadge &&
                idLang == that.idLang;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idBadge, idLang);
    }
}
