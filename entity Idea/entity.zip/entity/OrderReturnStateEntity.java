package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "order_return_state", schema = "ps1761", catalog = "")
public class OrderReturnStateEntity {
    private int idOrderReturnState;
    private String color;

    @Id
    @Column(name = "id_order_return_state", nullable = false)
    public int getIdOrderReturnState() {
        return idOrderReturnState;
    }

    public void setIdOrderReturnState(int idOrderReturnState) {
        this.idOrderReturnState = idOrderReturnState;
    }

    @Basic
    @Column(name = "color", nullable = true, length = 32)
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderReturnStateEntity that = (OrderReturnStateEntity) o;
        return idOrderReturnState == that.idOrderReturnState &&
                Objects.equals(color, that.color);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrderReturnState, color);
    }
}
