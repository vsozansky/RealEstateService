package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "order_detail", schema = "ps1761", catalog = "")
public class OrderDetailEntity {
    private int idOrderDetail;
    private int idOrder;
    private Integer idOrderInvoice;
    private Integer idWarehouse;
    private int idShop;
    private int productId;
    private Integer productAttributeId;
    private Integer idCustomization;
    private String productName;
    private int productQuantity;
    private int productQuantityInStock;
    private int productQuantityRefunded;
    private int productQuantityReturn;
    private int productQuantityReinjected;
    private BigDecimal productPrice;
    private BigDecimal reductionPercent;
    private BigDecimal reductionAmount;
    private BigDecimal reductionAmountTaxIncl;
    private BigDecimal reductionAmountTaxExcl;
    private BigDecimal groupReduction;
    private BigDecimal productQuantityDiscount;
    private String productEan13;
    private String productIsbn;
    private String productUpc;
    private String productReference;
    private String productSupplierReference;
    private BigDecimal productWeight;
    private Integer idTaxRulesGroup;
    private byte taxComputationMethod;
    private String taxName;
    private BigDecimal taxRate;
    private BigDecimal ecotax;
    private BigDecimal ecotaxTaxRate;
    private byte discountQuantityApplied;
    private String downloadHash;
    private Integer downloadNb;
    private Timestamp downloadDeadline;
    private BigDecimal totalPriceTaxIncl;
    private BigDecimal totalPriceTaxExcl;
    private BigDecimal unitPriceTaxIncl;
    private BigDecimal unitPriceTaxExcl;
    private BigDecimal totalShippingPriceTaxIncl;
    private BigDecimal totalShippingPriceTaxExcl;
    private BigDecimal purchaseSupplierPrice;
    private BigDecimal originalProductPrice;
    private BigDecimal originalWholesalePrice;

    @Id
    @Column(name = "id_order_detail", nullable = false)
    public int getIdOrderDetail() {
        return idOrderDetail;
    }

    public void setIdOrderDetail(int idOrderDetail) {
        this.idOrderDetail = idOrderDetail;
    }

    @Basic
    @Column(name = "id_order", nullable = false)
    public int getIdOrder() {
        return idOrder;
    }

    public void setIdOrder(int idOrder) {
        this.idOrder = idOrder;
    }

    @Basic
    @Column(name = "id_order_invoice", nullable = true)
    public Integer getIdOrderInvoice() {
        return idOrderInvoice;
    }

    public void setIdOrderInvoice(Integer idOrderInvoice) {
        this.idOrderInvoice = idOrderInvoice;
    }

    @Basic
    @Column(name = "id_warehouse", nullable = true)
    public Integer getIdWarehouse() {
        return idWarehouse;
    }

    public void setIdWarehouse(Integer idWarehouse) {
        this.idWarehouse = idWarehouse;
    }

    @Basic
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "product_id", nullable = false)
    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    @Basic
    @Column(name = "product_attribute_id", nullable = true)
    public Integer getProductAttributeId() {
        return productAttributeId;
    }

    public void setProductAttributeId(Integer productAttributeId) {
        this.productAttributeId = productAttributeId;
    }

    @Basic
    @Column(name = "id_customization", nullable = true)
    public Integer getIdCustomization() {
        return idCustomization;
    }

    public void setIdCustomization(Integer idCustomization) {
        this.idCustomization = idCustomization;
    }

    @Basic
    @Column(name = "product_name", nullable = false, length = 255)
    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    @Basic
    @Column(name = "product_quantity", nullable = false)
    public int getProductQuantity() {
        return productQuantity;
    }

    public void setProductQuantity(int productQuantity) {
        this.productQuantity = productQuantity;
    }

    @Basic
    @Column(name = "product_quantity_in_stock", nullable = false)
    public int getProductQuantityInStock() {
        return productQuantityInStock;
    }

    public void setProductQuantityInStock(int productQuantityInStock) {
        this.productQuantityInStock = productQuantityInStock;
    }

    @Basic
    @Column(name = "product_quantity_refunded", nullable = false)
    public int getProductQuantityRefunded() {
        return productQuantityRefunded;
    }

    public void setProductQuantityRefunded(int productQuantityRefunded) {
        this.productQuantityRefunded = productQuantityRefunded;
    }

    @Basic
    @Column(name = "product_quantity_return", nullable = false)
    public int getProductQuantityReturn() {
        return productQuantityReturn;
    }

    public void setProductQuantityReturn(int productQuantityReturn) {
        this.productQuantityReturn = productQuantityReturn;
    }

    @Basic
    @Column(name = "product_quantity_reinjected", nullable = false)
    public int getProductQuantityReinjected() {
        return productQuantityReinjected;
    }

    public void setProductQuantityReinjected(int productQuantityReinjected) {
        this.productQuantityReinjected = productQuantityReinjected;
    }

    @Basic
    @Column(name = "product_price", nullable = false, precision = 6)
    public BigDecimal getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(BigDecimal productPrice) {
        this.productPrice = productPrice;
    }

    @Basic
    @Column(name = "reduction_percent", nullable = false, precision = 2)
    public BigDecimal getReductionPercent() {
        return reductionPercent;
    }

    public void setReductionPercent(BigDecimal reductionPercent) {
        this.reductionPercent = reductionPercent;
    }

    @Basic
    @Column(name = "reduction_amount", nullable = false, precision = 6)
    public BigDecimal getReductionAmount() {
        return reductionAmount;
    }

    public void setReductionAmount(BigDecimal reductionAmount) {
        this.reductionAmount = reductionAmount;
    }

    @Basic
    @Column(name = "reduction_amount_tax_incl", nullable = false, precision = 6)
    public BigDecimal getReductionAmountTaxIncl() {
        return reductionAmountTaxIncl;
    }

    public void setReductionAmountTaxIncl(BigDecimal reductionAmountTaxIncl) {
        this.reductionAmountTaxIncl = reductionAmountTaxIncl;
    }

    @Basic
    @Column(name = "reduction_amount_tax_excl", nullable = false, precision = 6)
    public BigDecimal getReductionAmountTaxExcl() {
        return reductionAmountTaxExcl;
    }

    public void setReductionAmountTaxExcl(BigDecimal reductionAmountTaxExcl) {
        this.reductionAmountTaxExcl = reductionAmountTaxExcl;
    }

    @Basic
    @Column(name = "group_reduction", nullable = false, precision = 2)
    public BigDecimal getGroupReduction() {
        return groupReduction;
    }

    public void setGroupReduction(BigDecimal groupReduction) {
        this.groupReduction = groupReduction;
    }

    @Basic
    @Column(name = "product_quantity_discount", nullable = false, precision = 6)
    public BigDecimal getProductQuantityDiscount() {
        return productQuantityDiscount;
    }

    public void setProductQuantityDiscount(BigDecimal productQuantityDiscount) {
        this.productQuantityDiscount = productQuantityDiscount;
    }

    @Basic
    @Column(name = "product_ean13", nullable = true, length = 13)
    public String getProductEan13() {
        return productEan13;
    }

    public void setProductEan13(String productEan13) {
        this.productEan13 = productEan13;
    }

    @Basic
    @Column(name = "product_isbn", nullable = true, length = 32)
    public String getProductIsbn() {
        return productIsbn;
    }

    public void setProductIsbn(String productIsbn) {
        this.productIsbn = productIsbn;
    }

    @Basic
    @Column(name = "product_upc", nullable = true, length = 12)
    public String getProductUpc() {
        return productUpc;
    }

    public void setProductUpc(String productUpc) {
        this.productUpc = productUpc;
    }

    @Basic
    @Column(name = "product_reference", nullable = true, length = 64)
    public String getProductReference() {
        return productReference;
    }

    public void setProductReference(String productReference) {
        this.productReference = productReference;
    }

    @Basic
    @Column(name = "product_supplier_reference", nullable = true, length = 64)
    public String getProductSupplierReference() {
        return productSupplierReference;
    }

    public void setProductSupplierReference(String productSupplierReference) {
        this.productSupplierReference = productSupplierReference;
    }

    @Basic
    @Column(name = "product_weight", nullable = false, precision = 6)
    public BigDecimal getProductWeight() {
        return productWeight;
    }

    public void setProductWeight(BigDecimal productWeight) {
        this.productWeight = productWeight;
    }

    @Basic
    @Column(name = "id_tax_rules_group", nullable = true)
    public Integer getIdTaxRulesGroup() {
        return idTaxRulesGroup;
    }

    public void setIdTaxRulesGroup(Integer idTaxRulesGroup) {
        this.idTaxRulesGroup = idTaxRulesGroup;
    }

    @Basic
    @Column(name = "tax_computation_method", nullable = false)
    public byte getTaxComputationMethod() {
        return taxComputationMethod;
    }

    public void setTaxComputationMethod(byte taxComputationMethod) {
        this.taxComputationMethod = taxComputationMethod;
    }

    @Basic
    @Column(name = "tax_name", nullable = false, length = 16)
    public String getTaxName() {
        return taxName;
    }

    public void setTaxName(String taxName) {
        this.taxName = taxName;
    }

    @Basic
    @Column(name = "tax_rate", nullable = false, precision = 3)
    public BigDecimal getTaxRate() {
        return taxRate;
    }

    public void setTaxRate(BigDecimal taxRate) {
        this.taxRate = taxRate;
    }

    @Basic
    @Column(name = "ecotax", nullable = false, precision = 6)
    public BigDecimal getEcotax() {
        return ecotax;
    }

    public void setEcotax(BigDecimal ecotax) {
        this.ecotax = ecotax;
    }

    @Basic
    @Column(name = "ecotax_tax_rate", nullable = false, precision = 3)
    public BigDecimal getEcotaxTaxRate() {
        return ecotaxTaxRate;
    }

    public void setEcotaxTaxRate(BigDecimal ecotaxTaxRate) {
        this.ecotaxTaxRate = ecotaxTaxRate;
    }

    @Basic
    @Column(name = "discount_quantity_applied", nullable = false)
    public byte getDiscountQuantityApplied() {
        return discountQuantityApplied;
    }

    public void setDiscountQuantityApplied(byte discountQuantityApplied) {
        this.discountQuantityApplied = discountQuantityApplied;
    }

    @Basic
    @Column(name = "download_hash", nullable = true, length = 255)
    public String getDownloadHash() {
        return downloadHash;
    }

    public void setDownloadHash(String downloadHash) {
        this.downloadHash = downloadHash;
    }

    @Basic
    @Column(name = "download_nb", nullable = true)
    public Integer getDownloadNb() {
        return downloadNb;
    }

    public void setDownloadNb(Integer downloadNb) {
        this.downloadNb = downloadNb;
    }

    @Basic
    @Column(name = "download_deadline", nullable = true)
    public Timestamp getDownloadDeadline() {
        return downloadDeadline;
    }

    public void setDownloadDeadline(Timestamp downloadDeadline) {
        this.downloadDeadline = downloadDeadline;
    }

    @Basic
    @Column(name = "total_price_tax_incl", nullable = false, precision = 6)
    public BigDecimal getTotalPriceTaxIncl() {
        return totalPriceTaxIncl;
    }

    public void setTotalPriceTaxIncl(BigDecimal totalPriceTaxIncl) {
        this.totalPriceTaxIncl = totalPriceTaxIncl;
    }

    @Basic
    @Column(name = "total_price_tax_excl", nullable = false, precision = 6)
    public BigDecimal getTotalPriceTaxExcl() {
        return totalPriceTaxExcl;
    }

    public void setTotalPriceTaxExcl(BigDecimal totalPriceTaxExcl) {
        this.totalPriceTaxExcl = totalPriceTaxExcl;
    }

    @Basic
    @Column(name = "unit_price_tax_incl", nullable = false, precision = 6)
    public BigDecimal getUnitPriceTaxIncl() {
        return unitPriceTaxIncl;
    }

    public void setUnitPriceTaxIncl(BigDecimal unitPriceTaxIncl) {
        this.unitPriceTaxIncl = unitPriceTaxIncl;
    }

    @Basic
    @Column(name = "unit_price_tax_excl", nullable = false, precision = 6)
    public BigDecimal getUnitPriceTaxExcl() {
        return unitPriceTaxExcl;
    }

    public void setUnitPriceTaxExcl(BigDecimal unitPriceTaxExcl) {
        this.unitPriceTaxExcl = unitPriceTaxExcl;
    }

    @Basic
    @Column(name = "total_shipping_price_tax_incl", nullable = false, precision = 6)
    public BigDecimal getTotalShippingPriceTaxIncl() {
        return totalShippingPriceTaxIncl;
    }

    public void setTotalShippingPriceTaxIncl(BigDecimal totalShippingPriceTaxIncl) {
        this.totalShippingPriceTaxIncl = totalShippingPriceTaxIncl;
    }

    @Basic
    @Column(name = "total_shipping_price_tax_excl", nullable = false, precision = 6)
    public BigDecimal getTotalShippingPriceTaxExcl() {
        return totalShippingPriceTaxExcl;
    }

    public void setTotalShippingPriceTaxExcl(BigDecimal totalShippingPriceTaxExcl) {
        this.totalShippingPriceTaxExcl = totalShippingPriceTaxExcl;
    }

    @Basic
    @Column(name = "purchase_supplier_price", nullable = false, precision = 6)
    public BigDecimal getPurchaseSupplierPrice() {
        return purchaseSupplierPrice;
    }

    public void setPurchaseSupplierPrice(BigDecimal purchaseSupplierPrice) {
        this.purchaseSupplierPrice = purchaseSupplierPrice;
    }

    @Basic
    @Column(name = "original_product_price", nullable = false, precision = 6)
    public BigDecimal getOriginalProductPrice() {
        return originalProductPrice;
    }

    public void setOriginalProductPrice(BigDecimal originalProductPrice) {
        this.originalProductPrice = originalProductPrice;
    }

    @Basic
    @Column(name = "original_wholesale_price", nullable = false, precision = 6)
    public BigDecimal getOriginalWholesalePrice() {
        return originalWholesalePrice;
    }

    public void setOriginalWholesalePrice(BigDecimal originalWholesalePrice) {
        this.originalWholesalePrice = originalWholesalePrice;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderDetailEntity that = (OrderDetailEntity) o;
        return idOrderDetail == that.idOrderDetail &&
                idOrder == that.idOrder &&
                idShop == that.idShop &&
                productId == that.productId &&
                productQuantity == that.productQuantity &&
                productQuantityInStock == that.productQuantityInStock &&
                productQuantityRefunded == that.productQuantityRefunded &&
                productQuantityReturn == that.productQuantityReturn &&
                productQuantityReinjected == that.productQuantityReinjected &&
                taxComputationMethod == that.taxComputationMethod &&
                discountQuantityApplied == that.discountQuantityApplied &&
                Objects.equals(idOrderInvoice, that.idOrderInvoice) &&
                Objects.equals(idWarehouse, that.idWarehouse) &&
                Objects.equals(productAttributeId, that.productAttributeId) &&
                Objects.equals(idCustomization, that.idCustomization) &&
                Objects.equals(productName, that.productName) &&
                Objects.equals(productPrice, that.productPrice) &&
                Objects.equals(reductionPercent, that.reductionPercent) &&
                Objects.equals(reductionAmount, that.reductionAmount) &&
                Objects.equals(reductionAmountTaxIncl, that.reductionAmountTaxIncl) &&
                Objects.equals(reductionAmountTaxExcl, that.reductionAmountTaxExcl) &&
                Objects.equals(groupReduction, that.groupReduction) &&
                Objects.equals(productQuantityDiscount, that.productQuantityDiscount) &&
                Objects.equals(productEan13, that.productEan13) &&
                Objects.equals(productIsbn, that.productIsbn) &&
                Objects.equals(productUpc, that.productUpc) &&
                Objects.equals(productReference, that.productReference) &&
                Objects.equals(productSupplierReference, that.productSupplierReference) &&
                Objects.equals(productWeight, that.productWeight) &&
                Objects.equals(idTaxRulesGroup, that.idTaxRulesGroup) &&
                Objects.equals(taxName, that.taxName) &&
                Objects.equals(taxRate, that.taxRate) &&
                Objects.equals(ecotax, that.ecotax) &&
                Objects.equals(ecotaxTaxRate, that.ecotaxTaxRate) &&
                Objects.equals(downloadHash, that.downloadHash) &&
                Objects.equals(downloadNb, that.downloadNb) &&
                Objects.equals(downloadDeadline, that.downloadDeadline) &&
                Objects.equals(totalPriceTaxIncl, that.totalPriceTaxIncl) &&
                Objects.equals(totalPriceTaxExcl, that.totalPriceTaxExcl) &&
                Objects.equals(unitPriceTaxIncl, that.unitPriceTaxIncl) &&
                Objects.equals(unitPriceTaxExcl, that.unitPriceTaxExcl) &&
                Objects.equals(totalShippingPriceTaxIncl, that.totalShippingPriceTaxIncl) &&
                Objects.equals(totalShippingPriceTaxExcl, that.totalShippingPriceTaxExcl) &&
                Objects.equals(purchaseSupplierPrice, that.purchaseSupplierPrice) &&
                Objects.equals(originalProductPrice, that.originalProductPrice) &&
                Objects.equals(originalWholesalePrice, that.originalWholesalePrice);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrderDetail, idOrder, idOrderInvoice, idWarehouse, idShop, productId, productAttributeId, idCustomization, productName, productQuantity, productQuantityInStock, productQuantityRefunded, productQuantityReturn, productQuantityReinjected, productPrice, reductionPercent, reductionAmount, reductionAmountTaxIncl, reductionAmountTaxExcl, groupReduction, productQuantityDiscount, productEan13, productIsbn, productUpc, productReference, productSupplierReference, productWeight, idTaxRulesGroup, taxComputationMethod, taxName, taxRate, ecotax, ecotaxTaxRate, discountQuantityApplied, downloadHash, downloadNb, downloadDeadline, totalPriceTaxIncl, totalPriceTaxExcl, unitPriceTaxIncl, unitPriceTaxExcl, totalShippingPriceTaxIncl, totalShippingPriceTaxExcl, purchaseSupplierPrice, originalProductPrice, originalWholesalePrice);
    }
}
