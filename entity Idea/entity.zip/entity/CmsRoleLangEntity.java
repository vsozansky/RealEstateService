package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "cms_role_lang", schema = "ps1761", catalog = "")
@IdClass(CmsRoleLangEntityPK.class)
public class CmsRoleLangEntity {
    private int idCmsRole;
    private int idLang;
    private int idShop;
    private String name;

    @Id
    @Column(name = "id_cms_role", nullable = false)
    public int getIdCmsRole() {
        return idCmsRole;
    }

    public void setIdCmsRole(int idCmsRole) {
        this.idCmsRole = idCmsRole;
    }

    @Id
    @Column(name = "id_lang", nullable = false)
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Basic
    @Column(name = "name", nullable = true, length = 128)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CmsRoleLangEntity that = (CmsRoleLangEntity) o;
        return idCmsRole == that.idCmsRole &&
                idLang == that.idLang &&
                idShop == that.idShop &&
                Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCmsRole, idLang, idShop, name);
    }
}
