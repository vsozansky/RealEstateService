package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "web_browser", schema = "ps1761", catalog = "")
public class WebBrowserEntity {
    private int idWebBrowser;
    private String name;

    @Id
    @Column(name = "id_web_browser", nullable = false)
    public int getIdWebBrowser() {
        return idWebBrowser;
    }

    public void setIdWebBrowser(int idWebBrowser) {
        this.idWebBrowser = idWebBrowser;
    }

    @Basic
    @Column(name = "name", nullable = true, length = 64)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WebBrowserEntity that = (WebBrowserEntity) o;
        return idWebBrowser == that.idWebBrowser &&
                Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idWebBrowser, name);
    }
}
