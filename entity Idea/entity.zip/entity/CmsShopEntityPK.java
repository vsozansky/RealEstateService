package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class CmsShopEntityPK implements Serializable {
    private int idCms;
    private int idShop;

    @Column(name = "id_cms", nullable = false)
    @Id
    public int getIdCms() {
        return idCms;
    }

    public void setIdCms(int idCms) {
        this.idCms = idCms;
    }

    @Column(name = "id_shop", nullable = false)
    @Id
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CmsShopEntityPK that = (CmsShopEntityPK) o;
        return idCms == that.idCms &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCms, idShop);
    }
}
