package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "page_viewed", schema = "ps1761", catalog = "")
@IdClass(PageViewedEntityPK.class)
public class PageViewedEntity {
    private int idPage;
    private int idShopGroup;
    private int idShop;
    private int idDateRange;
    private int counter;

    @Id
    @Column(name = "id_page", nullable = false)
    public int getIdPage() {
        return idPage;
    }

    public void setIdPage(int idPage) {
        this.idPage = idPage;
    }

    @Basic
    @Column(name = "id_shop_group", nullable = false)
    public int getIdShopGroup() {
        return idShopGroup;
    }

    public void setIdShopGroup(int idShopGroup) {
        this.idShopGroup = idShopGroup;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Id
    @Column(name = "id_date_range", nullable = false)
    public int getIdDateRange() {
        return idDateRange;
    }

    public void setIdDateRange(int idDateRange) {
        this.idDateRange = idDateRange;
    }

    @Basic
    @Column(name = "counter", nullable = false)
    public int getCounter() {
        return counter;
    }

    public void setCounter(int counter) {
        this.counter = counter;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PageViewedEntity that = (PageViewedEntity) o;
        return idPage == that.idPage &&
                idShopGroup == that.idShopGroup &&
                idShop == that.idShop &&
                idDateRange == that.idDateRange &&
                counter == that.counter;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPage, idShopGroup, idShop, idDateRange, counter);
    }
}
