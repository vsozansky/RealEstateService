package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "attribute_group_shop", schema = "ps1761", catalog = "")
@IdClass(AttributeGroupShopEntityPK.class)
public class AttributeGroupShopEntity {
    private int idAttributeGroup;
    private int idShop;

    @Id
    @Column(name = "id_attribute_group", nullable = false)
    public int getIdAttributeGroup() {
        return idAttributeGroup;
    }

    public void setIdAttributeGroup(int idAttributeGroup) {
        this.idAttributeGroup = idAttributeGroup;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AttributeGroupShopEntity that = (AttributeGroupShopEntity) o;
        return idAttributeGroup == that.idAttributeGroup &&
                idShop == that.idShop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAttributeGroup, idShop);
    }
}
