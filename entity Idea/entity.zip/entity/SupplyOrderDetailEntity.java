package com.jprestashop.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name = "supply_order_detail", schema = "ps1761", catalog = "")
public class SupplyOrderDetailEntity {
    private int idSupplyOrderDetail;
    private int idSupplyOrder;
    private int idCurrency;
    private int idProduct;
    private int idProductAttribute;
    private String reference;
    private String supplierReference;
    private String name;
    private String ean13;
    private String isbn;
    private String upc;
    private BigDecimal exchangeRate;
    private BigDecimal unitPriceTe;
    private int quantityExpected;
    private int quantityReceived;
    private BigDecimal priceTe;
    private BigDecimal discountRate;
    private BigDecimal discountValueTe;
    private BigDecimal priceWithDiscountTe;
    private BigDecimal taxRate;
    private BigDecimal taxValue;
    private BigDecimal priceTi;
    private BigDecimal taxValueWithOrderDiscount;
    private BigDecimal priceWithOrderDiscountTe;

    @Id
    @Column(name = "id_supply_order_detail", nullable = false)
    public int getIdSupplyOrderDetail() {
        return idSupplyOrderDetail;
    }

    public void setIdSupplyOrderDetail(int idSupplyOrderDetail) {
        this.idSupplyOrderDetail = idSupplyOrderDetail;
    }

    @Basic
    @Column(name = "id_supply_order", nullable = false)
    public int getIdSupplyOrder() {
        return idSupplyOrder;
    }

    public void setIdSupplyOrder(int idSupplyOrder) {
        this.idSupplyOrder = idSupplyOrder;
    }

    @Basic
    @Column(name = "id_currency", nullable = false)
    public int getIdCurrency() {
        return idCurrency;
    }

    public void setIdCurrency(int idCurrency) {
        this.idCurrency = idCurrency;
    }

    @Basic
    @Column(name = "id_product", nullable = false)
    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Basic
    @Column(name = "id_product_attribute", nullable = false)
    public int getIdProductAttribute() {
        return idProductAttribute;
    }

    public void setIdProductAttribute(int idProductAttribute) {
        this.idProductAttribute = idProductAttribute;
    }

    @Basic
    @Column(name = "reference", nullable = false, length = 64)
    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    @Basic
    @Column(name = "supplier_reference", nullable = false, length = 64)
    public String getSupplierReference() {
        return supplierReference;
    }

    public void setSupplierReference(String supplierReference) {
        this.supplierReference = supplierReference;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 128)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "ean13", nullable = true, length = 13)
    public String getEan13() {
        return ean13;
    }

    public void setEan13(String ean13) {
        this.ean13 = ean13;
    }

    @Basic
    @Column(name = "isbn", nullable = true, length = 32)
    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    @Basic
    @Column(name = "upc", nullable = true, length = 12)
    public String getUpc() {
        return upc;
    }

    public void setUpc(String upc) {
        this.upc = upc;
    }

    @Basic
    @Column(name = "exchange_rate", nullable = true, precision = 6)
    public BigDecimal getExchangeRate() {
        return exchangeRate;
    }

    public void setExchangeRate(BigDecimal exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    @Basic
    @Column(name = "unit_price_te", nullable = true, precision = 6)
    public BigDecimal getUnitPriceTe() {
        return unitPriceTe;
    }

    public void setUnitPriceTe(BigDecimal unitPriceTe) {
        this.unitPriceTe = unitPriceTe;
    }

    @Basic
    @Column(name = "quantity_expected", nullable = false)
    public int getQuantityExpected() {
        return quantityExpected;
    }

    public void setQuantityExpected(int quantityExpected) {
        this.quantityExpected = quantityExpected;
    }

    @Basic
    @Column(name = "quantity_received", nullable = false)
    public int getQuantityReceived() {
        return quantityReceived;
    }

    public void setQuantityReceived(int quantityReceived) {
        this.quantityReceived = quantityReceived;
    }

    @Basic
    @Column(name = "price_te", nullable = true, precision = 6)
    public BigDecimal getPriceTe() {
        return priceTe;
    }

    public void setPriceTe(BigDecimal priceTe) {
        this.priceTe = priceTe;
    }

    @Basic
    @Column(name = "discount_rate", nullable = true, precision = 6)
    public BigDecimal getDiscountRate() {
        return discountRate;
    }

    public void setDiscountRate(BigDecimal discountRate) {
        this.discountRate = discountRate;
    }

    @Basic
    @Column(name = "discount_value_te", nullable = true, precision = 6)
    public BigDecimal getDiscountValueTe() {
        return discountValueTe;
    }

    public void setDiscountValueTe(BigDecimal discountValueTe) {
        this.discountValueTe = discountValueTe;
    }

    @Basic
    @Column(name = "price_with_discount_te", nullable = true, precision = 6)
    public BigDecimal getPriceWithDiscountTe() {
        return priceWithDiscountTe;
    }

    public void setPriceWithDiscountTe(BigDecimal priceWithDiscountTe) {
        this.priceWithDiscountTe = priceWithDiscountTe;
    }

    @Basic
    @Column(name = "tax_rate", nullable = true, precision = 6)
    public BigDecimal getTaxRate() {
        return taxRate;
    }

    public void setTaxRate(BigDecimal taxRate) {
        this.taxRate = taxRate;
    }

    @Basic
    @Column(name = "tax_value", nullable = true, precision = 6)
    public BigDecimal getTaxValue() {
        return taxValue;
    }

    public void setTaxValue(BigDecimal taxValue) {
        this.taxValue = taxValue;
    }

    @Basic
    @Column(name = "price_ti", nullable = true, precision = 6)
    public BigDecimal getPriceTi() {
        return priceTi;
    }

    public void setPriceTi(BigDecimal priceTi) {
        this.priceTi = priceTi;
    }

    @Basic
    @Column(name = "tax_value_with_order_discount", nullable = true, precision = 6)
    public BigDecimal getTaxValueWithOrderDiscount() {
        return taxValueWithOrderDiscount;
    }

    public void setTaxValueWithOrderDiscount(BigDecimal taxValueWithOrderDiscount) {
        this.taxValueWithOrderDiscount = taxValueWithOrderDiscount;
    }

    @Basic
    @Column(name = "price_with_order_discount_te", nullable = true, precision = 6)
    public BigDecimal getPriceWithOrderDiscountTe() {
        return priceWithOrderDiscountTe;
    }

    public void setPriceWithOrderDiscountTe(BigDecimal priceWithOrderDiscountTe) {
        this.priceWithOrderDiscountTe = priceWithOrderDiscountTe;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SupplyOrderDetailEntity that = (SupplyOrderDetailEntity) o;
        return idSupplyOrderDetail == that.idSupplyOrderDetail &&
                idSupplyOrder == that.idSupplyOrder &&
                idCurrency == that.idCurrency &&
                idProduct == that.idProduct &&
                idProductAttribute == that.idProductAttribute &&
                quantityExpected == that.quantityExpected &&
                quantityReceived == that.quantityReceived &&
                Objects.equals(reference, that.reference) &&
                Objects.equals(supplierReference, that.supplierReference) &&
                Objects.equals(name, that.name) &&
                Objects.equals(ean13, that.ean13) &&
                Objects.equals(isbn, that.isbn) &&
                Objects.equals(upc, that.upc) &&
                Objects.equals(exchangeRate, that.exchangeRate) &&
                Objects.equals(unitPriceTe, that.unitPriceTe) &&
                Objects.equals(priceTe, that.priceTe) &&
                Objects.equals(discountRate, that.discountRate) &&
                Objects.equals(discountValueTe, that.discountValueTe) &&
                Objects.equals(priceWithDiscountTe, that.priceWithDiscountTe) &&
                Objects.equals(taxRate, that.taxRate) &&
                Objects.equals(taxValue, that.taxValue) &&
                Objects.equals(priceTi, that.priceTi) &&
                Objects.equals(taxValueWithOrderDiscount, that.taxValueWithOrderDiscount) &&
                Objects.equals(priceWithOrderDiscountTe, that.priceWithOrderDiscountTe);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idSupplyOrderDetail, idSupplyOrder, idCurrency, idProduct, idProductAttribute, reference, supplierReference, name, ean13, isbn, upc, exchangeRate, unitPriceTe, quantityExpected, quantityReceived, priceTe, discountRate, discountValueTe, priceWithDiscountTe, taxRate, taxValue, priceTi, taxValueWithOrderDiscount, priceWithOrderDiscountTe);
    }
}
