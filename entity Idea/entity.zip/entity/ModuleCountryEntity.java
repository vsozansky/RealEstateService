package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "module_country", schema = "ps1761", catalog = "")
@IdClass(ModuleCountryEntityPK.class)
public class ModuleCountryEntity {
    private int idModule;
    private int idShop;
    private int idCountry;

    @Id
    @Column(name = "id_module", nullable = false)
    public int getIdModule() {
        return idModule;
    }

    public void setIdModule(int idModule) {
        this.idModule = idModule;
    }

    @Id
    @Column(name = "id_shop", nullable = false)
    public int getIdShop() {
        return idShop;
    }

    public void setIdShop(int idShop) {
        this.idShop = idShop;
    }

    @Id
    @Column(name = "id_country", nullable = false)
    public int getIdCountry() {
        return idCountry;
    }

    public void setIdCountry(int idCountry) {
        this.idCountry = idCountry;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ModuleCountryEntity that = (ModuleCountryEntity) o;
        return idModule == that.idModule &&
                idShop == that.idShop &&
                idCountry == that.idCountry;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idModule, idShop, idCountry);
    }
}
