package com.jprestashop.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "specific_price_rule_condition", schema = "ps1761", catalog = "")
public class SpecificPriceRuleConditionEntity {
    private int idSpecificPriceRuleCondition;
    private int idSpecificPriceRuleConditionGroup;
    private String type;
    private String value;

    @Id
    @Column(name = "id_specific_price_rule_condition", nullable = false)
    public int getIdSpecificPriceRuleCondition() {
        return idSpecificPriceRuleCondition;
    }

    public void setIdSpecificPriceRuleCondition(int idSpecificPriceRuleCondition) {
        this.idSpecificPriceRuleCondition = idSpecificPriceRuleCondition;
    }

    @Basic
    @Column(name = "id_specific_price_rule_condition_group", nullable = false)
    public int getIdSpecificPriceRuleConditionGroup() {
        return idSpecificPriceRuleConditionGroup;
    }

    public void setIdSpecificPriceRuleConditionGroup(int idSpecificPriceRuleConditionGroup) {
        this.idSpecificPriceRuleConditionGroup = idSpecificPriceRuleConditionGroup;
    }

    @Basic
    @Column(name = "type", nullable = false, length = 255)
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Basic
    @Column(name = "value", nullable = false, length = 255)
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SpecificPriceRuleConditionEntity that = (SpecificPriceRuleConditionEntity) o;
        return idSpecificPriceRuleCondition == that.idSpecificPriceRuleCondition &&
                idSpecificPriceRuleConditionGroup == that.idSpecificPriceRuleConditionGroup &&
                Objects.equals(type, that.type) &&
                Objects.equals(value, that.value);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idSpecificPriceRuleCondition, idSpecificPriceRuleConditionGroup, type, value);
    }
}
