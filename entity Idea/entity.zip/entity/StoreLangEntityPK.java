package com.jprestashop.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class StoreLangEntityPK implements Serializable {
    private int idStore;
    private int idLang;

    @Column(name = "id_store", nullable = false)
    @Id
    public int getIdStore() {
        return idStore;
    }

    public void setIdStore(int idStore) {
        this.idStore = idStore;
    }

    @Column(name = "id_lang", nullable = false)
    @Id
    public int getIdLang() {
        return idLang;
    }

    public void setIdLang(int idLang) {
        this.idLang = idLang;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StoreLangEntityPK that = (StoreLangEntityPK) o;
        return idStore == that.idStore &&
                idLang == that.idLang;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idStore, idLang);
    }
}
