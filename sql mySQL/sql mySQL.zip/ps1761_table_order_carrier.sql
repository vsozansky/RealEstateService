
CREATE TABLE `order_carrier` (
  `id_order_carrier` int(11) NOT NULL,
  `id_order` int(11) UNSIGNED NOT NULL,
  `id_carrier` int(11) UNSIGNED NOT NULL,
  `id_order_invoice` int(11) UNSIGNED DEFAULT NULL,
  `weight` decimal(20,6) DEFAULT NULL,
  `shipping_cost_tax_excl` decimal(20,6) DEFAULT NULL,
  `shipping_cost_tax_incl` decimal(20,6) DEFAULT NULL,
  `tracking_number` varchar(64) DEFAULT NULL,
  `date_add` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `order_carrier` (`id_order_carrier`, `id_order`, `id_carrier`, `id_order_invoice`, `weight`, `shipping_cost_tax_excl`, `shipping_cost_tax_incl`, `tracking_number`, `date_add`) VALUES
(1, 1, 2, 0, '0.000000', '2.000000', '2.000000', '', '2020-03-03 09:26:04'),
(2, 2, 2, 0, '0.000000', '2.000000', '2.000000', '', '2020-03-03 09:26:04'),
(3, 3, 2, 0, '0.000000', '2.000000', '2.000000', '', '2020-03-03 09:26:04'),
(4, 4, 2, 0, '0.000000', '2.000000', '2.000000', '', '2020-03-03 09:26:04'),
(5, 5, 2, 0, '0.000000', '2.000000', '2.000000', '', '2020-03-03 09:26:04');
