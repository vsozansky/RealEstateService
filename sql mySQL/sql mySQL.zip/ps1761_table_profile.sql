
CREATE TABLE `profile` (
  `id_profile` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `profile` (`id_profile`) VALUES
(1),
(2),
(3),
(4);
