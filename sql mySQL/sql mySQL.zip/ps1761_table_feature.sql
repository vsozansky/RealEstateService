
CREATE TABLE `feature` (
  `id_feature` int(10) UNSIGNED NOT NULL,
  `position` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `feature` (`id_feature`, `position`) VALUES
(1, 0),
(2, 1);
