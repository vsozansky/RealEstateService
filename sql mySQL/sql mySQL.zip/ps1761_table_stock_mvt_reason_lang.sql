
CREATE TABLE `stock_mvt_reason_lang` (
  `id_stock_mvt_reason` int(11) UNSIGNED NOT NULL,
  `id_lang` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `stock_mvt_reason_lang` (`id_stock_mvt_reason`, `id_lang`, `name`) VALUES
(1, 1, 'Увеличить'),
(1, 2, 'Збільшити'),
(2, 1, 'Уменьшить'),
(2, 2, 'Зменшити'),
(3, 1, 'Заказ покупателя'),
(3, 2, 'Замовлення покупця'),
(4, 1, 'Regulation following an inventory of stock'),
(4, 2, 'Regulation following an inventory of stock'),
(5, 1, 'Regulation following an inventory of stock'),
(5, 2, 'Regulation following an inventory of stock'),
(6, 1, 'Передача на другой склад'),
(6, 2, 'Переміщення до іншого складу'),
(7, 1, 'Передача с другого склада'),
(7, 2, 'Переміщення з іншого складу'),
(8, 1, 'Заказ на поставку'),
(8, 2, 'Замовлення постачальнику'),
(9, 1, 'Заказ покупателя'),
(9, 2, 'Замовлення покупця'),
(10, 1, 'Возврат товара'),
(10, 2, 'Повернення товару'),
(11, 1, 'Employee Edition'),
(11, 2, 'Employee Edition'),
(12, 1, 'Employee Edition'),
(12, 2, 'Employee Edition');
