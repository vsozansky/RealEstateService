
CREATE TABLE `contact_shop` (
  `id_contact` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `contact_shop` (`id_contact`, `id_shop`) VALUES
(1, 1),
(2, 1);
