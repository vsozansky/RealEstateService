
CREATE TABLE `employee_shop` (
  `id_employee` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `employee_shop` (`id_employee`, `id_shop`) VALUES
(1, 1);
