
CREATE TABLE `order_message_lang` (
  `id_order_message` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(128) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `order_message_lang` (`id_order_message`, `id_lang`, `name`, `message`) VALUES
(1, 1, 'Срок доставки', 'Здравствуйте,\n\nК сожалению, некоторых товаров из вашего заказа нет в наличии. Это может привести к небольшой задержке доставки. Примите наши извинения, уверяем, мы напряженно работаем над устранением этого затруднения.\n\nС уважением,'),
(1, 2, 'Затримка', 'Вітаємо,\n\nНа жаль, деяких товарів з вашого замовлення немає в наявності. Це може призвести до затримки доставки. Прийміть наші вибачення, ми працюємо над якомога швидшим вирішенням проблеми.\n\nЗ повагою,');
