
CREATE TABLE `quick_access_lang` (
  `id_quick_access` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `quick_access_lang` (`id_quick_access`, `id_lang`, `name`) VALUES
(1, 1, 'Заказы'),
(1, 2, 'Замовлення'),
(2, 1, 'Новый купон'),
(2, 2, 'Новий купон'),
(3, 1, 'Новый товар'),
(3, 2, 'Новий товар'),
(4, 1, 'Новая категория'),
(4, 2, 'Нова категорія'),
(5, 1, 'Установленные модули'),
(5, 2, 'Встановлені модулі'),
(6, 1, 'Оценка каталога'),
(6, 2, 'Зведення по Каталогу');
