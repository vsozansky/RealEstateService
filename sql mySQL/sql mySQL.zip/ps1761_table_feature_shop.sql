
CREATE TABLE `feature_shop` (
  `id_feature` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `feature_shop` (`id_feature`, `id_shop`) VALUES
(1, 1),
(2, 1);
