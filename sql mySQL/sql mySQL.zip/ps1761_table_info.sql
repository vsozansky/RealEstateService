
CREATE TABLE `info` (
  `id_info` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `info` (`id_info`) VALUES
(1);
