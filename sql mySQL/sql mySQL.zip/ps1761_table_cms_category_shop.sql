
CREATE TABLE `cms_category_shop` (
  `id_cms_category` int(10) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `cms_category_shop` (`id_cms_category`, `id_shop`) VALUES
(1, 1);
