
CREATE TABLE `feature_value_lang` (
  `id_feature_value` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `value` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `feature_value_lang` (`id_feature_value`, `id_lang`, `value`) VALUES
(1, 1, 'Полиэстер'),
(1, 2, 'Поліестер'),
(2, 1, 'Шерсть'),
(2, 2, 'Вовна'),
(3, 1, 'Ceramic'),
(3, 2, 'Ceramic'),
(4, 1, 'Хлопок'),
(4, 2, 'Бавовна'),
(5, 1, 'Recycled cardboard'),
(5, 2, 'Recycled cardboard'),
(6, 1, 'Matt paper'),
(6, 2, 'Matt paper'),
(7, 1, 'Long sleeves'),
(7, 2, 'Long sleeves'),
(8, 1, 'Short sleeves'),
(8, 2, 'Short sleeves'),
(9, 1, 'Removable cover'),
(9, 2, 'Removable cover'),
(10, 1, '120 pages'),
(10, 2, '120 pages');
