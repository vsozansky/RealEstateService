
CREATE TABLE `layered_filter_shop` (
  `id_layered_filter` int(10) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `layered_filter_shop` (`id_layered_filter`, `id_shop`) VALUES
(1, 1);
