
CREATE TABLE `link_block_lang` (
  `id_link_block` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(40) NOT NULL DEFAULT '',
  `custom_content` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `link_block_lang` (`id_link_block`, `id_lang`, `name`, `custom_content`) VALUES
(1, 1, 'Товары', NULL),
(1, 2, 'Products', NULL),
(2, 1, 'Наша компания', NULL),
(2, 2, 'Our company', NULL);
