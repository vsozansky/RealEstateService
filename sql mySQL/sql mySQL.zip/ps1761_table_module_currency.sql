
CREATE TABLE `module_currency` (
  `id_module` int(10) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL DEFAULT '1',
  `id_currency` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `module_currency` (`id_module`, `id_shop`, `id_currency`) VALUES
(11, 1, 1),
(11, 1, 2),
(11, 1, 3),
(30, 1, 1),
(30, 1, 2),
(30, 1, 3);
