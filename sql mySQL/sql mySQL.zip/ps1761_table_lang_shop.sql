
CREATE TABLE `lang_shop` (
  `id_lang` int(11) NOT NULL,
  `id_shop` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `lang_shop` (`id_lang`, `id_shop`) VALUES
(1, 1),
(2, 1);
