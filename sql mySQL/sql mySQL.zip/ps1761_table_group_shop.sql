
CREATE TABLE `group_shop` (
  `id_group` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `group_shop` (`id_group`, `id_shop`) VALUES
(1, 1),
(2, 1),
(3, 1);
