
CREATE TABLE `page_type` (
  `id_page_type` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `page_type` (`id_page_type`, `name`) VALUES
(1, 'index');
