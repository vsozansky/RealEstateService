
CREATE TABLE `risk_lang` (
  `id_risk` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `risk_lang` (`id_risk`, `id_lang`, `name`) VALUES
(1, 1, 'Нет'),
(1, 2, 'Вимкнені'),
(2, 1, 'Низкий'),
(2, 2, 'Низький'),
(3, 1, 'Средняя'),
(3, 2, 'Середній'),
(4, 1, 'Высокая'),
(4, 2, 'Високий');
