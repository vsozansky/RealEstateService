
CREATE TABLE `order_return_state_lang` (
  `id_order_return_state` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `order_return_state_lang` (`id_order_return_state`, `id_lang`, `name`) VALUES
(1, 1, 'В ожидании подтверждения'),
(1, 2, 'Очікується підтвердження'),
(2, 1, 'Ожидает посылки'),
(2, 2, 'Очікується повернення'),
(3, 1, 'Посылка получена'),
(3, 2, 'Повернення отримано'),
(4, 1, 'Возврат отклонен'),
(4, 2, 'Повернення відхилено'),
(5, 1, 'Возврат осуществлен'),
(5, 2, 'Повернення здійснено');
