
CREATE TABLE `tax_rules_group_shop` (
  `id_tax_rules_group` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tax_rules_group_shop` (`id_tax_rules_group`, `id_shop`) VALUES
(1, 1);
