
CREATE TABLE `webservice_account_shop` (
  `id_webservice_account` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `webservice_account_shop` (`id_webservice_account`, `id_shop`) VALUES
(1, 1);
