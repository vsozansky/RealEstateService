
CREATE TABLE `gender` (
  `id_gender` int(11) NOT NULL,
  `type` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `gender` (`id_gender`, `type`) VALUES
(1, 0),
(2, 1);
