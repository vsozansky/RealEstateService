
CREATE TABLE `category` (
  `id_category` int(10) UNSIGNED NOT NULL,
  `id_parent` int(10) UNSIGNED NOT NULL,
  `id_shop_default` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `level_depth` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `nleft` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `nright` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL,
  `position` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `is_root_category` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `category` (`id_category`, `id_parent`, `id_shop_default`, `level_depth`, `nleft`, `nright`, `active`, `date_add`, `date_upd`, `position`, `is_root_category`) VALUES
(1, 0, 1, 0, 1, 18, 1, '2020-03-03 09:23:14', '2020-03-03 09:23:14', 0, 0),
(2, 1, 1, 1, 2, 17, 1, '2020-03-03 09:23:14', '2020-03-03 09:23:14', 0, 1),
(3, 2, 1, 2, 3, 8, 1, '2020-03-03 09:26:03', '2020-03-03 09:26:03', 0, 0),
(4, 3, 1, 3, 4, 5, 1, '2020-03-03 09:26:03', '2020-03-03 09:26:03', 0, 0),
(5, 3, 1, 3, 6, 7, 1, '2020-03-03 09:26:03', '2020-03-03 09:26:03', 0, 0),
(6, 2, 1, 2, 9, 14, 1, '2020-03-03 09:26:03', '2020-03-03 09:26:03', 0, 0),
(7, 6, 1, 3, 10, 11, 1, '2020-03-03 09:26:03', '2020-03-03 09:26:03', 0, 0),
(8, 6, 1, 3, 12, 13, 1, '2020-03-03 09:26:03', '2020-03-03 09:26:03', 0, 0),
(9, 2, 1, 2, 15, 16, 1, '2020-03-03 09:26:03', '2020-03-03 09:26:03', 0, 0);
