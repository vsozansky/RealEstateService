
CREATE TABLE `carrier_shop` (
  `id_carrier` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `carrier_shop` (`id_carrier`, `id_shop`) VALUES
(1, 1),
(2, 1);
