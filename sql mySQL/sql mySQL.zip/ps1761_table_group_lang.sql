
CREATE TABLE `group_lang` (
  `id_group` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `group_lang` (`id_group`, `id_lang`, `name`) VALUES
(1, 1, 'Посетитель'),
(1, 2, 'Відвідувач'),
(2, 1, 'Гость'),
(2, 2, 'Гість'),
(3, 1, 'Клиент'),
(3, 2, 'Клієнт');
