
CREATE TABLE `order_history` (
  `id_order_history` int(10) UNSIGNED NOT NULL,
  `id_employee` int(10) UNSIGNED NOT NULL,
  `id_order` int(10) UNSIGNED NOT NULL,
  `id_order_state` int(10) UNSIGNED NOT NULL,
  `date_add` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `order_history` (`id_order_history`, `id_employee`, `id_order`, `id_order_state`, `date_add`) VALUES
(1, 0, 1, 1, '2020-03-03 09:26:05'),
(2, 0, 2, 1, '2020-03-03 09:26:05'),
(3, 0, 3, 1, '2020-03-03 09:26:05'),
(4, 0, 4, 1, '2020-03-03 09:26:05'),
(5, 0, 5, 10, '2020-03-03 09:26:05'),
(6, 1, 1, 6, '2020-03-03 09:26:05'),
(7, 1, 3, 8, '2020-03-03 09:26:05');
