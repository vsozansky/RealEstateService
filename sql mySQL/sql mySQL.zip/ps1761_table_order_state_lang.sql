
CREATE TABLE `order_state_lang` (
  `id_order_state` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) NOT NULL,
  `template` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `order_state_lang` (`id_order_state`, `id_lang`, `name`, `template`) VALUES
(1, 1, 'Ожидается оплата чеком', 'cheque'),
(1, 2, 'Очікування перевірки платежу', 'cheque'),
(2, 1, 'Платеж принят', 'payment'),
(2, 2, 'Оплату прийнято', 'payment'),
(3, 1, 'В обработке', 'preparation'),
(3, 2, 'В обробці', 'preparation'),
(4, 1, 'Отправлен', 'shipped'),
(4, 2, 'Доставляється', 'shipped'),
(5, 1, 'Доставлено', ''),
(5, 2, 'Доставлено', ''),
(6, 1, 'Отменено', 'order_canceled'),
(6, 2, 'Відмінено', 'order_canceled'),
(7, 1, 'Возмещено', 'refund'),
(7, 2, 'Відмінено', 'refund'),
(8, 1, 'Ошибка оплаты', 'payment_error'),
(8, 2, 'Помилка оплати', 'payment_error'),
(9, 1, 'Данного товара нет на складе (оплачен)', 'outofstock'),
(9, 2, 'Товар вичерпано (оплачено)', 'outofstock'),
(10, 1, 'Ожидается оплата банковским переводом', 'bankwire'),
(10, 2, 'Очікується оплата банківським переказом', 'bankwire'),
(11, 1, 'Платеж принят', 'payment'),
(11, 2, 'Відкладений платіж прийнято', 'payment'),
(12, 1, 'Данного товара нет на складе (не оплачен)', 'outofstock'),
(12, 2, 'Товар вичерпано (без оплати)', 'outofstock'),
(13, 1, 'Ожидается подтверждение оплаты наличными', 'cashondelivery'),
(13, 2, 'Очікується платіж післяплатою', 'cashondelivery');
