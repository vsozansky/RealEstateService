
CREATE TABLE `order_message` (
  `id_order_message` int(10) UNSIGNED NOT NULL,
  `date_add` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `order_message` (`id_order_message`, `date_add`) VALUES
(1, '2020-03-03 09:26:05');
