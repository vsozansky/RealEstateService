
CREATE TABLE `profile_lang` (
  `id_lang` int(10) UNSIGNED NOT NULL,
  `id_profile` int(10) UNSIGNED NOT NULL,
  `name` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `profile_lang` (`id_lang`, `id_profile`, `name`) VALUES
(1, 1, 'Суперадминистратор'),
(2, 1, 'Суперадміністратор'),
(1, 2, 'Логист'),
(2, 2, 'Логіст'),
(1, 3, 'Переводчик'),
(2, 3, 'Перекладач'),
(1, 4, 'Менеджер по продажам'),
(2, 4, 'Продавець');
