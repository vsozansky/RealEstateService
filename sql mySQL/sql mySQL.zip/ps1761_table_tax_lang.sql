
CREATE TABLE `tax_lang` (
  `id_tax` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tax_lang` (`id_tax`, `id_lang`, `name`) VALUES
(1, 1, 'НДС 20%'),
(1, 2, 'НДС 20%');
