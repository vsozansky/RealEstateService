
CREATE TABLE `info_shop` (
  `id_info` int(10) UNSIGNED NOT NULL,
  `id_shop` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `info_shop` (`id_info`, `id_shop`) VALUES
(1, 1);
