
CREATE TABLE `module_country` (
  `id_module` int(10) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL DEFAULT '1',
  `id_country` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `module_country` (`id_module`, `id_shop`, `id_country`) VALUES
(11, 1, 216),
(30, 1, 216);
