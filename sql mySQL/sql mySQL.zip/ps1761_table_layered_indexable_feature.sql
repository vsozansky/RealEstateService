
CREATE TABLE `layered_indexable_feature` (
  `id_feature` int(11) NOT NULL,
  `indexable` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `layered_indexable_feature` (`id_feature`, `indexable`) VALUES
(1, 1),
(2, 1);
