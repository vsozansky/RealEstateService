
CREATE TABLE `supply_order_state_lang` (
  `id_supply_order_state` int(11) UNSIGNED NOT NULL,
  `id_lang` int(11) UNSIGNED NOT NULL,
  `name` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `supply_order_state_lang` (`id_supply_order_state`, `id_lang`, `name`) VALUES
(1, 1, '1 - Создаётся'),
(1, 2, '1 - Створюється'),
(2, 1, '2 - Заказ одобрен'),
(2, 2, '2 - Замовлення прийнято'),
(3, 1, '3 - Ожидание получения'),
(3, 2, '3 - Очікуємо отримання'),
(4, 1, '4 - Получен частично'),
(4, 2, '4 - Частково отримано'),
(5, 1, '5 - Получен'),
(5, 2, '5 - Отримано'),
(6, 1, '6 - Отменён'),
(6, 2, '6 - Замовлення скасовано');
